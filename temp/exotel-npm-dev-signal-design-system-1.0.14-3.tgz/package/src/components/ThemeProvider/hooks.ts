import { useColorScheme } from "@mui/material/styles";
import type { UseThemeModeReturn } from "./ThemeProvider";

/**
 * Read or change the current theme mode from anywhere inside
 * `<ExotelThemeProvider>`.
 *
 * ```tsx
 * const { mode, setMode, toggleMode } = useThemeMode();
 * ```
 */
export function useThemeMode(): UseThemeModeReturn {
  const { mode, setMode } = useColorScheme();
  
  const toggleMode = () => {
    setMode(mode === 'dark' ? 'light' : 'dark');
  };
  
  return { mode: mode || 'system', setMode, toggleMode };
}

/**
 * It will return the data based on the theme mode.
 * @param lightModeData 
 * @param darkModeData 
 * @returns lightModeData | darkModeData
 */
export const useLoadDataByTheme = <T>(lightModeData: T, darkModeData: T) => {
  const theme = useThemeMode();
  return theme.mode === 'dark' ? darkModeData : lightModeData;
}

// Re-export useFont from ThemeProvider for convenience
export { useFont } from "./ThemeProvider";
