/**
 * ExotelThemeProvider, useThemeMode & useFont
 *
 * Usage in a consumer app:
 * ```tsx
 * import { ExotelThemeProvider, useThemeMode, useFont } from '@exotel/design-system';
 *
 * function App() {
 *   return (
 *     <ExotelThemeProvider defaultMode="light">
 *       <ThemeToggle />
 *       <FontToggle />
 *       <AppContent />
 *     </ExotelThemeProvider>
 *   );
 * }
 *
 * function ThemeToggle() {
 *   const { mode, setMode, toggleMode } = useThemeMode();
 *   return <button onClick={toggleMode}>Current: {mode}</button>;
 * }
 *
 * function FontToggle() {
 *   const { fontKey, setFont } = useFont();
 *   return (
 *     <button onClick={() => setFont(fontKey === 'noto-sans' ? 'ibm-plex-sans' : 'noto-sans')}>
 *       Current font: {fontKey}
 *     </button>
 *   );
 * }
 * ```
 */

import { createContext, useContext, useMemo, useState, useEffect } from "react";
import type { ReactNode } from "react";
import { ThemeProvider, useColorScheme } from "@mui/material/styles";
import type { ThemeOptions } from "@mui/material/styles";
import CssBaseline from "@mui/material/CssBaseline";
import { deepmerge } from "@mui/utils";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { createExotelTheme, DEFAULT_FONT } from "../../theme";
import type { FontKey } from "../../theme";

export type ThemeMode = "light" | "dark" | "system";

export interface ExotelThemeProviderProps {
  children: ReactNode;
  /**
   * The initial color mode applied on first visit (before any user toggle).
   * - `'light'`  — start in light mode (default)
   * - `'dark'`   — start in dark mode
   * - `'system'` — follow the user's OS preference
   *
   * After the user changes the mode via `useThemeMode().setMode()`,
   * their choice is persisted and takes priority over this value.
   */
  defaultMode?: ThemeMode;
  /**
   * Initial font. Defaults to `"noto-sans"`.
   * Can be changed at runtime via `useFont().setFont()`.
   */
  defaultFont?: FontKey;
  /**
   * Locale string passed to the dayjs date adapter (e.g. "en", "de", "ja").
   * Controls formatting for all date/time picker components.
   */
  adapterLocale?: string;
  /**
   * Partial theme overrides deep-merged on top of the base Exotel theme.
   * Use this to extend palette colors, add component overrides, or
   * adjust typography without forking the design system theme.
   */
  themeOverrides?: ThemeOptions;
}

/** Public hook return type for `useThemeMode`. */
export interface UseThemeModeReturn {
  /** Current resolved mode (`'light'` or `'dark'`). `undefined` during SSR. */
  mode: ThemeMode;
  /** Set the mode explicitly. */
  setMode: (mode: ThemeMode) => void;
  /** Toggle between light and dark. */
  toggleMode: () => void;
}

/** Public hook return type for `useFont`. */
export interface UseFontReturn {
  /** Currently active font key. */
  fontKey: FontKey;
  /** Switch to a different font at runtime. Persisted in localStorage. */
  setFont: (key: FontKey) => void;
}

// ---------------------------------------------------------------------------
// Font context — allows any descendant to read or change the active font
// ---------------------------------------------------------------------------

const FONT_STORAGE_KEY = "exotel-font";

const FontContext = createContext<UseFontReturn | null>(null);

export function useFont(): UseFontReturn {
  const ctx = useContext(FontContext);
  if (!ctx) {
    throw new Error("useFont() must be used inside <ExotelThemeProvider>");
  }
  return ctx;
}

// ---------------------------------------------------------------------------
// Internal: syncs the defaultMode prop into MUI on mount
// ---------------------------------------------------------------------------

function InitialModeSync({ defaultMode }: { defaultMode: ThemeMode }) {
  const { setMode } = useColorScheme();
  useEffect(() => {
    setMode(defaultMode);
    // Only run on mount — after this, useThemeMode().setMode() takes over.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  return null;
}

// ---------------------------------------------------------------------------
// ExotelThemeProvider
// ---------------------------------------------------------------------------

const MODE_STORAGE_KEY = "exotel-mode";

function getStoredFont(fallback: FontKey): FontKey {
  try {
    const stored = localStorage.getItem(FONT_STORAGE_KEY);
    if (stored === "noto-sans" || stored === "ibm-plex-sans") return stored;
  } catch {
    /* SSR or private browsing */
  }
  return fallback;
}

export function ExotelThemeProvider({
  children,
  defaultMode = "light",
  defaultFont = DEFAULT_FONT,
  adapterLocale,
  themeOverrides,
}: ExotelThemeProviderProps) {
  const [fontKey, setFontKey] = useState<FontKey>(() =>
    getStoredFont(defaultFont)
  );

  const setFont = (key: FontKey) => {
    setFontKey(key);
    try {
      localStorage.setItem(FONT_STORAGE_KEY, key);
    } catch {
      /* ignore */
    }
  };

  const theme = useMemo(() => {
    return createExotelTheme(fontKey, themeOverrides);
  }, [fontKey, themeOverrides]);

  const fontCtx = useMemo<UseFontReturn>(
    () => ({ fontKey, setFont }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [fontKey]
  );

  return (
    <FontContext.Provider value={fontCtx}>
      <ThemeProvider
        theme={theme}
        defaultMode={defaultMode}
        modeStorageKey={MODE_STORAGE_KEY}
        noSsr
      >
        <InitialModeSync defaultMode={defaultMode} />
        <CssBaseline />
        <LocalizationProvider
          dateAdapter={AdapterDayjs}
          adapterLocale={adapterLocale}
        >
          {children}
        </LocalizationProvider>
      </ThemeProvider>
    </FontContext.Provider>
  );
}
