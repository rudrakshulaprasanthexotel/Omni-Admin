/**
 * Typography Component
 * 
 * Exotel-approved typography component that wraps MUI's Typography.
 */

import MuiTypography, { type TypographyProps as MuiTypographyProps } from '@mui/material/Typography';
import { forwardRef } from 'react';

export interface TypographyProps extends Omit<MuiTypographyProps, 'ref'> {
  children?: React.ReactNode;
}

export const Typography = forwardRef<HTMLElement, TypographyProps>(
  (props, ref) => <MuiTypography ref={ref} {...props} />
);

Typography.displayName = 'Typography';
