/**
 * Slider Component
 * 
 * Exotel-approved slider component that wraps MUI's Slider.
 */

import MuiSlider, { type SliderProps as MuiSliderProps } from '@mui/material/Slider';
import { forwardRef } from 'react';

export interface SliderProps extends Omit<MuiSliderProps, 'ref'> {
  value?: number | number[];
  onChange?: (event: Event, value: number | number[], activeThumb: number) => void;
}

export const Slider = forwardRef<HTMLSpanElement, SliderProps>(
  (props, ref) => <MuiSlider ref={ref} {...props} />
);

Slider.displayName = 'Slider';
