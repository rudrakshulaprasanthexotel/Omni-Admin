/**
 * Card Component
 * 
 * Exports the Exotel Card component that wraps MUI's Card.
 */

export { Card } from './Card';
export type { CardProps } from './Card';
