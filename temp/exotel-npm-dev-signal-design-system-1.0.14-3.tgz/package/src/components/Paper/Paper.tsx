/**
 * Paper Component
 * 
 * Exotel-approved paper component that wraps MUI's Paper.
 */

import MuiPaper, { type PaperProps as MuiPaperProps } from '@mui/material/Paper';
import { forwardRef } from 'react';

export interface PaperProps extends Omit<MuiPaperProps, 'ref'> {
  children?: React.ReactNode;
}

export const Paper = forwardRef<HTMLDivElement, PaperProps>(
  (props, ref) => <MuiPaper ref={ref} {...props} />
);

Paper.displayName = 'Paper';
