/**
 * Breadcrumbs Component
 * 
 * Exotel-approved breadcrumbs component that wraps MUI's Breadcrumbs.
 */

import MuiBreadcrumbs, { type BreadcrumbsProps as MuiBreadcrumbsProps } from '@mui/material/Breadcrumbs';
import { forwardRef } from 'react';

export interface BreadcrumbsProps extends Omit<MuiBreadcrumbsProps, 'ref'> {
  children?: React.ReactNode;
}

export const Breadcrumbs = forwardRef<HTMLElement, BreadcrumbsProps>(
  (props, ref) => <MuiBreadcrumbs ref={ref} {...props} />
);

Breadcrumbs.displayName = 'Breadcrumbs';
