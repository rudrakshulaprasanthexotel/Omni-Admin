export { Dialog } from './Dialog';
export type { DialogProps } from './Dialog';

export { StructuredDialog, DialogBody, DialogFooter } from './StructuredDialog';
export type { StructuredDialogProps } from './StructuredDialog';
