/**
 * LinearProgress Component
 * 
 * Exotel-approved linear progress component that wraps MUI's LinearProgress.
 */

import MuiLinearProgress, { type LinearProgressProps as MuiLinearProgressProps } from '@mui/material/LinearProgress';
import { forwardRef } from 'react';

export interface LinearProgressProps extends Omit<MuiLinearProgressProps, 'ref'> {}

export const LinearProgress = forwardRef<HTMLSpanElement, LinearProgressProps>(
  (props, ref) => <MuiLinearProgress ref={ref} {...props} />
);

LinearProgress.displayName = 'LinearProgress';
