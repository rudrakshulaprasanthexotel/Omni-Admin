import dayjs from 'dayjs';
import type { PickersShortcutsItem } from '@mui/x-date-pickers/PickersShortcuts';
import type { DateRange } from '@mui/x-date-pickers-pro';
import type { Dayjs } from 'dayjs';

export type DateRangeShortcut = PickersShortcutsItem<DateRange<Dayjs>>;

export const DEFAULT_DATE_RANGE_SHORTCUTS: DateRangeShortcut[] = [
  {
    label: 'Today',
    getValue: () => {
      const today = dayjs();
      return [today.startOf('day'), today.endOf('day')];
    },
  },
  {
    label: 'Yesterday',
    getValue: () => {
      const yesterday = dayjs().subtract(1, 'day');
      return [yesterday.startOf('day'), yesterday.endOf('day')];
    },
  },
  {
    label: 'Last 3 Days',
    getValue: () => {
      return [dayjs().subtract(2, 'days').startOf('day'), dayjs().endOf('day')];
    },
  },
  {
    label: 'Last 7 Days',
    getValue: () => {
      return [dayjs().subtract(6, 'days').startOf('day'), dayjs().endOf('day')];
    },
  },
  {
    label: 'Last 14 Days',
    getValue: () => {
      return [dayjs().subtract(13, 'days').startOf('day'), dayjs().endOf('day')];
    },
  },
  {
    label: 'Last 30 Days',
    getValue: () => {
      return [dayjs().subtract(29, 'days').startOf('day'), dayjs().endOf('day')];
    },
  },
  {
    label: 'Last Month',
    getValue: () => {
      const firstDayLastMonth = dayjs().subtract(1, 'month').startOf('month');
      const lastDayLastMonth = dayjs().subtract(1, 'month').endOf('month');
      return [firstDayLastMonth, lastDayLastMonth];
    },
  },
];
