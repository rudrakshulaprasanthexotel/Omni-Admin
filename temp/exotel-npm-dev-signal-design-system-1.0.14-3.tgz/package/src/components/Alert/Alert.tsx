/**
 * Alert Component
 * 
 * Exotel-approved alert component that wraps MUI's Alert.
 */

import MuiAlert, { type AlertProps as MuiAlertProps } from '@mui/material/Alert';
import { forwardRef } from 'react';

export interface AlertProps extends Omit<MuiAlertProps, 'ref'> {
  children?: React.ReactNode;
}

export const Alert = forwardRef<HTMLDivElement, AlertProps>(
  (props, ref) => <MuiAlert ref={ref} {...props} />
);

Alert.displayName = 'Alert';
