// url=https://www.figma.com/design/CiTSqZD3DKtMu91owRSkZW/Signal-Design-System?node-id=6587-47500
// source=src/components/Badge/Badge.tsx
// component=Badge
import figma from 'figma';

const instance = figma.selectedInstance;

const variant = instance.getEnum('Variant', {
  Standard: 'standard',
  Dot: 'dot',
  Tonal: 'tonal',
});

const color = instance.getEnum('Color', {
  Default: 'default',
  Primary: 'primary',
  Secondary: 'secondary',
  Error: 'error',
  Warning: 'warning',
  Info: 'info',
  Success: 'success',
});

const content = instance.getString('Content');
const showBadgeContent = variant === 'standard' || variant === 'tonal';

export default {
  example: figma.code`
    <Badge
      variant="${variant}"
      color="${color}"
      ${showBadgeContent ? figma.code`badgeContent="${content}"` : ''}
    >
      <IconButton size="small">
        <Icon name="bell-ringing" size="md" />
      </IconButton>
    </Badge>
  `,
  imports: [
    'import { Badge, IconButton, Icon } from "@exotel-npm-dev/signal-design-system"',
  ],
  id: 'badge',
  metadata: {
    nestable: true,
  },
};
