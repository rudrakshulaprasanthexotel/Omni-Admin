/**
 * Switch Component
 * 
 * Exotel-approved switch component that wraps MUI's Switch.
 */

import MuiSwitch, { type SwitchProps as MuiSwitchProps } from '@mui/material/Switch';
import { forwardRef } from 'react';

export interface SwitchProps extends Omit<MuiSwitchProps, 'ref'> {
  checked?: boolean;
  disabled?: boolean;
  onChange?: (event: React.ChangeEvent<HTMLInputElement>, checked: boolean) => void;
}

export const Switch = forwardRef<HTMLButtonElement, SwitchProps>(
  (props, ref) => <MuiSwitch ref={ref} {...props} />
);

Switch.displayName = 'Switch';
