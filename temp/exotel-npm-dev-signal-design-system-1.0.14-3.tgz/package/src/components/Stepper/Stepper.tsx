/**
 * Stepper Component
 * 
 * Exotel-approved stepper component that wraps MUI's Stepper.
 */

import MuiStepper, { type StepperProps as MuiStepperProps } from '@mui/material/Stepper';
import { forwardRef } from 'react';

export interface StepperProps extends Omit<MuiStepperProps, 'ref'> {
  children?: React.ReactNode;
}

export const Stepper = forwardRef<HTMLDivElement, StepperProps>(
  (props, ref) => <MuiStepper ref={ref} {...props} />
);

Stepper.displayName = 'Stepper';
