import { useState, useEffect } from "react";
import { useNavigationContext } from "../navigationContext";
import { checkActiveChild } from "../utils";
import { ListItemButton, ListItemIcon, ListItemText } from "../../List";
import { Icon, type IconName } from "../../Icon";
import { Collapse } from "@mui/material";
import { NavSection } from "./NavSection";
import { IconButton } from "../../IconButton";

export interface NavItemProps {
    id: string;
    iconName?: IconName;
    label: string;
    path?: string;
    openNewPage: boolean;
    onClick?: () => void;
    children?: Omit<NavItemProps, 'level'>[];
    level: number;
    showPin?: boolean;
    pinnedItem?: boolean;
}

export const NavItem = ({
    id,
    level,
    iconName,
    label,
    path,
    openNewPage,
    onClick,
    children,
    showPin = false,
    pinnedItem = false,
}: NavItemProps) => {
    const [isHovered, setIsHovered] = useState(false);

    if (level > 3) throw new Error('NavItem level cannot be greater than 3');

    const { currentPath, setCurrentPath, sidebarExpanded, search, searchExpandedIds, setPinnedItems, pinnedItems } = useNavigationContext();
    const hasChildren = Boolean(children?.length);
    const isActive = path === currentPath;
    const hasActiveChild = checkActiveChild(children || [], currentPath);
    
    // Determine if this item should be expanded due to search
    const shouldExpandForSearch = Boolean(search) && searchExpandedIds.has(id);
    
    const [ isExpanded, setIsExpanded ] = useState(
        hasChildren && (isActive || hasActiveChild || shouldExpandForSearch)
    );
    const [ userInteracted, setUserInteracted ] = useState(false);
    const isPinned = pinnedItems.some((item) => item.id === id);
    const showPinButton = showPin && (pinnedItem || isHovered);


    // Handle search-based expansion
    useEffect(() => {
        if (hasChildren) {
            const hasSearchQuery = Boolean(search && search.trim());
            if (hasSearchQuery && searchExpandedIds.has(id)) {
                // Expand when this item is in the search path (only if user hasn't manually interacted)
                if (!userInteracted) {
                    setIsExpanded(true);
                }
            } else if (!hasSearchQuery) {
                // When search is cleared, revert to default behavior and reset user interaction flag
                setIsExpanded(isActive || hasActiveChild);
                setUserInteracted(false);
            }
        }
    }, [search, searchExpandedIds, id, hasChildren, isActive, hasActiveChild, userInteracted]);

    const handleClickItem = () => {
        if (hasChildren) {
            setIsExpanded(!isExpanded);
            // Mark that user has manually interacted with this item
            if (search) {
                setUserInteracted(true);
            }
        } else {
            if (path) setCurrentPath(path);
            onClick?.();
        }
    };

    const handlePinClick = (e: React.MouseEvent<HTMLButtonElement>) => {
        e.stopPropagation();
        e.preventDefault();
        if (isPinned) {
            setPinnedItems(pinnedItems.filter((item) => item.id !== id));
        } else {
            setPinnedItems([...pinnedItems, { id, iconName, label, path, openNewPage, level, showPin, pinnedItem: true }]);
        }
    }

    return (
        <>
            <ListItemButton
                onClick={handleClickItem}
                onMouseEnter={() => setIsHovered(true)}
                onMouseLeave={() => setIsHovered(false)}
                selected={isActive}
                sx={{
                    '& .MuiListItemText-primary': (theme) => {
                        const { lineHeight: _, ...rest } = theme.typography.label1;
                        return Object.fromEntries(
                            Object.entries(rest).map(
                                ([key, val]) => [key, `${val} !important`]
                            )
                        );
                    }
                }}
            >
                {iconName && (
                    <ListItemIcon>
                        <Icon name={iconName} size="sm" />
                    </ListItemIcon>
                )}
                <ListItemText
                    sx={{
                        opacity: sidebarExpanded ? 1 : 0
                    }}
                    primary={label}
                />
                {!hasChildren && showPinButton && (
                    <IconButton size="small" onClick={handlePinClick}>
                        <Icon name={isPinned ? 'push-pin-slash' : 'push-pin'} size="xs" color="grey" />
                    </IconButton>
                )}
                {openNewPage && (
                    <ListItemIcon sx={{ display: sidebarExpanded ? 'block' : 'none', minWidth: 2.25, marginRight: '4px' }}>
                        <Icon name="arrow-square-out" size="sm" color="grey" />
                    </ListItemIcon>
                )}
                {hasChildren && (
                    <ListItemIcon sx={{ minWidth: 2.25, marginRight: '4px', display: sidebarExpanded ? 'block' : 'none' }}>
                        <Icon size="xs" name={isExpanded ? 'caret-down' : 'caret-right'} weight="fill" />
                    </ListItemIcon>
                )}
            </ListItemButton>
            {children && Boolean(children?.length) && (
                <Collapse in={isExpanded && sidebarExpanded} timeout="auto" unmountOnExit>
                    <NavSection
                        level={level + 1}
                        items={children}
                    />
                </Collapse>
            )}
        </>
    )
}
