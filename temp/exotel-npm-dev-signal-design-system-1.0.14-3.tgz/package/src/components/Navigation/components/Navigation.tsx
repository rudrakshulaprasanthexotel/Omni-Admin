import { forwardRef, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { NavToolbar } from "./NavToolbar";
import { NavSections } from "./NavSections";
import type { NavSectionProps } from "./NavSection";
import { NavigationProvider, type NavigationContextProps } from "../navigationContext";
import { NavFooter } from "./NavFooter";
import { Divider } from "../../Divider";
import { buildDisplayConfig, filterSectionsBySearch, filterSectionsByVisibility, mergeDisplayConfig } from "../utils";
import { Box } from "../../Box";
import type { NavItemProps } from "./NavItem";

export interface NavigationProps {
  items: NavSectionProps[];
  staticSidebar?: boolean;
}

export const Navigation = forwardRef<HTMLDivElement, NavigationProps>((props, ref) => {
  const { items, staticSidebar = false } = props;

  const [ search, setSearch ] = useState('');
  const [ isPinned, setIsPinned ] = useState(false);
  const [ isHovered, setIsHovered ] = useState(false);
  const [ sections, setSections ] = useState<NavSectionProps[]>([]);
  const [ currentPath, setCurrentPath ] = useState('/home');
  const [ displayConfig, setDisplayConfig ] = useState(() => buildDisplayConfig(items));
  const [ searchExpandedIds, setSearchExpandedIds ] = useState<Set<string>>(new Set());
  const [ pinnedItems, setPinnedItems ] = useState<NavItemProps[]>([]);

  const sidebarExpanded = staticSidebar || isPinned || isHovered;
  const localRef = useRef<HTMLDivElement | null>(null);

  const setCombinedRef = useCallback(
    (node: HTMLDivElement | null) => {
      localRef.current = node;
      if (typeof ref === "function") {
        ref(node);
      } else if (ref) {
        ref.current = node;
      }
    }, [ref]);

  const visibleSections = useMemo(() => {
    const visibilityFiltered = filterSectionsByVisibility(sections, displayConfig);
    const searchResult = filterSectionsBySearch(visibilityFiltered, search);
    setSearchExpandedIds(searchResult.expandedIds);
    return searchResult.sections;
  }, [sections, displayConfig, search]);

  const navigationData: NavigationContextProps = {
    staticSidebar,
    currentPath,
    setCurrentPath,
    sidebarExpanded,
    isPinned,
    setIsPinned,
    search,
    setSearch,
    sections,
    setSections,
    displayConfig,
    setDisplayConfig,
    searchExpandedIds,
    setSearchExpandedIds,
    pinnedItems,
    setPinnedItems,
  };
  
  useEffect(() => {
    setSections(items);
    setDisplayConfig((prev) => mergeDisplayConfig(prev, items));
  }, [items]);

  useEffect(() => {
    const node = localRef.current;
    if (!node) {
      return;
    }
    const handleEnter = () => setIsHovered(true);
    const handleLeave = () => setIsHovered(false);
    node.addEventListener('mouseenter', handleEnter);
    node.addEventListener('mouseleave', handleLeave);
    return () => {
      node.removeEventListener('mouseenter', handleEnter);
      node.removeEventListener('mouseleave', handleLeave);
    };
  }, []);

  // useEffect(() => {
  //   setCurrentPath(window.location.pathname);

  //   window.addEventListener('popstate', (...e) => {
  //     console.log('+++++++++++++++popstate', e);
  //   });
  //   // @ts-ignore
  //   window.navigation.addEventListener("currententrychange", () => {
  //     // @ts-ignore
  //     const data = window.navigation.currentEntry.getState();
  //     console.log('+++++++++++++++currententrychange', data);
  //   });
  // }, [])

  return (
    <NavigationProvider value={navigationData}>
      <Box
        sx={{
          height: '100%',
          width: (staticSidebar || isPinned) ? undefined : '62px',
          zIndex: 20,
          position: 'sticky',
        }}
        component="aside"
        ref={setCombinedRef}
      >
        <Box
          component="nav"
          sx={{
            width: sidebarExpanded ? '250px' : '62px',
            paddingBlock: '12px 8px',
            overflow: 'hidden',
            transition: 'width 0.25s ease',
            display: 'flex',
            flexDirection: 'column',
            height: '100%',
            backgroundColor: 'surface.elevation1',
            borderRight: (theme) => `1px solid ${theme.vars?.palette?.divider}`,
          }}
          aria-label="navigation-bar"
        >
          <NavToolbar id="navigation" />
          <NavSections sections={visibleSections} />
          <Divider />
          <NavFooter />
        </Box>
      </Box>
    </NavigationProvider>
  )
});

Navigation.displayName = 'Navigation';