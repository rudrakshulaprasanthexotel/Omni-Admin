import { InputAdornment } from "@mui/material";
import { EnhancedTextField as TextField } from "../../EnhancedTextField"
import { Icon } from "../../Icon";
import { IconButton } from "../../IconButton";
import { useNavigationContext } from "../navigationContext";
import { Box } from "../../Box";

interface NavToolbarProps {
    id: string;
}

export const NavToolbar = ({
    id
}: NavToolbarProps) => {
    const { search, setSearch, isPinned, setIsPinned, sidebarExpanded, staticSidebar } = useNavigationContext();

    return (
        <Box component="div" sx={{ display: 'flex', alignItems: 'center', gap: 1, paddingInline: '12px' }}>
            {!sidebarExpanded ? (
                <Box sx={{ marginLeft: 1, height: 32, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <Icon size="sm" name="magnifying-glass" color="grey" />
                </Box>
            ) : (
                <>
                    <TextField
                        id={`${id}-nav-toolbar-search`}
                        value={search}
                        size="small"
                        placeholder="Search"
                        sx={{
                            flex: 1,
                            '& .MuiInputBase-root': {
                                paddingLeft: 1,
                            }
                        }}
                        onChange={(e) => setSearch?.(e.target.value)}
                        slotProps={{
                            input: {
                                startAdornment: (
                                <InputAdornment position="start">
                                    <Icon size="sm" name="magnifying-glass" color="grey" />
                                </InputAdornment>
                                ),
                            },
                        }}
                    />
                    {!staticSidebar && (
                        <IconButton
                            onClick={() => setIsPinned?.(!isPinned)}
                            size="small"
                        >
                            <Icon name={isPinned ? 'push-pin-slash' : 'push-pin'} size="sm" color="grey" />
                        </IconButton>
                    )}
                </>
            )}
        </Box>
    )
}
