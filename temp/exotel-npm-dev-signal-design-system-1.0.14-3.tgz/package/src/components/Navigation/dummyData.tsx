import type { NavSectionProps } from "./components/NavSection";
import { Icon } from "../Icon";

export const dummyItems: NavSectionProps[] = [
    {
        items: [
            {
                id: 'home',
                iconName: 'house',
                label: 'Home',
                path: '/home',
                openNewPage: false,
            },
            {
                id: 'interactions',
                iconName: 'headset',
                label: 'Interactions',
                path: '/interactions',
                openNewPage: false,
            },
            {
                id: 'interaction-history',
                iconName: 'file-text',
                label: 'Interaction History',
                path: '/interactions/history',
                openNewPage: false,
            },
            {
                id: 'contacts',
                iconName: 'address-book',
                label: 'Contacts',
                path: '/contacts',
                openNewPage: false,
            },
            {
                id: 'insights',
                iconName: 'chart-bar',
                label: 'Insights',
                path: '/insights',
                openNewPage: false,
            },
        ],
    },
    {
        label: 'MONITOR',
        items: [
            {
                id: 'monitor-analysis',
                iconName: 'chart-line',
                label: 'Analysis',
                path: '/monitor/analysis',
                openNewPage: false,
                children: [
                    {
                        id: 'monitor-analysis-dashboard',
                        label: 'Dashboard',
                        path: '/monitor/analysis/dashboard',
                        openNewPage: false,
                    },
                    {
                        id: 'monitor-analysis-reports',
                        label: 'Reports',
                        path: '/monitor/analysis/reports',
                        openNewPage: false,
                        children: [
                            {
                                id: 'monitor-analysis-call',
                                label: 'Call Analysis',
                                path: '/monitor/analysis/call-analysis',
                                openNewPage: false,
                            },
                            {
                                id: 'monitor-analysis-report-history',
                                label: 'Report History',
                                path: '/monitor/analysis/report-history',
                                openNewPage: false,
                            },
                        ]
                    },
                ],
            },
        ],
    },
    {
        items: [
            {
                id: 'manage',
                iconName: 'gear',
                label: 'Manage',
                path: '/manage',
                openNewPage: false,
                children: [
                    {
                        id: 'manage-call-settings',
                        label: 'Call Settings',
                        path: '/manage/call-settings',
                        openNewPage: false,
                    },
                ],
            },
            {
                id: 'users',
                iconName: 'user',
                label: 'Users & Privileges',
                path: '/users',
                openNewPage: false,
                children: [
                    {
                        id: 'users-roles',
                        label: 'Roles',
                        path: '/users/roles',
                        openNewPage: false,
                    },
                ],
            },
            {
                id: 'advanced-settings',
                iconName: 'gear',
                label: 'Advanced Settings',
                path: '/settings/advanced',
                openNewPage: false,
                children: [
                    {
                        id: 'advanced-settings-preferences',
                        label: 'Preferences',
                        path: '/settings/advanced/preferences',
                        openNewPage: false,
                    },
                ],
            },
        ],
    },
    {
        label: 'APPS',
        items: [
            {
                id: 'apps-voicelogs',
                iconName: 'phone',
                label: 'Voicelogs',
                path: '/apps/voicelogs',
                openNewPage: false,
            },
            {
                id: 'apps-control-center',
                iconName: 'gear',
                label: 'Control Center',
                path: '/apps/control-center',
                openNewPage: false,
            },
        ],
    },
    {
        items: [
            {
                id: 'voicebot',
                iconName: 'phone',
                label: 'Voicebot',
                path: '/voicebot',
                openNewPage: true,
            },
            {
                id: 'chatbot',
                iconName: 'chat',
                label: 'Chatbot',
                path: '/chatbot',
                openNewPage: true,
            },
        ],
    },
];