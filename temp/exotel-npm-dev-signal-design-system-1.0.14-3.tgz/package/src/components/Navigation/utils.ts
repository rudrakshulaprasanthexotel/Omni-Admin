import type { NavItemProps } from "./components/NavItem";
import type { NavSectionProps } from "./components/NavSection";

export type DisplayConfig = Record<string, boolean>;


export const checkActiveChild = (children: Omit<NavItemProps, 'level'>[], activePath: string): boolean => {
    return children.some((child) => {
        if (child.path === activePath) {
            return true;
        }
        if (child.children) {
            return checkActiveChild(child.children, activePath);
        }
        return false;
    });
};

const walkItems = (
    items: Omit<NavItemProps, 'level'>[],
    callback: (item: Omit<NavItemProps, 'level'>) => void
) => {
    items.forEach((item) => {
        callback(item);
        if (item.children) {
            walkItems(item.children, callback);
        }
    });
};

export const buildDisplayConfig = (sections: NavSectionProps[]): DisplayConfig => {
    const config: DisplayConfig = {};
    sections.forEach((section) => {
        walkItems(section.items, (item) => {
            config[item.id] = true;
        });
    });
    return config;
};

export const mergeDisplayConfig = (
    existing: DisplayConfig,
    sections: NavSectionProps[]
): DisplayConfig => {
    const nextConfig = buildDisplayConfig(sections);
    Object.keys(nextConfig).forEach((id) => {
        if (Object.prototype.hasOwnProperty.call(existing, id)) {
            nextConfig[id] = existing[id];
        }
    });
    return nextConfig;
};

export const filterSectionsByVisibility = (
    sections: NavSectionProps[],
    displayConfig: DisplayConfig
): NavSectionProps[] => {
    const isVisible = (id: string) => displayConfig?.[id] !== false;

    const filterItems = (items: Omit<NavItemProps, 'level'>[]): Omit<NavItemProps, 'level'>[] => {
        return items.reduce<Omit<NavItemProps, 'level'>[]>((acc, item) => {
            if (!isVisible(item.id)) {
                return acc;
            }
            const nextItem: Omit<NavItemProps, 'level'> = { ...item };
            if (item.children) {
                const filteredChildren = filterItems(item.children);
                if (filteredChildren.length) {
                    nextItem.children = filteredChildren;
                } else {
                    delete nextItem.children;
                }
            }
            acc.push(nextItem);
            return acc;
        }, []);
    };

    return sections
        .map((section) => ({
            ...section,
            items: filterItems(section.items),
        }))
        .filter((section) => section.items.length > 0 || Boolean(section.label));
};

export interface SearchFilterResult {
    sections: NavSectionProps[];
    expandedIds: Set<string>;
}

export const filterSectionsBySearch = (
    sections: NavSectionProps[],
    searchText: string
): SearchFilterResult => {
    const query = searchText.trim().toLowerCase();
    const expandedIds = new Set<string>();

    if (!query) {
        return {
            sections,
            expandedIds,
        };
    }

    const filterItems = (items: Omit<NavItemProps, 'level'>[]): Omit<NavItemProps, 'level'>[] => {
        return items.reduce<Omit<NavItemProps, 'level'>[]>((acc, item) => {
            const matchesSelf = item.label.toLowerCase().includes(query);
            let children: Omit<NavItemProps, 'level'>[] | undefined;
            let hasMatchingDescendant = false;

            if (item.children) {
                // First, try to find matching descendants
                const filteredChildren = filterItems(item.children);
                hasMatchingDescendant = filteredChildren.length > 0;

                // If this item matches, include ALL children (not filtered)
                // If descendants match, include only filtered children
                if (matchesSelf) {
                    children = item.children; // Include all children when parent matches
                } else if (hasMatchingDescendant) {
                    children = filteredChildren; // Include only matching children
                }
            }

            // Include this item if:
            // 1. It matches the search query itself, OR
            // 2. It has children that match (directly or nested)
            if (matchesSelf || hasMatchingDescendant) {
                // Only expand if there are matching descendants (not if item itself matches)
                // This ensures parent is expanded to show matching children
                if (hasMatchingDescendant && item.children) {
                    expandedIds.add(item.id);
                }

                acc.push({
                    ...item,
                    ...(children ? { children } : { children: undefined }),
                });
            }
            return acc;
        }, []);
    };

    const filteredSections = sections
        .map((section) => ({
            ...section,
            items: filterItems(section.items),
        }))
        .filter((section) => section.items.length > 0);

    return {
        sections: filteredSections,
        expandedIds,
    };
};
