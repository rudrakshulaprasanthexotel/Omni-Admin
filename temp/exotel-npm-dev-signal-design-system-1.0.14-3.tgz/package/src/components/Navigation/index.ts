import { Navigation, type NavigationProps } from './components/Navigation';
import type { NavSectionProps } from './components/NavSection';

export { Navigation };
export type { NavigationProps, NavSectionProps };