/**
 * ListItemText Component
 * 
 * Exotel-approved list item text component that wraps MUI's ListItemText.
 */

import MuiListItemText, { type ListItemTextProps as MuiListItemTextProps } from '@mui/material/ListItemText';
import { forwardRef } from 'react';

export interface ListItemTextProps extends Omit<MuiListItemTextProps, 'ref'> {
  primary?: React.ReactNode;
  secondary?: React.ReactNode;
}

export const ListItemText = forwardRef<HTMLDivElement, ListItemTextProps>(
  (props, ref) => <MuiListItemText ref={ref} {...props} />
);

ListItemText.displayName = 'ListItemText';
