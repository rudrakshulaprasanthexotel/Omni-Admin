/**
 * List Component
 * 
 * Exotel-approved list component that wraps MUI's List.
 */

import MuiList, { type ListProps as MuiListProps } from '@mui/material/List';
import { forwardRef } from 'react';

export interface ListProps extends Omit<MuiListProps, 'ref'> {
  children?: React.ReactNode;
}

export const List = forwardRef<HTMLUListElement, ListProps>(
  (props, ref) => <MuiList ref={ref} {...props} />
);

List.displayName = 'List';
