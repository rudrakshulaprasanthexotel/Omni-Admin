/**
 * ListItemButton Component
 * 
 * Exotel-approved list item button component that wraps MUI's ListItemButton.
 */

import MuiListItemButton, { type ListItemButtonProps as MuiListItemButtonProps } from '@mui/material/ListItemButton';
import { forwardRef } from 'react';

export interface ListItemButtonProps extends Omit<MuiListItemButtonProps, 'ref'> {
  children?: React.ReactNode;
}

export const ListItemButton = forwardRef<HTMLDivElement, ListItemButtonProps>(
  (props, ref) => <MuiListItemButton ref={ref} {...props} />
);

ListItemButton.displayName = 'ListItemButton';
