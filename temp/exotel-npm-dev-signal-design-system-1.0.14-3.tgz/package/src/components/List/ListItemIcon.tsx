/**
 * ListItemIcon Component
 * 
 * Exotel-approved list item icon component that wraps MUI's ListItemIcon.
 */

import MuiListItemIcon, { type ListItemIconProps as MuiListItemIconProps } from '@mui/material/ListItemIcon';
import { forwardRef } from 'react';

export interface ListItemIconProps extends Omit<MuiListItemIconProps, 'ref'> {
  children?: React.ReactNode;
}

export const ListItemIcon = forwardRef<HTMLDivElement, ListItemIconProps>(
  (props, ref) => <MuiListItemIcon ref={ref} {...props} />
);

ListItemIcon.displayName = 'ListItemIcon';
