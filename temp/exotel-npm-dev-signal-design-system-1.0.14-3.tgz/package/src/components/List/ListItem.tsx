/**
 * ListItem Component
 * 
 * Exotel-approved list item component that wraps MUI's ListItem.
 */

import MuiListItem, { type ListItemProps as MuiListItemProps } from '@mui/material/ListItem';
import { forwardRef } from 'react';

export interface ListItemProps extends Omit<MuiListItemProps, 'ref'> {
  children?: React.ReactNode;
}

export const ListItem = forwardRef<HTMLLIElement, ListItemProps>(
  (props, ref) => <MuiListItem ref={ref} {...props} />
);

ListItem.displayName = 'ListItem';
