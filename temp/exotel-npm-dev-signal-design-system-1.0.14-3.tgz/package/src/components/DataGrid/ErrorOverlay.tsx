import { Box } from '@mui/material';
import { useColorScheme } from '@mui/material/styles';
import { Button } from '../Button';
import { Typography } from '../Typography';
import DefaultErrorSvg from '../../assets/empty.svg';

interface ErrorOverlayProps {
  title?: string;
  message?: string;
  onRefresh?: () => void;
  /** Image shown in light mode. Also used for dark mode (with invert filter) when darkImage is not provided. */
  lightImage?: string;
  /** Image shown in dark mode. When omitted, lightImage is used with an invert filter. */
  darkImage?: string;
}

export function ErrorOverlay({
  title = "Data couldn't be loaded",
  message = "We're having trouble fetching it right now. Please try again.",
  onRefresh,
  lightImage,
  darkImage,
}: ErrorOverlayProps) {
  const { mode } = useColorScheme();
  const isDark = mode === 'dark';

  let src: string;
  let filter: string | undefined;

  if (lightImage && darkImage) {
    src = isDark ? darkImage : lightImage;
  } else if (lightImage) {
    src = lightImage;
    if (isDark) filter = 'invert(1)';
  } else {
    src = DefaultErrorSvg;
    if (isDark) filter = 'invert(1)';
  }

  return (
    <Box
      display="flex"
      flexDirection="column"
      alignItems="center"
      justifyContent="center"
      height="100%"
      gap={1}
    >
      <img
        src={src}
        alt="Error"
        width={100}
        height={80}
        style={filter ? { filter } : undefined}
      />
      <Typography variant="subtitle1" color="text.primary" fontWeight={600} sx={{ mt: 1 }}>
        {title}
      </Typography>
      <Typography variant="body2" color="text.secondary">
        {message}
      </Typography>
      {onRefresh && (
        <Button
          variant="outlined"
          size="small"
          onClick={onRefresh}
          sx={{ mt: 1 }}
        >
          Refresh
        </Button>
      )}
    </Box>
  );
}
