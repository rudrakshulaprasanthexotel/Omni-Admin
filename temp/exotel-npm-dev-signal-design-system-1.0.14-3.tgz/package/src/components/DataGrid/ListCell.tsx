import type { ReactNode } from 'react';
import { Box } from '@mui/material';
import { Typography } from '../Typography';
import { Icon } from '../Icon';
import type { GridRenderCellParams } from '@mui/x-data-grid-pro';
import type { DataGridColDef } from './types';
import type { IconName } from '../Icon';

export interface ListCellConfig {
  /**
   * Field to use as the primary/title display.
   * Defaults to the first displayable column.
   */
  primaryField?: string;
  /**
   * Field to display right-aligned on the primary row (e.g. a date/timestamp).
   */
  secondaryField?: string;
  /**
   * Static icon name to show on the left side of every row.
   */
  iconName?: IconName;
  /**
   * Row field whose value determines the icon name.
   * Takes precedence over `iconName` when the field has a value.
   */
  iconField?: string;
  /**
   * Fields to exclude from display.
   */
  excludeFields?: string[];
  /**
   * Maximum number of detail fields to show below the primary row.
   * All displayable fields are shown when omitted.
   */
  maxFields?: number;
}

export interface ListCellProps {
  params: GridRenderCellParams;
  columns: DataGridColDef[];
  config?: ListCellConfig;
}

const INTERNAL_FIELDS = new Set([
  '__check__',
  '__reorder__',
  '__detail_panel_toggle__',
  '__row_group_by_columns_group__',
  'listCell',
]);

function isDisplayable(col: DataGridColDef, excludeFields: string[]): boolean {
  if (INTERNAL_FIELDS.has(col.field)) return false;
  if ((col as any).type === 'actions') return false;
  if (excludeFields.includes(col.field)) return false;
  return true;
}

function formatValue(value: unknown): string {
  if (value == null || value === '') return '—';
  if (typeof value === 'boolean') return value ? 'Yes' : 'No';
  if (Array.isArray(value)) return value.length ? value.join(', ') : '—';
  if (value instanceof Date) return value.toLocaleDateString();
  if (typeof value === 'object') return JSON.stringify(value);
  return String(value);
}

function renderCellContent(
  col: DataGridColDef,
  listParams: GridRenderCellParams,
): ReactNode {
  if (col.renderCell) {
    const cellParams = {
      ...listParams,
      field: col.field,
      value: listParams.row[col.field],
      colDef: col,
    } as GridRenderCellParams;
    return col.renderCell(cellParams);
  }
  return formatValue(listParams.row[col.field]);
}

export function ListCell({ params, columns, config }: ListCellProps) {
  const { row } = params;
  const {
    primaryField,
    secondaryField,
    iconName,
    iconField,
    excludeFields = [],
    maxFields,
  } = config ?? {};

  const reserved = new Set([primaryField, secondaryField].filter(Boolean));
  const displayable = columns.filter(
    (col) => isDisplayable(col, excludeFields) && !reserved.has(col.field),
  );

  const primaryCol = primaryField
    ? columns.find((col) => col.field === primaryField)
    : displayable[0];

  const secondaryCol = secondaryField
    ? columns.find((col) => col.field === secondaryField)
    : undefined;

  const detailCols = displayable.filter((col) => col !== primaryCol);
  const visibleDetails = maxFields != null ? detailCols.slice(0, maxFields) : detailCols;

  const resolvedIcon = (iconField ? row[iconField] : iconName) as IconName | undefined;

  return (
    <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 1.5, py: 1, width: '100%', overflow: 'hidden' }}>
      {resolvedIcon && (
        <Box sx={{ pt: 0.25, flexShrink: 0, color: 'text.secondary' }}>
          <Icon name={resolvedIcon} size="sm" />
        </Box>
      )}

      <Box sx={{ flex: 1, minWidth: 0 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', flexWrap: 'wrap' }}>
          {primaryCol && (
            primaryCol.renderCell ? (
              <Box sx={{ minWidth: 0, overflow: 'hidden' }}>
                {renderCellContent(primaryCol, params)}
              </Box>
            ) : (
              <Typography variant="subtitle2" noWrap>
                {formatValue(row[primaryCol.field])}
              </Typography>
            )
          )}
          {secondaryCol && (
            secondaryCol.renderCell ? (
              <Box sx={{ flexShrink: 0 }}>
                {renderCellContent(secondaryCol, params)}
              </Box>
            ) : (
              <Typography variant="caption" color="text.secondary" noWrap sx={{ flexShrink: 0 }}>
                {formatValue(row[secondaryCol.field])}
              </Typography>
            )
          )}
        </Box>

        {visibleDetails.length > 0 && (
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.25, mt: 0.25 }}>
            {visibleDetails.map((col) => (
              col.renderCell ? (
                <Box key={col.field} sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                  <Typography variant="caption" color="text.secondary" component="span">
                    {col.headerName ?? col.field}:
                  </Typography>
                  {renderCellContent(col, params)}
                </Box>
              ) : (
                <Typography key={col.field} variant="caption" color="text.secondary" noWrap>
                  {col.headerName ?? col.field}: {formatValue(row[col.field])}
                </Typography>
              )
            ))}
          </Box>
        )}
      </Box>
    </Box>
  );
}
