import { forwardRef } from 'react';
import type { TextFieldProps } from '@mui/material/TextField';
import { EnhancedTextField } from '../../EnhancedTextField';

export type LabelOnlyDateRangeTextFieldProps = TextFieldProps & {
  filterLabel: string;
};

/**
 * DateRangePicker textField slot: always shows the filter category label; the range appears in applied-filters chips only.
 */
export const LabelOnlyDateRangeTextField = forwardRef<HTMLDivElement, LabelOnlyDateRangeTextFieldProps>(
  function LabelOnlyDateRangeTextField({ filterLabel, value: _ignored, ...rest }, ref) {
    return (
      <EnhancedTextField
        ref={ref}
        {...rest}
        showLabel={false}
        value={filterLabel}
        InputProps={{
          ...rest.InputProps,
          readOnly: true,
        }}
      />
    );
  }
);

LabelOnlyDateRangeTextField.displayName = 'LabelOnlyDateRangeTextField';
