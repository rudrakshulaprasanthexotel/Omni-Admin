import { forwardRef, useState, useRef, useCallback, useEffect } from 'react';
import { styled, alpha } from '@mui/material/styles';
import MuiBox from '@mui/material/Box';
import MuiTypography from '@mui/material/Typography';
import MuiIconButton from '@mui/material/IconButton';
import { IconButton } from '../IconButton';
import MuiPopper from '@mui/material/Popper';
import MuiPaper from '@mui/material/Paper';
import MuiList from '@mui/material/List';
import MuiListItemButton from '@mui/material/ListItemButton';
import MuiListItemText from '@mui/material/ListItemText';
import MuiListItemAvatar from '@mui/material/ListItemAvatar';
import MuiAvatar from '@mui/material/Avatar';
import MuiCircularProgress from '@mui/material/CircularProgress';
import MuiClickAwayListener from '@mui/material/ClickAwayListener';
import { Icon } from '../Icon';
import { Chip } from '../Chip';
import type { ChangeEvent, KeyboardEvent as ReactKeyboardEvent } from 'react';

export interface ChatInputAttachment {
  id: string;
  name: string;
  size?: number;
  type?: string;
  file?: File;
}

export interface ChatInputMention {
  id: string;
  label: string;
}

export interface MentionSuggestion {
  id: string;
  label: string;
  secondary?: string;
  avatar?: string;
}

export interface ChatInputBoxProps {
  value?: string;
  onChange?: (value: string) => void;
  onSend?: (value: string, attachments: ChatInputAttachment[], mentions: ChatInputMention[]) => void;
  placeholder?: string;
  maxLength?: number;
  attachments?: ChatInputAttachment[];
  onAttach?: (files: File[]) => void;
  acceptFileTypes?: string;
  allowMultipleFiles?: boolean;
  onRemoveAttachment?: (id: string) => void;
  mentionSuggestions?: MentionSuggestion[];
  onMentionSearch?: (query: string) => void;
  onMentionSelect?: (suggestion: MentionSuggestion) => void;
  mentionLoading?: boolean;
  mentionEmptyText?: string;
  sendDisabled?: boolean;
  disabled?: boolean;
}

interface TrackedMention {
  id: string;
  label: string;
  start: number;
  end: number;
}

// ─── Styled components ───────────────────────────────────────────────

const Root = styled(MuiBox)(({ theme }) => ({
  display: 'flex',
  flexDirection: 'column',
  gap: theme.spacing(1.5),
  alignItems: 'center',
  width: '100%',
  maxWidth: 700,
}));

const InputContainer = styled(MuiBox)(({ theme }) => ({
  display: 'flex',
  flexDirection: 'column',
  gap: theme.spacing(1.5),
  width: '100%',
  backgroundColor: (theme.vars?.palette?.background?.paper as string) || theme.palette.background.paper,
  border: `1px solid ${(theme.vars?.palette?.divider as string) || theme.palette.divider}`,
  borderRadius: 12,
  padding: theme.spacing(1.5),
  boxShadow: `0px 4px 8px -2px ${alpha(theme.palette.common.black, 0.1)}, 0px 2px 4px -2px ${alpha(theme.palette.common.black, 0.06)}`,
  overflow: 'hidden',
  '&:focus-within': {
    borderColor: (theme.vars?.palette?.primary?.main as string) || theme.palette.primary.main,
  },
}));

const AttachmentsArea = styled(MuiBox)(({ theme }) => ({
  display: 'flex',
  flexWrap: 'wrap',
  gap: theme.spacing(0.5),
  padding: theme.spacing(0, 0, 0.5, 0),
}));

const EditableArea = styled('div')(({ theme }) => ({
  width: '100%',
  minHeight: 40,
  maxHeight: 160,
  overflowY: 'auto',
  border: 'none',
  outline: 'none',
  fontFamily: theme.typography.fontFamily,
  fontSize: theme.typography.body2.fontSize,
  lineHeight: theme.typography.body2.lineHeight,
  letterSpacing: theme.typography.body2.letterSpacing,
  color: (theme.vars?.palette?.text?.primary as string) || theme.palette.text.primary,
  backgroundColor: 'transparent',
  padding: 0,
  whiteSpace: 'pre-wrap',
  wordBreak: 'break-word',
  '& .mention-highlight': {
    backgroundColor: theme.vars
      ? `rgba(${theme.vars.palette.primary.mainChannel} / 0.15)`
      : alpha(theme.palette.primary.main, 0.15),
    color: (theme.vars?.palette?.primary?.main as string) || theme.palette.primary.main,
    fontWeight: theme.typography.fontWeightMedium,
    borderRadius: 4,
    padding: '1px 2px',
    whiteSpace: 'nowrap',
  },
  '&:empty::before': {
    content: 'attr(data-placeholder)',
    color: (theme.vars?.palette?.text?.disabled as string) || theme.palette.text.disabled,
    pointerEvents: 'none',
  },
  '&[aria-disabled="true"]': {
    color: (theme.vars?.palette?.text?.disabled as string) || theme.palette.text.disabled,
    cursor: 'not-allowed',
    pointerEvents: 'none',
  },
}));

const BottomBar = styled(MuiBox)(({ theme }) => ({
  display: 'flex',
  flexWrap: 'wrap',
  alignItems: 'center',
  justifyContent: 'flex-end',
  gap: theme.spacing(1),
  minHeight: 28,
  width: '100%',
}));

const BottomActions = styled(MuiBox)(({ theme }) => ({
  display: 'flex',
  flex: '1 0 0',
  flexWrap: 'wrap',
  alignItems: 'center',
  gap: theme.spacing(0.5),
  minWidth: 0,
}));

const SendButton = styled(MuiIconButton, {
  shouldForwardProp: (prop) => prop !== 'isActive',
})<{ isActive?: boolean }>(({ theme, isActive }) => {
  const primaryMain = (theme.vars?.palette?.primary?.main as string) || theme.palette.primary.main;
  const primaryDark = (theme.vars?.palette?.primary?.dark as string) || theme.palette.primary.dark;
  const primaryContrast = (theme.vars?.palette?.primary?.contrastText as string) || theme.palette.primary.contrastText;
  return {
    width: 32,
    height: 32,
    borderRadius: theme.shape.borderRadius,
    backgroundColor: primaryMain,
    color: primaryContrast,
    opacity: isActive ? 1 : 0.25,
    '&:hover': {
      backgroundColor: isActive ? primaryDark : primaryMain,
    },
    '&.Mui-disabled': {
      backgroundColor: primaryMain,
      color: primaryContrast,
      opacity: 0.25,
    },
  };
});

const CharCount = styled(MuiTypography)(({ theme }) => ({
  flex: '1 0 0',
  textAlign: 'right',
  minWidth: 0,
  fontSize: 12,
  lineHeight: '16px',
  color: (theme.vars?.palette?.text?.disabled as string) || theme.palette.text.disabled,
}));

const MentionPopoverPaper = styled(MuiPaper)(({ theme }) => ({
  width: '100%',
  maxHeight: 240,
  overflow: 'auto',
  borderRadius: theme.shape.borderRadius,
  boxShadow: `0px 4px 12px ${alpha(theme.palette.common.black, 0.12)}`,
  border: `1px solid ${(theme.vars?.palette?.divider as string) || theme.palette.divider}`,
}));

const MentionListItem = styled(MuiListItemButton)(({ theme }) => ({
  padding: theme.spacing(0.75, 1.5),
  gap: theme.spacing(1),
  '&.Mui-focusVisible, &.Mui-selected': {
    backgroundColor: theme.vars
      ? `rgba(${theme.vars.palette.primary.mainChannel} / 0.08)`
      : alpha(theme.palette.primary.main, 0.08),
  },
}));

// ─── Cursor helpers ──────────────────────────────────────────────────

function getCursorOffset(container: HTMLElement): number {
  const sel = container.ownerDocument.getSelection();
  if (!sel || sel.rangeCount === 0) return 0;
  const range = sel.getRangeAt(0).cloneRange();
  range.selectNodeContents(container);
  range.setEnd(sel.getRangeAt(0).startContainer, sel.getRangeAt(0).startOffset);
  return range.toString().length;
}

function setCursorOffset(container: HTMLElement, offset: number): void {
  const walker = container.ownerDocument.createTreeWalker(container, NodeFilter.SHOW_TEXT);
  let remaining = offset;
  let node: Node | null;
  while ((node = walker.nextNode())) {
    const len = (node as Text).length;
    if (remaining <= len) {
      const range = container.ownerDocument.createRange();
      range.setStart(node, remaining);
      range.collapse(true);
      const sel = container.ownerDocument.getSelection();
      sel?.removeAllRanges();
      sel?.addRange(range);
      return;
    }
    remaining -= len;
  }
}

// ─── Pure-string helpers ─────────────────────────────────────────────

function escapeHTML(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/\n/g, '<br>');
}

function getMentionQuery(text: string, cursorPos: number): { query: string; atIndex: number } | null {
  const before = text.slice(0, cursorPos);
  const lastAt = before.lastIndexOf('@');
  if (lastAt === -1) return null;
  const charBeforeAt = lastAt > 0 ? before[lastAt - 1] : ' ';
  if (charBeforeAt !== ' ' && charBeforeAt !== '\n' && lastAt !== 0) return null;
  const query = before.slice(lastAt + 1);
  if (query.includes(' ') || query.includes('\n')) return null;
  return { query, atIndex: lastAt };
}

function revalidateMentions(mentions: TrackedMention[], text: string): TrackedMention[] {
  const used = new Set<number>();
  return mentions
    .map((m) => {
      const search = `@${m.label}`;
      let best = -1;
      let bestDist = Infinity;
      let idx = text.indexOf(search);
      while (idx !== -1) {
        if (!used.has(idx)) {
          const dist = Math.abs(idx - m.start);
          if (dist < bestDist) { bestDist = dist; best = idx; }
        }
        idx = text.indexOf(search, idx + 1);
      }
      if (best === -1) return null;
      used.add(best);
      return { ...m, start: best, end: best + search.length };
    })
    .filter((m): m is TrackedMention => m !== null);
}

function buildMentionHTML(text: string, mentions: TrackedMention[]): string {
  if (text.length === 0) return '';
  if (mentions.length === 0) return escapeHTML(text);
  const sorted = [...mentions].sort((a, b) => a.start - b.start);
  let html = '';
  let last = 0;
  for (const m of sorted) {
    if (m.start > last) html += escapeHTML(text.slice(last, m.start));
    html += `<span class="mention-highlight" contenteditable="false">${escapeHTML(text.slice(m.start, m.end))}</span>`;
    last = m.end;
  }
  if (last < text.length) html += escapeHTML(text.slice(last));
  return html;
}

// ─── Component ───────────────────────────────────────────────────────

export const ChatInputBox = forwardRef<HTMLDivElement, ChatInputBoxProps>(
  (
    {
      onChange,
      onSend,
      placeholder = 'Type @ to select processes, campaigns and queues you want to configure',
      maxLength = 200,
      attachments = [],
      onAttach,
      onRemoveAttachment,
      acceptFileTypes,
      allowMultipleFiles = true,
      mentionSuggestions = [],
      onMentionSearch,
      onMentionSelect,
      mentionLoading = false,
      mentionEmptyText = 'No results found',
      sendDisabled,
      disabled = false,
    },
    ref
  ) => {
    const editableRef = useRef<HTMLDivElement>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const inputContainerRef = useRef<HTMLDivElement>(null);

    const [trackedMentions, setTrackedMentions] = useState<TrackedMention[]>([]);
    const [mentionOpen, setMentionOpen] = useState(false);
    const [mentionAtIndex, setMentionAtIndex] = useState(-1);
    const [highlightedIndex, setHighlightedIndex] = useState(0);
    const [charCount, setCharCount] = useState(0);
    const listRef = useRef<HTMLUListElement>(null);

    const isSendActive = !sendDisabled && !disabled && (charCount > 0 || attachments.length > 0);

    useEffect(() => { setHighlightedIndex(0); }, [mentionSuggestions]);

    useEffect(() => {
      if (!listRef.current) return;
      const item = listRef.current.children[highlightedIndex] as HTMLElement | undefined;
      item?.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
    }, [highlightedIndex]);

    const closeMentionPopover = useCallback(() => {
      setMentionOpen(false);
      setMentionAtIndex(-1);
      setHighlightedIndex(0);
    }, []);

    const renderHTML = useCallback((text: string, mentions: TrackedMention[], cursorOffset: number) => {
      const el = editableRef.current;
      if (!el) return;
      el.innerHTML = buildMentionHTML(text, mentions);
      setCursorOffset(el, cursorOffset);
      setCharCount(text.length);
      onChange?.(text);
    }, [onChange]);

    const openMentionPopover = useCallback(() => {
      const el = editableRef.current;
      if (!el) return;
      el.focus();
      const text = el.textContent ?? '';
      const cursor = getCursorOffset(el);
      const newText = text.slice(0, cursor) + '@' + text.slice(cursor);
      const updated = revalidateMentions(trackedMentions, newText);
      setTrackedMentions(updated);
      setMentionOpen(true);
      setMentionAtIndex(cursor);
      setHighlightedIndex(0);
      onMentionSearch?.('');
      renderHTML(newText, updated, cursor + 1);
    }, [trackedMentions, onMentionSearch, renderHTML]);

    const selectMention = useCallback(
      (suggestion: MentionSuggestion) => {
        const el = editableRef.current;
        if (!el || mentionAtIndex < 0) return;
        const text = el.textContent ?? '';
        const cursor = getCursorOffset(el);
        const before = text.slice(0, mentionAtIndex);
        const after = text.slice(cursor);
        const mentionText = `@${suggestion.label}`;
        const newText = before + mentionText + ' ' + after;
        const newMention: TrackedMention = {
          id: suggestion.id,
          label: suggestion.label,
          start: mentionAtIndex,
          end: mentionAtIndex + mentionText.length,
        };
        const updated = revalidateMentions([...trackedMentions, newMention], newText);
        setTrackedMentions(updated);
        onMentionSelect?.(suggestion);
        closeMentionPopover();
        renderHTML(newText, updated, before.length + mentionText.length + 1);
      },
      [mentionAtIndex, trackedMentions, onMentionSelect, closeMentionPopover, renderHTML]
    );

    const handleInput = useCallback(() => {
      const el = editableRef.current;
      if (!el) return;
      const text = el.textContent ?? '';

      if (text.length === 0 && el.innerHTML !== '') {
        el.innerHTML = '';
      }

      const cursor = getCursorOffset(el);
      const updated = revalidateMentions(trackedMentions, text);
      setTrackedMentions(updated);
      setCharCount(text.length);

      const info = getMentionQuery(text, cursor);
      if (info && !updated.some((m) => info.atIndex >= m.start && info.atIndex < m.end)) {
        if (!mentionOpen) { setMentionOpen(true); setHighlightedIndex(0); }
        setMentionAtIndex(info.atIndex);
        onMentionSearch?.(info.query);
      } else if (mentionOpen) {
        closeMentionPopover();
      }

      onChange?.(text);
    }, [trackedMentions, mentionOpen, onChange, onMentionSearch, closeMentionPopover]);

    const handleKeyDown = useCallback(
      (e: ReactKeyboardEvent<HTMLDivElement>) => {
        if (mentionOpen && mentionSuggestions.length > 0) {
          if (e.key === 'ArrowDown') {
            e.preventDefault();
            setHighlightedIndex((prev) => (prev + 1) % mentionSuggestions.length);
            return;
          }
          if (e.key === 'ArrowUp') {
            e.preventDefault();
            setHighlightedIndex((prev) => (prev - 1 + mentionSuggestions.length) % mentionSuggestions.length);
            return;
          }
          if (e.key === 'Enter' || e.key === 'Tab') {
            e.preventDefault();
            selectMention(mentionSuggestions[highlightedIndex]);
            return;
          }
          if (e.key === 'Escape') {
            e.preventDefault();
            closeMentionPopover();
            return;
          }
        }

        if (e.key === 'Backspace') {
          const el = editableRef.current;
          if (!el) return;
          const text = el.textContent ?? '';
          const cursor = getCursorOffset(el);

          const mentionBefore = trackedMentions.find((m) => m.end === cursor);
          if (mentionBefore) {
            e.preventDefault();
            const newText = text.slice(0, mentionBefore.start) + text.slice(mentionBefore.end);
            const updated = revalidateMentions(
              trackedMentions.filter((m) => m !== mentionBefore),
              newText
            );
            setTrackedMentions(updated);
            renderHTML(newText, updated, mentionBefore.start);
            return;
          }
        }

        if (e.key === 'Enter' && !e.shiftKey) {
          e.preventDefault();
          if (isSendActive && editableRef.current) {
            const text = editableRef.current.textContent ?? '';
            const mentions = trackedMentions.map((m) => ({ id: m.id, label: m.label }));
            onSend?.(text, attachments, mentions);
          }
        }
      },
      [mentionOpen, mentionSuggestions, highlightedIndex, selectMention, closeMentionPopover, isSendActive, onSend, attachments, trackedMentions, renderHTML]
    );

    const handlePaste = useCallback(
      (e: React.ClipboardEvent<HTMLDivElement>) => {
        const files = e.clipboardData?.files;
        if (files && files.length > 0 && onAttach) {
          e.preventDefault();
          onAttach(Array.from(files));
          return;
        }
        e.preventDefault();
        const plain = e.clipboardData.getData('text/plain');
        document.execCommand('insertText', false, plain);
      },
      [onAttach]
    );

    const handleSend = useCallback(() => {
      if (isSendActive && editableRef.current) {
        const text = editableRef.current.textContent ?? '';
        const mentions = trackedMentions.map((m) => ({ id: m.id, label: m.label }));
        onSend?.(text, attachments, mentions);
      }
    }, [isSendActive, onSend, attachments, trackedMentions]);

    const handleAttachClick = useCallback(() => { fileInputRef.current?.click(); }, []);

    const handleFileChange = useCallback(
      (e: ChangeEvent<HTMLInputElement>) => {
        const files = e.target.files;
        if (files && files.length > 0 && onAttach) onAttach(Array.from(files));
        if (fileInputRef.current) fileInputRef.current.value = '';
      },
      [onAttach]
    );

    return (
      <Root ref={ref}>
        <input
          ref={fileInputRef}
          type="file"
          hidden
          accept={acceptFileTypes}
          multiple={allowMultipleFiles}
          onChange={handleFileChange}
        />
        <InputContainer ref={inputContainerRef}>
          {attachments.length > 0 && (
            <AttachmentsArea>
              {attachments.map((attachment) => (
                <Chip
                  key={attachment.id}
                  label={attachment.name}
                  size="small"
                  onDelete={onRemoveAttachment ? () => onRemoveAttachment(attachment.id) : undefined}
                  icon={<Icon name="paperclip" size="xs" />}
                />
              ))}
            </AttachmentsArea>
          )}

          <EditableArea
            ref={editableRef}
            contentEditable={!disabled}
            aria-disabled={disabled || undefined}
            data-placeholder={placeholder}
            role="textbox"
            aria-multiline="true"
            aria-label="Message input"
            onInput={handleInput}
            onKeyDown={handleKeyDown}
            onPaste={handlePaste}
            suppressContentEditableWarning
          />

          <BottomBar>
            <BottomActions>
              <MuiBox sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
                <IconButton size="small" variant="outlined" shape="square" onClick={handleAttachClick} disabled={disabled} aria-label="Attach file">
                  <Icon name="paperclip" size="sm" />
                </IconButton>
                <IconButton size="small" variant="outlined" shape="square" onClick={openMentionPopover} disabled={disabled} aria-label="Mention">
                  <Icon name="at" size="sm" />
                </IconButton>
              </MuiBox>
              <CharCount>{charCount}/{maxLength}</CharCount>
            </BottomActions>
            <SendButton isActive={isSendActive} onClick={handleSend} disabled={!isSendActive} aria-label="Send message">
              <Icon name="arrow-up" size="sm" weight="bold" />
            </SendButton>
          </BottomBar>
        </InputContainer>

        <MuiPopper
          open={mentionOpen}
          anchorEl={inputContainerRef.current}
          placement="top-start"
          style={{ width: inputContainerRef.current?.offsetWidth, zIndex: 1300 }}
          modifiers={[{ name: 'offset', options: { offset: [0, 4] } }]}
        >
          <MuiClickAwayListener onClickAway={closeMentionPopover}>
            <MentionPopoverPaper>
              {mentionLoading ? (
                <MuiBox sx={{ display: 'flex', justifyContent: 'center', p: 2 }}>
                  <MuiCircularProgress size={24} />
                </MuiBox>
              ) : mentionSuggestions.length === 0 ? (
                <MuiBox sx={{ p: 2, textAlign: 'center' }}>
                  <MuiTypography variant="body2" color="text.secondary">{mentionEmptyText}</MuiTypography>
                </MuiBox>
              ) : (
                <MuiList ref={listRef} disablePadding>
                  {mentionSuggestions.map((suggestion, index) => (
                    <MentionListItem
                      key={suggestion.id}
                      selected={index === highlightedIndex}
                      onClick={() => selectMention(suggestion)}
                      onMouseEnter={() => setHighlightedIndex(index)}
                    >
                      <MuiListItemAvatar sx={{ minWidth: 36 }}>
                        <MuiAvatar src={suggestion.avatar} sx={{ width: 28, height: 28, fontSize: 12 }}>
                          {suggestion.label.charAt(0).toUpperCase()}
                        </MuiAvatar>
                      </MuiListItemAvatar>
                      <MuiListItemText
                        primary={suggestion.label}
                        secondary={suggestion.secondary}
                        primaryTypographyProps={{ variant: 'body2' }}
                        secondaryTypographyProps={{ variant: 'caption' }}
                      />
                    </MentionListItem>
                  ))}
                </MuiList>
              )}
            </MentionPopoverPaper>
          </MuiClickAwayListener>
        </MuiPopper>
      </Root>
    );
  }
);

ChatInputBox.displayName = 'ChatInputBox';
