/**
 * Tab Component
 *
 * Exotel-approved tab component that wraps MUI's Tab.
 * Accepts `iconProps` to render a design-system `Icon` instead of
 * requiring raw JSX in the `icon` prop.
 * Accepts `badge` to render an inline Badge next to the label.
 */

import MuiTab, { type TabProps as MuiTabProps } from '@mui/material/Tab';
import { forwardRef } from 'react';
import { Badge } from '../Badge';
import { Icon, type IconProps } from '../Icon';

export interface TabProps extends Omit<MuiTabProps, 'ref' | 'icon'> {
  /**
   * Raw icon element.
   * @deprecated Use `iconProps` instead for consistent design-system Icon usage.
   */
  icon?: React.ReactElement;
  /**
   * Props forwarded to the design-system `Icon` component.
   * When provided, renders `<Icon {...iconProps} />` as the tab icon.
   */
  iconProps?: IconProps;
  /**
   * Badge content (number or string) displayed inline next to the label.
   * Renders a small error-colored Badge matching the Figma spec.
   */
  badge?: React.ReactNode;
}

export const Tab = forwardRef<HTMLDivElement, TabProps>(
  ({ iconProps, icon, badge, label, ...props }, ref) => {
    const resolvedIcon = iconProps?.name
      ? <Icon {...iconProps} />
      : icon;

    const resolvedLabel = badge != null
      ? <Badge badgeContent={badge} color="error">{label}</Badge>
      : label;

    return (
      <MuiTab
        ref={ref}
        {...(resolvedIcon ? { icon: resolvedIcon } : {})}
        label={resolvedLabel}
        {...props}
      />
    );
  },
);

Tab.displayName = 'Tab';
