/**
 * Tabs Component
 * 
 * Exotel-approved tabs component that wraps MUI's Tabs.
 * Supports a "button" tabStyle for segmented-control / pill-style tabs
 * and a "topIcon" tabStyle for icon-above-label tabs with a rounded content-width indicator.
 */

import MuiTabs, { type TabsProps as MuiTabsProps } from '@mui/material/Tabs';
import { forwardRef } from 'react';

export interface TabsProps extends Omit<MuiTabsProps, 'ref'> {
  children?: React.ReactNode;
  value?: string | number;
  onChange?: (event: React.SyntheticEvent, newValue: string | number) => void;
  /** Visual style of the tabs. "button" renders a segmented-control / pill appearance. "topIcon" renders icon-above-label tabs with a rounded, content-width indicator. */
  tabStyle?: 'default' | 'button' | 'topIcon';
}

export const Tabs = forwardRef<HTMLDivElement, TabsProps>(
  ({ tabStyle = 'default', ...props }, ref) => (
    <MuiTabs
      ref={ref}
      {...(tabStyle !== 'default' && { 'data-variant': tabStyle })}
      {...props}
    />
  ),
);

Tabs.displayName = 'Tabs';
