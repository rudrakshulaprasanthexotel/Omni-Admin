/**
 * MultiSelect Component
 * 
 * Multi-select dropdown with grouped options support
 */

export { MultiSelect } from './MultiSelect';
export type { MultiSelectProps, MultiSelectOption } from './MultiSelect';
