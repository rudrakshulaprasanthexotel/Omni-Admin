/**
 * Checkbox Component
 * 
 * Exports the Exotel Checkbox component that wraps MUI's Checkbox.
 */

export { Checkbox } from './Checkbox';
export type { CheckboxProps } from './Checkbox';
