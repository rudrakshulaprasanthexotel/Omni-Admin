/**
 * Table Component
 * 
 * Exotel-approved table component that wraps MUI's Table.
 */

import MuiTable, { type TableProps as MuiTableProps } from '@mui/material/Table';
import { forwardRef } from 'react';

export interface TableProps extends Omit<MuiTableProps, 'ref'> {
  children?: React.ReactNode;
}

export const Table = forwardRef<HTMLTableElement, TableProps>(
  (props, ref) => <MuiTable ref={ref} {...props} />
);

Table.displayName = 'Table';
