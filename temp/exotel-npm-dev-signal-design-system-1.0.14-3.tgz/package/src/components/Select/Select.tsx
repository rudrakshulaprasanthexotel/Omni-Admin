/**
 * Select Component
 * 
 * Exotel-approved select component that wraps MUI's Select.
 */

import MuiSelect, { type SelectProps as MuiSelectProps } from '@mui/material/Select';
import { forwardRef } from 'react';

export interface SelectProps extends Omit<MuiSelectProps, 'ref'> {
  children?: React.ReactNode;
  value?: unknown;
}

export const Select = forwardRef<HTMLDivElement, SelectProps>(
  (props, ref) => <MuiSelect ref={ref} {...props} />
);

Select.displayName = 'Select';
