// url=https://www.figma.com/design/CiTSqZD3DKtMu91owRSkZW/Signal-Design-System?node-id=6583-46084
// source=src/components/Accordion/Accordion.tsx
// component=Accordion
// Selection https://www.figma.com/design/CiTSqZD3DKtMu91owRSkZW/Signal-Design-System?node-id=166-118828 maps to this <Accordion> (main: 6583:46084).
import figma from 'figma';

const instance = figma.selectedInstance;

const disabled = instance.getEnum('Disabled', {
  False: false,
  True: true,
});

const expanded = instance.getEnum('Expanded?', {
  False: false,
  True: true,
});

const firstOfType = instance.getEnum('First-of-type', {
  False: false,
  True: true,
});

const lastOfType = instance.getEnum('Last-of-type', {
  False: false,
  True: true,
});

const titleNode = instance.findText('body1');
let summaryText = 'Section title';
if (titleNode && titleNode.type === 'TEXT') {
  summaryText = titleNode.textContent;
}

const detailsSwap = instance.getInstanceSwap('↳ Instance');
let detailsSnippet;
if (detailsSwap && detailsSwap.type === 'INSTANCE' && detailsSwap.hasCodeConnect()) {
  detailsSnippet = detailsSwap.executeTemplate().example;
}

export default {
  example: figma.code`
    <Accordion
      disabled={${disabled}}
      defaultExpanded={${expanded}}
    >
      <AccordionSummary>
        <Typography>${summaryText}</Typography>
      </AccordionSummary>
      <AccordionDetails>
        ${detailsSnippet ? figma.code`${detailsSnippet}` : figma.code`<Typography>Panel content</Typography>`}
      </AccordionDetails>
    </Accordion>
  `,
  imports: [
    'import { Accordion, AccordionSummary, AccordionDetails, Typography } from "@exotel-npm-dev/signal-design-system"',
  ],
  id: 'accordion',
  metadata: {
    nestable: true,
    props: {
      firstOfType,
      lastOfType,
    },
  },
};
