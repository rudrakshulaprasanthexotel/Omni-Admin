/**
 * Accordion Component
 * 
 * Exotel-approved accordion component that wraps MUI's Accordion.
 */

import MuiAccordion, { type AccordionProps as MuiAccordionProps } from '@mui/material/Accordion';
import { forwardRef } from 'react';

export interface AccordionProps extends Omit<MuiAccordionProps, 'ref'>{};

export const Accordion = forwardRef<HTMLDivElement, AccordionProps>(
  (props, ref) => <MuiAccordion ref={ref} {...props} />
);

Accordion.displayName = 'Accordion';
