/**
 * FormControl Component
 * 
 * Exotel-approved form control component that wraps MUI's FormControl.
 */

import MuiFormControl, { type FormControlProps as MuiFormControlProps } from '@mui/material/FormControl';
import { forwardRef } from 'react';

export interface FormControlProps extends Omit<MuiFormControlProps, 'ref'> {
  children?: React.ReactNode;
}

export const FormControl = forwardRef<HTMLDivElement, FormControlProps>(
  (props, ref) => <MuiFormControl ref={ref} {...props} />
);

FormControl.displayName = 'FormControl';
