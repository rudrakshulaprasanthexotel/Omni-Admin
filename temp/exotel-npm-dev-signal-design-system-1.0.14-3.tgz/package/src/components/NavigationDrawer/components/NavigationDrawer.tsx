import { useState } from "react";
import { Navigation } from "../../Navigation/components/Navigation"
import type { NavigationProps } from "../../Navigation/components/Navigation"
import { Drawer } from "../../Drawer";
import { IconButton } from "../../IconButton";
import { Icon } from "../../Icon";

export interface NavigationDrawerProps {
    items: NavigationProps['items'];
}

export const NavigationDrawer = (props: NavigationDrawerProps) => {
    const { items } = props;

    const [ isOpen, setIsOpen ] = useState(false);

    return (
        <>
            <IconButton onClick={() => setIsOpen(true)}>
                <Icon name='menu' size='sm' />
            </IconButton>
            <Drawer open={isOpen} onClose={() => setIsOpen(false)}>
                <Navigation staticSidebar={true} items={items} />
            </Drawer>
        </>
    )
};
