import { memo } from 'react';
import { Handle, Position, type NodeProps } from '@xyflow/react';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import { styled, alpha } from '@mui/material/styles';
import type { ActionNodeData } from '../types';

const STATUS_COLOR_MAP = {
  default: 'grey',
  success: 'success',
  error: 'error',
  warning: 'warning',
  info: 'info',
} as const;

interface StyledRootProps {
  ownerState: { selected: boolean; status: ActionNodeData['status'] };
}

const Root = styled(Box, {
  shouldForwardProp: (p) => p !== 'ownerState',
})<StyledRootProps>(({ theme, ownerState }) => {
  const colorKey = STATUS_COLOR_MAP[ownerState.status ?? 'default'];
  const palette = theme.palette[colorKey] ?? theme.palette.grey;
  const borderColor = ownerState.selected
    ? theme.palette.primary.main
    : theme.palette.divider;

  return {
    display: 'flex',
    alignItems: 'center',
    gap: theme.spacing(1),
    padding: theme.spacing(1, 1.5),
    minWidth: 180,
    borderRadius: theme.shape.borderRadius,
    border: `1.5px solid ${borderColor}`,
    backgroundColor: theme.palette.background.paper,
    boxShadow: ownerState.selected ? theme.shadows[4] : theme.shadows[1],
    transition: theme.transitions.create(['box-shadow', 'border-color'], {
      duration: theme.transitions.duration.short,
    }),
    '&:hover': {
      boxShadow: theme.shadows[3],
    },
    ...(ownerState.status && ownerState.status !== 'default' && {
      borderLeftWidth: 4,
      borderLeftColor: (palette as any).main ?? (palette as any)[500],
    }),
  };
});

const IconWrapper = styled(Box)(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  width: 32,
  height: 32,
  borderRadius: theme.shape.borderRadius,
  backgroundColor: alpha(theme.palette.primary.main, 0.08),
  color: theme.palette.primary.main,
  flexShrink: 0,
}));

function ActionNodeComponent({ data, selected = false }: NodeProps) {
  const { label, description, icon, status } = data as ActionNodeData;

  return (
    <>
      <Handle type="target" position={Position.Top} />
      <Root ownerState={{ selected, status }}>
        {icon && (
          <IconWrapper>
            <Typography variant="body2" component="span">{icon}</Typography>
          </IconWrapper>
        )}
        <Box sx={{ overflow: 'hidden' }}>
          <Typography
            variant="label2"
            noWrap
            sx={{ display: 'block', color: 'text.primary' }}
          >
            {label}
          </Typography>
          {description && (
            <Typography
              variant="body3"
              noWrap
              sx={{ color: 'text.secondary' }}
            >
              {description}
            </Typography>
          )}
        </Box>
      </Root>
      <Handle type="source" position={Position.Bottom} />
    </>
  );
}

export const ActionNode = memo(ActionNodeComponent);
