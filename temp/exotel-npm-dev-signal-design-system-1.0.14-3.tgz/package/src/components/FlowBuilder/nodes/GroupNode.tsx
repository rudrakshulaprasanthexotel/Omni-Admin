import { memo } from 'react';
import { type NodeProps } from '@xyflow/react';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import { styled, alpha } from '@mui/material/styles';
import type { GroupNodeData } from '../types';

interface StyledRootProps {
  ownerState: { selected: boolean };
}

const Root = styled(Box, {
  shouldForwardProp: (p) => p !== 'ownerState',
})<StyledRootProps>(({ theme, ownerState }) => ({
  width: '100%',
  height: '100%',
  borderRadius: Number(theme.shape.borderRadius) * 1.5,
  border: `1.5px dashed ${ownerState.selected ? theme.palette.primary.main : theme.palette.divider}`,
  backgroundColor: alpha(theme.palette.primary.main, 0.03),
  padding: theme.spacing(0.5),
}));

function GroupNodeComponent({ data, selected = false }: NodeProps) {
  const { label } = data as GroupNodeData;

  return (
    <Root ownerState={{ selected }}>
      <Typography
        variant="title1"
        sx={{ color: 'text.secondary', px: 1, py: 0.25 }}
      >
        {label}
      </Typography>
    </Root>
  );
}

export const GroupNode = memo(GroupNodeComponent);
