import { memo } from 'react';
import { Handle, Position, type NodeProps } from '@xyflow/react';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Chip from '@mui/material/Chip';
import { styled, alpha } from '@mui/material/styles';
import type { ConditionNodeData } from '../types';

interface StyledRootProps {
  ownerState: { selected: boolean };
}

const Root = styled(Box, {
  shouldForwardProp: (p) => p !== 'ownerState',
})<StyledRootProps>(({ theme, ownerState }) => ({
  display: 'flex',
  flexDirection: 'column',
  gap: theme.spacing(0.75),
  padding: theme.spacing(1, 1.5),
  minWidth: 180,
  maxWidth: 260,
  borderRadius: theme.shape.borderRadius,
  border: `1.5px solid ${ownerState.selected ? theme.palette.primary.main : theme.palette.divider}`,
  backgroundColor: theme.palette.background.paper,
  boxShadow: ownerState.selected ? theme.shadows[4] : theme.shadows[1],
  transition: theme.transitions.create(['box-shadow', 'border-color'], {
    duration: theme.transitions.duration.short,
  }),
  '&:hover': {
    boxShadow: theme.shadows[3],
  },
}));

const DiamondBadge = styled(Box)(({ theme }) => ({
  width: 20,
  height: 20,
  transform: 'rotate(45deg)',
  borderRadius: 4,
  backgroundColor: alpha(theme.palette.warning.main, 0.15),
  border: `1.5px solid ${theme.palette.warning.main}`,
  flexShrink: 0,
}));

function ConditionNodeComponent({ data, selected = false }: NodeProps) {
  const { label, description, conditions } = data as ConditionNodeData;

  return (
    <>
      <Handle type="target" position={Position.Top} />
      <Root ownerState={{ selected }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <DiamondBadge />
          <Typography variant="label2" noWrap sx={{ color: 'text.primary' }}>
            {label}
          </Typography>
        </Box>
        {description && (
          <Typography variant="body3" sx={{ color: 'text.secondary' }}>
            {description}
          </Typography>
        )}
        {conditions && conditions.length > 0 && (
          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5, mt: 0.25 }}>
            {conditions.map((c) => (
              <Chip key={c} label={c} size="small" variant="outlined" />
            ))}
          </Box>
        )}
      </Root>
      <Handle type="source" position={Position.Bottom} id="yes" style={{ left: '30%' }} />
      <Handle type="source" position={Position.Bottom} id="no" style={{ left: '70%' }} />
    </>
  );
}

export const ConditionNode = memo(ConditionNodeComponent);
