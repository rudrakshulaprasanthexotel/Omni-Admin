import { memo } from 'react';
import { Controls, type ControlProps } from '@xyflow/react';

export interface FlowControlsProps extends ControlProps {}

/**
 * Thin wrapper around React Flow's `<Controls />`.
 * Inherits Exotel theme via CSS variables set on the parent FlowBuilder.
 */
function FlowControlsComponent(props: FlowControlsProps) {
  return <Controls {...props} />;
}

export const FlowControls = memo(FlowControlsComponent);
