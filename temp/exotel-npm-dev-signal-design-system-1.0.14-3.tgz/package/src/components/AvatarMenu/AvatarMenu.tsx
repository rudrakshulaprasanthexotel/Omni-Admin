import { useCallback, useRef, useState } from 'react';
import MuiMenuItem from '@mui/material/MenuItem';
import { Box } from '../Box';
import { Divider } from '../Divider';
import { Icon } from '../Icon';
import { ListItemIcon, ListItemText } from '../List';
import { Menu } from '../Menu';
import { Typography } from '../Typography';
import { AvatarMenuTrigger } from './AvatarMenuTrigger';
import { AvatarMenuHeader } from './AvatarMenuHeader';
import { AvatarMenuGroupItems } from './AvatarMenuGroupItems';
import { ThemeSubmenu } from './ThemeSubmenu';
import { menuItemSx } from './constants';
import type { AvatarMenuProps } from './types';

export function AvatarMenu({
  avatarName,
  menuGroups,
  footerInfo,
  selectedTheme,
  size = 'small',
  onThemeChange,
  onLogout,
}: AvatarMenuProps): React.ReactElement {
  const [anchorEl, setAnchorEl] = useState<HTMLDivElement | null>(null);
  const [themeAnchorEl, setThemeAnchorEl] = useState<HTMLElement | null>(null);
  const themeRowRef = useRef<HTMLLIElement>(null);
  const open = Boolean(anchorEl);

  const handleOpen = useCallback((event: React.MouseEvent<HTMLDivElement>) => {
    setAnchorEl(event.currentTarget);
  }, []);

  const handleClose = useCallback(() => {
    setAnchorEl(null);
    setThemeAnchorEl(null);
  }, []);

  const handleKeyDown = useCallback((e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      setAnchorEl(e.currentTarget);
    }
  }, []);

  const handleThemeRowClick = () => {
    setThemeAnchorEl(themeRowRef.current);
  };

  const handleThemeSubmenuClose = () => {
    setThemeAnchorEl(null);
  };

  return (
    <>
      <AvatarMenuTrigger
        avatarName={avatarName}
        size={size}
        open={open}
        onOpen={handleOpen}
        onKeyDown={handleKeyDown}
      />

      <Menu
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
        transformOrigin={{ vertical: 'top', horizontal: 'right' }}
        slotProps={{
          paper: {
            sx: { width: 230 },
          },
        }}
      >
        <AvatarMenuHeader avatarName={avatarName} />

        {menuGroups.map((group) => (
          <Box key={group.id}>
            <AvatarMenuGroupItems group={group} onClose={handleClose} />
            <Divider sx={{ marginBlock: '2px !important' }} />
          </Box>
        ))}

        {/* Theme — constant, opens submenu to the left */}
        <MuiMenuItem
          ref={themeRowRef}
          onClick={handleThemeRowClick}
          sx={{
            ...menuItemSx,
            bgcolor: Boolean(themeAnchorEl) ? 'action.selected' : undefined,
          }}
        >
          <ListItemText slotProps={{ primary: { variant: 'body2' } }}>
            Theme
          </ListItemText>
          <Icon name="caret-right" size="sm" color="currentColor" />
        </MuiMenuItem>

        <Divider sx={{ marginBlock: '2px !important' }} />

        {/* Logout — constant */}
        <MuiMenuItem
          onClick={() => { handleClose(); onLogout(); }}
          sx={menuItemSx}
        >
          <ListItemIcon sx={{ minWidth: 28 }}>
            <Icon name="sign-out" size="sm" color="currentColor" />
          </ListItemIcon>
          <ListItemText slotProps={{ primary: { variant: 'body2' } }}>
            Logout
          </ListItemText>
        </MuiMenuItem>

        {footerInfo.length > 0 && (
          <Box sx={{ px: 2, pb: 1.5, pt: 0.25 }}>
            {footerInfo.map((row) => (
              <Typography
                key={row.label}
                variant="caption"
                color="text.secondary"
                display="block"
              >
                {row.label} : {row.value}
              </Typography>
            ))}
          </Box>
        )}
      </Menu>

      {/* Rendered outside Menu so it isn't clipped by the Menu paper */}
      <ThemeSubmenu
        anchorEl={themeAnchorEl}
        selectedTheme={selectedTheme}
        onSelect={onThemeChange}
        onClose={handleThemeSubmenuClose}
      />
    </>
  );
}

AvatarMenu.displayName = 'AvatarMenu';
