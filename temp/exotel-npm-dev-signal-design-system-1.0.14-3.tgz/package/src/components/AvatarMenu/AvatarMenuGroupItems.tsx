import MuiMenuItem from '@mui/material/MenuItem';
import { Icon } from '../Icon';
import { ListItemIcon, ListItemText } from '../List';
import { menuItemSx } from './constants';
import type { AvatarMenuGroup, AvatarMenuItem } from './types';

interface AvatarMenuGroupItemsProps {
  group: AvatarMenuGroup;
  onClose: () => void;
}

export function AvatarMenuGroupItems({ group, onClose }: AvatarMenuGroupItemsProps) {
  return (
    <>
      {group.items.map((item: AvatarMenuItem) => (
        <MuiMenuItem
          key={item.id}
          disabled={item.disabled}
          onClick={() => { onClose(); item.onClick(); }}
          sx={menuItemSx}
        >
          {item.icon && (
            <ListItemIcon sx={{ minWidth: 28 }}>
              <Icon name={item.icon} size="sm" color="currentColor" />
            </ListItemIcon>
          )}
          <ListItemText slotProps={{ primary: { variant: 'body2' } }}>
            {item.label}
          </ListItemText>
        </MuiMenuItem>
      ))}
    </>
  );
}
