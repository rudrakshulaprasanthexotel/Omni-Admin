/**
 * Input Component
 * 
 * Exotel-approved input component that wraps MUI's Input.
 */

import MuiInput, { type InputProps as MuiInputProps } from '@mui/material/Input';
import { forwardRef } from 'react';

export interface InputProps extends Omit<MuiInputProps, 'ref'> {
  value?: string | number;
}

export const Input = forwardRef<HTMLInputElement, InputProps>(
  (props, ref) => <MuiInput ref={ref} {...props} />
);

Input.displayName = 'Input';
