/**
 * Box Component
 * 
 * Exotel-approved box component that wraps MUI's Box.
 */

import MuiBox, { type BoxProps as MuiBoxProps } from '@mui/material/Box';
import { forwardRef } from 'react';

export interface BoxProps extends Omit<MuiBoxProps, 'ref'> {
  children?: React.ReactNode;
}

export const Box = forwardRef<HTMLDivElement, BoxProps>(
  (props, ref) => <MuiBox ref={ref} {...props} />
);

Box.displayName = 'Box';
