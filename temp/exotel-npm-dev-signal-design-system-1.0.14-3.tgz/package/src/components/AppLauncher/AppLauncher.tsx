import { useCallback, useMemo, useState } from 'react';
import Box from '@mui/material/Box';
import { useTheme } from '@mui/material/styles';
import { Icon } from '../Icon';
import { IconButton } from '../IconButton';
import { Popover } from '../Popover';
import { layoutStrategies } from './layoutStrategies';
import type { AppLauncherProps } from './types';

const POPOVER_WIDTH = 330;
const POPOVER_MAX_HEIGHT = 360;
const ARIA_LABEL_TRIGGER = 'Open app launcher';

/**
 * Pure render-only App Launcher. No business logic, no navigation, no fallbacks.
 * Renders icon button + popover; emits onProductClick(product). Host owns data and click behavior.
 */
const DEFAULT_ICON_NAME = 'squares-four';

export function AppLauncher({
  type,
  products,
  iconName = DEFAULT_ICON_NAME,
}: AppLauncherProps): React.ReactElement {
  const theme = useTheme();
  const [anchorEl, setAnchorEl] = useState<HTMLButtonElement | null>(null);
  const open = Boolean(anchorEl);

  const handleOpen = useCallback((event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
  }, []);

  const handleClose = useCallback(() => {
    setAnchorEl(null);
  }, []);

  const handleKeyDown = useCallback(
    (event: React.KeyboardEvent) => {
      if (event.key === 'Escape') handleClose();
    },
    [handleClose]
  );

  const layoutContent = useMemo(
    () => {
      console.log('+++++++++++type', type, layoutStrategies, layoutStrategies[type]);
      return layoutStrategies[type]({
        products,
        layout: type,
        theme,
        handleClose,
      })
    },
    [type, products, theme]
  );

  return (
    <>
      <IconButton
        onClick={handleOpen}
        aria-label={ARIA_LABEL_TRIGGER}
        aria-expanded={open}
        aria-haspopup="true"
        sx={(theme) => ({
          color: theme.palette.common.black,
          backgroundColor: theme.palette.common.white,
          '&:hover': { backgroundColor: theme.palette.common.white },
          '&:focus-visible': {
            outline: `2px solid ${theme.palette.primary.main}`,
            outlineOffset: 2,
          },
          ...theme.applyStyles('dark', {
            color: theme.palette.common.white,
            backgroundColor: theme.palette.common.black,
            '&:hover': { backgroundColor: theme.palette.common.black },
          }),
        })}
      >
        <Icon name={iconName} size="md" color="currentColor" />
      </IconButton>
      <Popover
        open={open}
        anchorEl={anchorEl}
        onClose={handleClose}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
        transformOrigin={{ vertical: 'top', horizontal: 'right' }}
        slotProps={{
          paper: {
            elevation: 8,
            sx: {
              width: POPOVER_WIDTH,
              maxWidth: 'calc(100vw - 24px)',
              maxHeight: POPOVER_MAX_HEIGHT,
              mt: 1.5,
              borderRadius: 2,
              overflow: 'hidden',
            },
          },
        }}
        onKeyDown={handleKeyDown}
      >
        <Box sx={{ overflow: 'auto', maxHeight: POPOVER_MAX_HEIGHT }}>
          {layoutContent}
        </Box>
      </Popover>
    </>
  );
}
