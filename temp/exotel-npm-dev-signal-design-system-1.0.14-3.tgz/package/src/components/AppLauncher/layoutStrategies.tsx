import Box from '@mui/material/Box';
import List from '@mui/material/List';
import ListSubheader from '@mui/material/ListSubheader';
import Typography from '@mui/material/Typography';
import type { Theme } from '@mui/material/styles';
import type { LayoutMode, Product } from './types';
import { ProductItem } from './ProductItem';
import { groupBySection } from './grouping';

export interface LayoutContext {
  products: Product[];
  layout: LayoutMode;
  theme: Theme;
  handleClose: () => void;
}

function sortByOrder(products: Product[]): Product[] {
  return [...products].sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
}

function handleProductClick(product: Product, handleClose: () => void): void {
  product.onProductClick();
  handleClose();
}

function renderProductRow(
  product: Product,
  handleClose: () => void,
): React.ReactElement {
  return (
    <ProductItem key={product.id} product={product} onClick={() => handleProductClick(product, handleClose)} />
  );
}

/** Default layout: flat list of products, sorted by optional order. */
export function renderDefaultLayout(ctx: LayoutContext): React.ReactElement {
  const { products, handleClose } = ctx;
  const sorted = sortByOrder(products);

  return (
    <List component="div" disablePadding sx={{ py: 0.5 }}>
      {sorted.map((product) => renderProductRow(product, handleClose))}
    </List>
  );
}

/** Sectioned layout: group by section, render section subheader then products. Section order = key order. */
export function renderSectionedLayout(ctx: LayoutContext): React.ReactElement {
  const { products, handleClose } = ctx;

  const sectionedGroups = groupBySection(products);
  const sectionKeys = Object.keys(sectionedGroups);
  return (
    <Box component="div" sx={{ display: 'block' }}>
      {sectionKeys.map((sectionKey, index) => {
        const sectionProducts = sectionedGroups[sectionKey];
        if (!sectionProducts?.length) return null;
        return (
          <List
            key={sectionKey}
            disablePadding
            subheader={
              <ListSubheader
                component="div"
                disableSticky
                sx={{
                  px: 1.5,
                  py: 0.75,
                  lineHeight: 1.5,
                  backgroundColor: 'transparent',
                }}
              >
                <Typography
                  variant="label2"
                  sx={(t) => ({
                    fontWeight: 600,
                    letterSpacing: '0.5px',
                    color: t.palette.text.secondary,
                    textTransform: 'uppercase',
                    ...t.applyStyles('dark', { color: t.palette.common.white }),
                  })}
                >
                  {sectionKey}
                </Typography>
              </ListSubheader>
            }
            sx={{ pt: index === 0 ? 0 : 0.5 }}
          >
            {sectionProducts.map((product) =>
              renderProductRow(product, handleClose)
            )}
          </List>
        );
      })}
    </Box>
  );
}

export const layoutStrategies: Record<LayoutMode, (ctx: LayoutContext) => React.ReactElement> = {
  default: renderDefaultLayout,
  sectioned: renderSectionedLayout,
};
