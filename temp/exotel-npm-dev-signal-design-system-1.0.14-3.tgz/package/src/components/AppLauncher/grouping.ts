import type { Product } from './types';

function sortByOrder(products: Product[]): Product[] {
  return [...products].sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
}

/**
 * Groups products by section. Products within each section are sorted by optional order (asc).
 * No hardcoded section names; keys come from product.section.
 */
export function groupBySection(products: Product[]): Record<string, Product[]> {
  const result: Record<string, Product[]> = {};
  for (const product of products) {
    const key = product.section;
    if (!result[key]) result[key] = [];
    result[key].push(product);
  }
  for (const key of Object.keys(result)) {
    result[key] = sortByOrder(result[key]);
  }
  return result;
}
