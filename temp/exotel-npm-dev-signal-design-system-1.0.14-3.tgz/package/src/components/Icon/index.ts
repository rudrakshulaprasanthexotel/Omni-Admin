/**
 * Icon Component
 * 
 * Exports the Exotel Icon component that wraps Phosphor Icons.
 */

export { Icon } from './Icon';
export type { IconProps, IconSize, IconWeightOption } from './Icon';
export type { IconName } from './iconRegistry';
