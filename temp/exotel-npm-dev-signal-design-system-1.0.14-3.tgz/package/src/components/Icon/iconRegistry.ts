import * as PhosphorIcons from 'phosphor-react';
import type { Icon as PhosphorIcon } from 'phosphor-react';

/** Keys on `phosphor-react` that are not icon components */
const EXCLUDED_EXPORT_KEYS = [
  'Icon',
  'IconProps',
  'IconWeight',
  'IconContext',
] as const;

type ExcludedExportKey = (typeof EXCLUDED_EXPORT_KEYS)[number];

/** PascalCase export name → kebab-case (matches the runtime loop below) */
type KebabCase<S extends string> = S extends `${infer T}${infer U}`
  ? U extends Uncapitalize<U>
    ? `${Lowercase<T>}${KebabCase<U>}`
    : `${Lowercase<T>}-${KebabCase<Uncapitalize<U>>}`
  : S;

type PascalExportName = Exclude<keyof typeof PhosphorIcons & string, ExcludedExportKey>;

/**
 * All icon names accepted by the registry (kebab-case), e.g. `"pencil-simple"` for `PencilSimple`.
 */
export type IconName = { [K in PascalExportName]: KebabCase<K> }[PascalExportName];

/**
 * Icon registry mapping
 * Maps string names to Phosphor icon components
 */
const iconRegistry = {} as Record<IconName, PhosphorIcon>;

Object.entries(PhosphorIcons).forEach(([key, value]) => {
  if ((EXCLUDED_EXPORT_KEYS as readonly string[]).includes(key)) return;

  let newKey = '';

  for (let i = 0; i < key.length; i++) {
    if (i === 0) {
      newKey += key[i].toLowerCase();
    } else {
      if (key[i] === key[i].toUpperCase()) {
        newKey += '-' + key[i].toLowerCase();
      } else {
        newKey += key[i];
      }
    }
  }

  iconRegistry[newKey as IconName] = value as PhosphorIcon;
});

export { iconRegistry };
