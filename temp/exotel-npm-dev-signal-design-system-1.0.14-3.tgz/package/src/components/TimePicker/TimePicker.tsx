/**
 * TimePicker Component
 *
 * Exotel-approved time picker component that wraps MUI X TimePicker.
 * Relies on the LocalizationProvider in ExotelThemeProvider.
 */

import { TimePicker as MuiTimePicker, type TimePickerProps as MuiTimePickerProps } from '@mui/x-date-pickers/TimePicker';
import { forwardRef, useMemo } from 'react';
import { FieldWrapper } from '../FieldLabel';

export interface TimePickerProps extends Omit<MuiTimePickerProps, 'ref'> {
  /** The size of the picker input. Matches EnhancedTextField sizes. */
  size?: 'small' | 'medium' | 'large';
}

export const TimePicker = forwardRef<HTMLDivElement, TimePickerProps>(
  (props, ref) => {
    const { label, size = 'medium', slotProps, ...rest } = props;

    const mergedSlotProps = useMemo(() => ({
      ...slotProps,
      textField: {
        size,
        ...(slotProps?.textField as object),
      },
    }), [size, slotProps]);

    return (
      <FieldWrapper label={label}>
        <MuiTimePicker ref={ref} slotProps={mergedSlotProps} {...rest} />
      </FieldWrapper>
    );
  }
);

TimePicker.displayName = 'TimePicker';
