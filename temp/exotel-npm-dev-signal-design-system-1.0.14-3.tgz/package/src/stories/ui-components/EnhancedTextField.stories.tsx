/**
 * EnhancedTextField Component Stories
 *
 * Stories for the Exotel EnhancedTextField component that wraps MUI's TextField.
 */

import type { Meta, StoryObj } from '@storybook/react';
import { EnhancedTextField, Icon } from '../../components';

type EnhancedTextFieldStoryArgs = React.ComponentProps<typeof EnhancedTextField> & {
  showStartIcon?: boolean;
  showEndIcon?: boolean;
};

const meta: Meta<EnhancedTextFieldStoryArgs> = {
  title: 'UI Components/EnhancedTextField',
  component: EnhancedTextField,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component:
          'Exotel-approved text field component with label above the input, wrapping MUI\'s TextField.',
      },
    },
  },
  tags: ['autodocs'],
  argTypes: {
    size: {
      control: 'select',
      options: ['small', 'medium', 'large'],
      description: 'The size of the component',
      table: {
        type: { summary: "'small' | 'medium' | 'large'" },
        defaultValue: { summary: "'medium'" },
      },
    },
    disabled: {
      control: 'boolean',
      description: 'If true, the component is disabled',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
    required: {
      control: 'boolean',
      description: 'If true, the label is displayed as required',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
    error: {
      control: 'boolean',
      description: 'If true, the label is displayed in an error state',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
    fullWidth: {
      control: 'boolean',
      description: 'If true, the input will take up the full width of its container',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
    showLabel: {
      control: 'boolean',
      description: 'If true, the label is displayed',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'true' },
      },
    },
    label: {
      control: 'text',
      description: 'The label content',
    },
    placeholder: {
      control: 'text',
      description: 'The short hint displayed in the input before the user enters a value',
    },
    helperText: {
      control: 'text',
      description: 'The helper text content',
    },
    showStartIcon: {
      control: 'boolean',
      description: 'Show icon at the start',
    },
    showEndIcon: {
      control: 'boolean',
      description: 'Show icon at the end',
    },
  },
};

export default meta;
type Story = StoryObj<EnhancedTextFieldStoryArgs>;

/**
 * Basic text field
 */
export const Basic: Story = {
  args: {
    label: 'Label',
  },
};

/**
 * Different sizes
 */
export const Sizes: Story = {
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', width: '300px' }}>
      <EnhancedTextField label="Small" size="small" />
      <EnhancedTextField label="Medium" size="medium" />
      <EnhancedTextField label="Large" size="large" />
    </div>
  ),
};

/**
 * With helper text
 */
export const WithHelperText: Story = {
  args: {
    label: 'Email',
    helperText: 'Enter your email address',
  },
};

/**
 * Required field
 */
export const Required: Story = {
  args: {
    label: 'Required Field',
    required: true,
  },
};

/**
 * Error state
 */
export const Error: Story = {
  args: {
    label: 'Email',
    error: true,
    helperText: 'Invalid email address',
  },
};

/**
 * Disabled state
 */
export const Disabled: Story = {
  args: {
    label: 'Disabled',
    disabled: true,
    defaultValue: 'Disabled value',
  },
};

/**
 * Full width
 */
export const FullWidth: Story = {
  args: {
    label: 'Full Width',
    fullWidth: true,
  },
};

/**
 * With placeholder
 */
export const WithPlaceholder: Story = {
  args: {
    label: 'Search',
    placeholder: 'Type to search...',
  },
};

/**
 * With start icon
 */
export const WithStartIcon: Story = {
  args: {
    label: 'Search',
    InputProps: {
      startAdornment: <Icon name="search" size="sm" />,
    },
  },
};

/**
 * With end icon
 */
export const WithEndIcon: Story = {
  args: {
    label: 'Password',
    type: 'password',
    InputProps: {
      endAdornment: <Icon name="eye" size="sm" />,
    },
  },
};

/**
 * With both start and end icons
 */
export const WithIcons: Story = {
  args: {
    label: 'Search',
    InputProps: {
      startAdornment: <Icon name="search" size="sm" />,
      endAdornment: <Icon name="x" size="sm" />,
    },
  },
};

/**
 * Multiline input (textarea)
 */
export const Multiline: Story = {
  argTypes: {
    multiline: { table: { disable: true } },
    showStartIcon: { table: { disable: true } },
    showEndIcon: { table: { disable: true } },
    size: { table: { disable: true } },
    rows: {
      control: 'number',
      description: 'Fixed number of rows',
    },
    minRows: {
      control: 'number',
      description: 'Minimum number of rows (auto-grow mode)',
    },
    maxRows: {
      control: 'number',
      description: 'Maximum number of rows (auto-grow mode)',
    },
    placeholder: {
      control: 'text',
    },
    label: {
      control: 'text',
    },
    helperText: {
      control: 'text',
    },
    disabled: {
      control: 'boolean',
    },
    error: {
      control: 'boolean',
    },
    required: {
      control: 'boolean',
    },
    fullWidth: {
      control: 'boolean',
    },
  },
  args: {
    label: 'Description',
    placeholder: 'Enter a description...',
    minRows: 2,
    disabled: false,
    error: false,
    required: false,
    fullWidth: false,
    helperText: '',
  },
  render: (args) => {
    const { showStartIcon, showEndIcon, ...rest } = args as EnhancedTextFieldStoryArgs;
    return (
      <div style={{ width: '350px' }}>
        <EnhancedTextField multiline {...rest} />
      </div>
    );
  },
};

/**
 * Interactive text field with all controls
 */
export const Interactive: Story = {
  args: {
    label: 'Label',
    size: 'medium',
    disabled: false,
    required: false,
    error: false,
    fullWidth: false,
    showLabel: true,
    placeholder: '',
    helperText: '',
    showStartIcon: false,
    showEndIcon: false,
  },
  render: (args) => {
    const { showStartIcon, showEndIcon, ...textFieldProps } = args;
    const InputProps: EnhancedTextFieldStoryArgs['InputProps'] = {};

    if (showStartIcon) {
      InputProps.startAdornment = <Icon name="search" size="sm" />;
    }
    if (showEndIcon) {
      InputProps.endAdornment = <Icon name="x" size="sm" />;
    }

    return (
      <EnhancedTextField
        {...textFieldProps}
        InputProps={Object.keys(InputProps).length > 0 ? InputProps : undefined}
      />
    );
  },
};