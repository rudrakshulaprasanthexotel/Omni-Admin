/**
 * NavigationDrawer Component Stories
 *
 * Stories for the NavigationDrawer component.
 */

import type { Meta, StoryObj } from '@storybook/react';
import { Box } from '../../components';
import { NavigationDrawer } from '../../components/NavigationDrawer';
import { dummyItems } from '../../components/Navigation/dummyData';
import tanjiroBgImage from '../../assets/tanjiro-bg-image.jpeg';

const meta: Meta<typeof NavigationDrawer> = {
  title: 'UI Components/NavigationDrawer',
  component: NavigationDrawer,
  parameters: {
    layout: 'fullscreen',
    docs: {
      description: {
        component: 'Navigation container optimized for mobile layouts.',
      },
    },
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof NavigationDrawer>;

export const Default: Story = {
  render: () => (
    <Box sx={{ height: '100vh', width: 320, backgroundColor: 'background.default' }}>
      <NavigationDrawer items={dummyItems} />
    </Box>
  ),
};

export const withContent: Story = {
  render: () => (
    <Box sx={{ height: '100vh', backgroundColor: 'background.default' }}>
      <Box component="header" sx={{ display: 'flex', alignItems: 'center'}}>
        <NavigationDrawer items={dummyItems} />
      <Box component="h1" sx={{ fontSize: 18, fontWeight: 600, color: 'text.primary', fontFamily: 'cursive' }}>My APP</Box>
      </Box>
      <Box component="main">
        <Box component="div" style={{ height: '100%', backgroundColor: 'blue', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <img style={{ width: '100%', height: '100%', objectFit: 'cover' }} src={tanjiroBgImage} alt="Content" />
        </Box>
      </Box>
    </Box>
  )
}
