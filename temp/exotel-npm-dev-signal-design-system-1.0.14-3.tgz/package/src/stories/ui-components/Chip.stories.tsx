import type { Meta, StoryObj } from '@storybook/react';
import { Chip, Icon } from '../../components';

const meta: Meta<typeof Chip> = {
  title: 'UI Components/Chip',
  component: Chip,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component:
          'Exotel-approved chip that wraps MUI Chip: **filled**, **outlined**, and **tonal** variants. ' +
          'Use `variant="tonal"` for a tinted surface and hue-matched label (same rules as Badge tonal), including light/dark palette. ' +
          'Supports icons, delete, clickable, and sizes like standard chips.',
      },
    },
  },
  tags: ['autodocs'],
  argTypes: {
    label: {
      control: 'text',
      description: 'The content of the chip',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
    color: {
      control: 'select',
      options: ['default', 'primary', 'secondary', 'error', 'info', 'success', 'warning'],
      description: 'The color of the component',
      table: {
        type: { summary: "'default' | 'primary' | 'secondary' | 'error' | 'info' | 'success' | 'warning'" },
        defaultValue: { summary: "'default'" },
      },
    },
    variant: {
      control: 'select',
      options: ['filled', 'outlined', 'tonal'],
      description:
        'The variant to use (tonal: tinted surface + hue-matched text, matching Badge tonal)',
      table: {
        type: { summary: "'filled' | 'outlined' | 'tonal'" },
        defaultValue: { summary: "'filled'" },
      },
    },
    size: {
      control: 'select',
      options: ['small', 'medium'],
      description: 'The size of the component',
      table: {
        type: { summary: "'small' | 'medium'" },
        defaultValue: { summary: "'medium'" },
      },
    },
    disabled: {
      control: 'boolean',
      description: 'If true, the component is disabled',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
    clickable: {
      control: 'boolean',
      description: 'If true, the chip will appear clickable',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
    deletable: {
      control: 'boolean',
      description: 'If true, the chip will show a delete icon',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof Chip>;

/**
 * Basic chip
 */
export const Basic: Story = {
  args: {
    label: 'Chip',
  },
};

/**
 * Tonal chip — use controls to change `color` and other props (matches Badge tonal styling).
 */
export const Tonal: Story = {
  args: {
    label: 'Tonal',
    variant: 'tonal',
    color: 'primary',
  },
};

/**
 * Different colors
 */
export const Colors: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
      <Chip label="Default" color="default" />
      <Chip label="Primary" color="primary" />
      <Chip label="Secondary" color="secondary" />
      <Chip label="Success" color="success" />
      <Chip label="Error" color="error" />
      <Chip label="Info" color="info" />
      <Chip label="Warning" color="warning" />
    </div>
  ),
};

/**
 * Different variants
 */
export const Variants: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
      <Chip label="Filled" variant="filled" />
      <Chip label="Outlined" variant="outlined" />
      <Chip label="Tonal" variant="tonal" color="primary" />
    </div>
  ),
};

/**
 * Tonal variant — same color logic as Badge tonal (theme palette, light/dark).
 */
export const TonalColors: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap', alignItems: 'center' }}>
      <Chip label="Default" variant="tonal" color="default" />
      <Chip label="Primary" variant="tonal" color="primary" />
      <Chip label="Secondary" variant="tonal" color="secondary" />
      <Chip label="Success" variant="tonal" color="success" />
      <Chip label="Error" variant="tonal" color="error" />
      <Chip label="Info" variant="tonal" color="info" />
      <Chip label="Warning" variant="tonal" color="warning" />
    </div>
  ),
};

/**
 * Tonal with clickable, delete, and leading icon (parity with standard chip behavior).
 */
export const TonalInteractive: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap', alignItems: 'center' }}>
      <Chip label="Clickable" variant="tonal" color="primary" clickable onClick={() => {}} />
      <Chip label="Deletable" variant="tonal" color="success" onDelete={() => {}} />
      <Chip
        label="With icon"
        variant="tonal"
        color="info"
        icon={<Icon name="check" size="sm" />}
      />
      <Chip
        label="All"
        variant="tonal"
        color="warning"
        icon={<Icon name="tag" size="sm" />}
        clickable
        onClick={() => {}}
        onDelete={() => {}}
      />
    </div>
  ),
};

/**
 * Clickable chip
 */
export const Clickable: Story = {
  args: {
    label: 'Clickable',
    clickable: true,
    onClick: () => {},
  },
};

/**
 * Deletable chip
 */
export const Deletable: Story = {
  args: {
    label: 'Deletable',
    onDelete: () => {},
  },
};

/**
 * Chip with icon
 */
export const WithIcon: Story = {
  args: {
    label: 'With Icon',
    icon: <Icon name="check" size="sm" />,
  },
};

/**
 * Chip with avatar
 */
export const WithAvatar: Story = {
  render: () => (
    <Chip
      avatar={<div style={{ width: 24, height: 24, borderRadius: '50%', background: '#1976d2', color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12 }}>AB</div>}
      label="Avatar Chip"
      color="primary"
    />
  ),
};

/**
 * Interactive chip with all controls
 */
export const Interactive: Story = {
  args: {
    label: 'Chip',
    color: 'default',
    variant: 'filled',
    size: 'medium',
    disabled: false,
    clickable: false,
    deletable: false,
  },
  render: (args) => {
    const { clickable, deletable, ...chipProps } = args;
    return (
      <Chip
        {...chipProps}
        onClick={clickable ? () => {} : undefined}
        onDelete={deletable ? () => {} : undefined}
      />
    );
  },
};
