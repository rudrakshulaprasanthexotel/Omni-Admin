/**
 * AppliedFilters Component Stories
 * 
 * Stories demonstrating the AppliedFilters component - displays applied
 * filters as chips with remove functionality and overflow handling.
 */

import type { Meta, StoryObj } from '@storybook/react';
import { AppliedFilters, type AppliedFilter } from '../../components/AppliedFilters';
import { useState } from 'react';
import { Box } from '@mui/material';

const meta: Meta<typeof AppliedFilters> = {
  title: 'UI Components/AppliedFilters',
  component: AppliedFilters,
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        component: `
### AppliedFilters

Displays applied filters in a compact bar with:
- Individual filter chips with remove buttons
- "Clear All" button to remove all filters
- Overflow handling with "+X More" chip
- Hover popup showing all filters when there's overflow

**Key Features:**
- ✅ Chip-based filter display
- ✅ Individual remove buttons
- ✅ Clear all functionality
- ✅ Automatic overflow handling
- ✅ Hover popup for hidden filters
- ✅ Support for multi-value filters

**Use Cases:**
- Search/filter interfaces
- Data tables with filters
- Report filters
- Any UI with active filter visualization
        `,
      },
    },
  },
  tags: ['autodocs'],
  argTypes: {
    filters: {
      control: 'object',
      description: 'Array of applied filters to display',
    },
    onClearAll: {
      description: 'Callback when Clear All is clicked',
    },
    maxVisible: {
      control: 'number',
      description: 'Maximum number of filters to show before truncating',
    },
    show: {
      control: 'boolean',
      description: 'Whether to show the component',
    },
  },
};

export default meta;
type Story = StoryObj<typeof AppliedFilters>;

/**
 * Basic usage with a few filters
 */
export const Basic: Story = {
  render: (args) => {
    const [filters, setFilters] = useState<AppliedFilter[]>([
      {
        id: 'campaign',
        label: 'Campaign',
        value: 'mohit_omni_camp',
        onRemove: () => {
          setFilters((prev) => prev.filter((f) => f.id !== 'campaign'));
        },
      },
      {
        id: 'queue',
        label: 'Queue',
        value: 'chat_Q1',
        onRemove: () => {
          setFilters((prev) => prev.filter((f) => f.id !== 'queue'));
        },
      },
      {
        id: 'channel',
        label: 'Channel',
        value: 'Voice',
        onRemove: () => {
          setFilters((prev) => prev.filter((f) => f.id !== 'channel'));
        },
      },
      {
        id: 'status',
        label: 'Status',
        value: 'Active',
        onRemove: () => {
          setFilters((prev) => prev.filter((f) => f.id !== 'status'));
        },
      },
      {
        id: 'agent',
        label: 'Agent',
        value: 'John Doe',
        onRemove: () => {
          setFilters((prev) => prev.filter((f) => f.id !== 'agent'));
        },
      },
      {
        id: 'date-range',
        label: 'Date Range',
        value: 'Jan 20, 2026 - Jan 23, 2026',
        onRemove: () => {
          setFilters((prev) => prev.filter((f) => f.id !== 'date-range'));
        },
      },
    ]);

    return (
      <Box>
        <AppliedFilters
          {...args}
          filters={filters}
          onClearAll={() => setFilters([])}
        />
        <Box sx={{ p: 2, textAlign: 'center', color: 'text.secondary' }}>
          {filters.length === 0
            ? 'All filters cleared'
            : 'Content area below filters'}
        </Box>
      </Box>
    );
  },
  args: {
    maxVisible: 4,
    show: true,
  },
  parameters: {
    docs: {
      description: {
        story: 'Basic usage with multiple filters: Campaign, Queue, Channel, Status, Agent, and Date Range. Shows overflow handling with "+X More" button when there are more than 4 filters.',
      },
    },
  },
};

/**
 * Matching the reference image with disposition filter
 */
export const WithDisposition: Story = {
  render: (args) => {
    const [filters, setFilters] = useState<AppliedFilter[]>([
      {
        id: 'campaign',
        label: 'Campaign',
        value: 'mohit_omni_camp',
        onRemove: () => {
          setFilters((prev) => prev.filter((f) => f.id !== 'campaign'));
        },
      },
      {
        id: 'queue',
        label: 'Queue',
        value: 'chat_Q1',
        onRemove: () => {
          setFilters((prev) => prev.filter((f) => f.id !== 'queue'));
        },
      },
      {
        id: 'channel',
        label: 'Channel',
        value: 'Voice',
        onRemove: () => {
          setFilters((prev) => prev.filter((f) => f.id !== 'channel'));
        },
      },
      {
        id: 'disposition',
        label: 'Disposition',
        value: 'failed.call.auto.dispose',
        onRemove: () => {
          setFilters((prev) => prev.filter((f) => f.id !== 'disposition'));
        },
      },
    ]);

    return (
      <Box>
        <AppliedFilters
          {...args}
          filters={filters}
          onClearAll={() => setFilters([])}
        />
        <Box sx={{ p: 2, textAlign: 'center', color: 'text.secondary' }}>
          {filters.length === 0
            ? 'All filters cleared'
            : 'Closed Interactions table content would appear here'}
        </Box>
      </Box>
    );
  },
  args: {
    maxVisible: 4,
    show: true,
  },
  parameters: {
    docs: {
      description: {
        story: 'Matches the reference image with Campaign, Queue, Channel, and Disposition filters.',
      },
    },
  },
};

/**
 * With overflow - shows "+X More" chip and popup
 */
export const WithOverflow: Story = {
  render: (args) => {
    const [filters, setFilters] = useState<AppliedFilter[]>([
      {
        id: 'campaign',
        label: 'Campaign',
        value: 'mohit_omni_camp',
        onRemove: () => {
          setFilters((prev) => prev.filter((f) => f.id !== 'campaign'));
        },
      },
      {
        id: 'queue',
        label: 'Queue',
        value: 'chat_Q1',
        onRemove: () => {
          setFilters((prev) => prev.filter((f) => f.id !== 'queue'));
        },
      },
      {
        id: 'channel',
        label: 'Channel',
        value: 'Voice',
        onRemove: () => {
          setFilters((prev) => prev.filter((f) => f.id !== 'channel'));
        },
      },
      {
        id: 'disposition',
        label: 'Disposition',
        value: 'failed.call.auto.dispose',
        onRemove: () => {
          setFilters((prev) => prev.filter((f) => f.id !== 'disposition'));
        },
      },
      {
        id: 'status',
        label: 'Status',
        value: 'Active',
        onRemove: () => {
          setFilters((prev) => prev.filter((f) => f.id !== 'status'));
        },
      },
      {
        id: 'priority',
        label: 'Priority',
        value: 'High',
        onRemove: () => {
          setFilters((prev) => prev.filter((f) => f.id !== 'priority'));
        },
      },
    ]);

    return (
      <Box>
        <AppliedFilters
          {...args}
          filters={filters}
          onClearAll={() => setFilters([])}
          maxVisible={3}
        />
        <Box sx={{ p: 2, textAlign: 'center', color: 'text.secondary' }}>
          {filters.length === 0
            ? 'All filters cleared'
            : 'Hover over "+X More" to see all filters'}
        </Box>
      </Box>
    );
  },
  args: {
    maxVisible: 3,
    show: true,
  },
  parameters: {
    docs: {
      description: {
        story: 'When there are more than maxVisible filters, shows a "+X More" chip. Hover over it to see all filters in a popup.',
      },
    },
  },
};

/**
 * With multi-value filters
 */
export const WithMultiValueFilters: Story = {
  render: (args) => {
    const [filters, setFilters] = useState<AppliedFilter[]>([
      {
        id: 'campaign',
        label: 'Campaign',
        value: 'mohit_omni_camp',
        onRemove: () => {
          setFilters((prev) => prev.filter((f) => f.id !== 'campaign'));
        },
      },
      {
        id: 'disposition',
        label: 'Disposition',
        value: ['Callback', 'schedule.callback', 'Open'],
        onRemove: () => {
          setFilters((prev) => prev.filter((f) => f.id !== 'disposition'));
        },
      },
      {
        id: 'status',
        label: 'Status',
        value: ['Active', 'Pending', 'In Progress'],
        onRemove: () => {
          setFilters((prev) => prev.filter((f) => f.id !== 'status'));
        },
      },
    ]);

    return (
      <Box>
        <AppliedFilters
          {...args}
          filters={filters}
          onClearAll={() => setFilters([])}
        />
        <Box sx={{ p: 2, textAlign: 'center', color: 'text.secondary' }}>
          {filters.length === 0
            ? 'All filters cleared'
            : 'Multi-value filters show as "First Value +2" format'}
        </Box>
      </Box>
    );
  },
  args: {
    maxVisible: 4,
    show: true,
  },
  parameters: {
    docs: {
      description: {
        story: 'Demonstrates multi-value filters. Shows first value with "+X" count. Full values visible in hover popup.',
      },
    },
  },
};

/**
 * Many filters with overflow
 */
export const ManyFilters: Story = {
  render: (args) => {
    const [filters, setFilters] = useState<AppliedFilter[]>([
      {
        id: 'date',
        label: 'Date',
        value: 'Jan 21 - Jan 27',
        onRemove: () => {
          setFilters((prev) => prev.filter((f) => f.id !== 'date'));
        },
      },
      {
        id: 'campaign',
        label: 'Campaign',
        value: 'mohit_omni_camp',
        onRemove: () => {
          setFilters((prev) => prev.filter((f) => f.id !== 'campaign'));
        },
      },
      {
        id: 'queue',
        label: 'Queue',
        value: 'chat_Q1',
        onRemove: () => {
          setFilters((prev) => prev.filter((f) => f.id !== 'queue'));
        },
      },
      {
        id: 'channel',
        label: 'Channel',
        value: 'Voice',
        onRemove: () => {
          setFilters((prev) => prev.filter((f) => f.id !== 'channel'));
        },
      },
      {
        id: 'disposition',
        label: 'Disposition',
        value: ['Callback', 'schedule.callback'],
        onRemove: () => {
          setFilters((prev) => prev.filter((f) => f.id !== 'disposition'));
        },
      },
      {
        id: 'status',
        label: 'Status',
        value: 'Active',
        onRemove: () => {
          setFilters((prev) => prev.filter((f) => f.id !== 'status'));
        },
      },
      {
        id: 'priority',
        label: 'Priority',
        value: 'High',
        onRemove: () => {
          setFilters((prev) => prev.filter((f) => f.id !== 'priority'));
        },
      },
      {
        id: 'agent',
        label: 'Agent',
        value: 'John Doe',
        onRemove: () => {
          setFilters((prev) => prev.filter((f) => f.id !== 'agent'));
        },
      },
    ]);

    return (
      <Box>
        <AppliedFilters
          {...args}
          filters={filters}
          onClearAll={() => setFilters([])}
        />
        <Box sx={{ p: 2, textAlign: 'center', color: 'text.secondary' }}>
          {filters.length === 0
            ? 'All filters cleared'
            : `${filters.length} filters applied - hover "+X More" to see all`}
        </Box>
      </Box>
    );
  },
  args: {
    maxVisible: 4,
    show: true,
  },
  parameters: {
    docs: {
      description: {
        story: '8 filters applied - first 4 visible, remaining 4 in "+4 More" popup.',
      },
    },
  },
};

/**
 * Empty state - no filters
 */
export const EmptyState: Story = {
  render: (args) => {
    return (
      <Box>
        <AppliedFilters {...args} filters={[]} onClearAll={() => {}} />
        <Box sx={{ p: 2, textAlign: 'center', color: 'text.secondary' }}>
          No filters applied - component is hidden
        </Box>
      </Box>
    );
  },
  args: {
    maxVisible: 4,
    show: true,
  },
  parameters: {
    docs: {
      description: {
        story: 'When no filters are applied, the component is automatically hidden.',
      },
    },
  },
};

/**
 * Interactive example with add/remove
 */
export const Interactive: Story = {
  render: (args) => {
    const allPossibleFilters: AppliedFilter[] = [
      {
        id: 'campaign',
        label: 'Campaign',
        value: 'mohit_omni_camp',
        onRemove: () => {},
      },
      {
        id: 'queue',
        label: 'Queue',
        value: 'chat_Q1',
        onRemove: () => {},
      },
      {
        id: 'channel',
        label: 'Channel',
        value: 'Voice',
        onRemove: () => {},
      },
      {
        id: 'disposition',
        label: 'Disposition',
        value: 'failed.call.auto.dispose',
        onRemove: () => {},
      },
      {
        id: 'status',
        label: 'Status',
        value: 'Active',
        onRemove: () => {},
      },
    ];

    const [activeFilters, setActiveFilters] = useState<string[]>([
      'campaign',
      'queue',
      'channel',
    ]);

    const filters = allPossibleFilters
      .filter((f) => activeFilters.includes(f.id))
      .map((f) => ({
        ...f,
        onRemove: () => {
          setActiveFilters((prev) => prev.filter((id) => id !== f.id));
        },
      }));

    const availableFilters = allPossibleFilters.filter(
      (f) => !activeFilters.includes(f.id)
    );

    return (
      <Box>
        <Box sx={{ p: 2, display: 'flex', gap: 1, flexWrap: 'wrap', mb: 2 }}>
          <Box sx={{ width: '100%', mb: 1 }}>
            <strong>Click to add filters:</strong>
          </Box>
          {availableFilters.map((filter) => (
            <button
              key={filter.id}
              onClick={() => {
                setActiveFilters((prev) => [...prev, filter.id]);
              }}
              style={{
                padding: '8px 16px',
                border: '1px solid #ddd',
                borderRadius: '4px',
                background: 'white',
                cursor: 'pointer',
              }}
            >
              Add {filter.label}
            </button>
          ))}
        </Box>
        <AppliedFilters
          {...args}
          filters={filters}
          onClearAll={() => setActiveFilters([])}
        />
        <Box sx={{ p: 2, textAlign: 'center', color: 'text.secondary' }}>
          {filters.length === 0
            ? 'No filters applied - add some above!'
            : `${filters.length} filter(s) applied`}
        </Box>
      </Box>
    );
  },
  args: {
    maxVisible: 3,
    show: true,
  },
  parameters: {
    docs: {
      description: {
        story: 'Interactive example where you can add/remove filters dynamically.',
      },
    },
  },
};
