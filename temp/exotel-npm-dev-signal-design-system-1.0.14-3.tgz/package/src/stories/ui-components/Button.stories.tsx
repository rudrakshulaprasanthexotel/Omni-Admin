/**
 * Button Component Stories
 * 
 * Stories for the Exotel Button component that wraps MUI's Button.
 */

import type { Meta, StoryObj } from '@storybook/react';
import { Button } from '../../components';

const meta: Meta<typeof Button> = {
  title: 'UI Components/Button',
  component: Button,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component: 'Exotel-approved button component that wraps MUI\'s Button. Provides consistent styling and behavior across Exotel applications.',
      },
    },
  },
  tags: ['autodocs'],
  argTypes: {
    variant: {
      control: 'select',
      options: ['text', 'outlined', 'contained', 'tonal'],
      description: 'The variant to use',
      table: {
        type: { summary: "'text' | 'outlined' | 'contained' | 'tonal'" },
        defaultValue: { summary: "'text'" },
      },
    },
    color: {
      control: 'select',
      options: ['inherit', 'primary', 'secondary', 'success', 'error', 'info', 'warning'],
      description: 'The color of the component',
      table: {
        type: { summary: "'inherit' | 'primary' | 'secondary' | 'success' | 'error' | 'info' | 'warning'" },
        defaultValue: { summary: "'primary'" },
      },
    },
    size: {
      control: 'select',
      options: ['small', 'medium', 'large', 'extraLarge'],
      description: 'The size of the component',
      table: {
        type: { summary: "'small' | 'medium' | 'large' | 'extraLarge'" },
        defaultValue: { summary: "'medium'" },
      },
    },
    disabled: {
      control: 'boolean',
      description: 'If true, the component is disabled',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
    fullWidth: {
      control: 'boolean',
      description: 'If true, the button will take up the full width of its container',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
    disableElevation: {
      control: 'boolean',
      description: 'If true, no elevation is used',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
    disableRipple: {
      control: 'boolean',
      description: 'If true, the ripple effect is disabled',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
    startIconProps: {
      control: 'object',
      description: 'Icon props for the start icon (e.g. { name: "plus" })',
      table: {
        type: { summary: 'IconProps' },
      },
    },
    endIconProps: {
      control: 'object',
      description: 'Icon props for the end icon (e.g. { name: "arrow-right" })',
      table: {
        type: { summary: 'IconProps' },
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof Button>;

/**
 * Primary button - the default variant for primary actions
 */
export const Primary: Story = {
  args: {
    children: 'Button',
    variant: 'contained',
    color: 'primary',
  },
};

/**
 * Button with start icon
 */
export const WithStartIcon: Story = {
  args: {
    children: 'Button',
    variant: 'contained',
    color: 'primary',
    startIconProps: { name: 'plus' },
  },
};

/**
 * Button with end icon
 */
export const WithEndIcon: Story = {
  args: {
    children: 'Button',
    variant: 'contained',
    color: 'primary',
    endIconProps: { name: 'arrow-right' },
  },
};

/**
 * Button with both start and end icons
 */
export const WithIcons: Story = {
  args: {
    children: 'Button',
    variant: 'contained',
    color: 'primary',
    startIconProps: { name: 'check' },
    endIconProps: { name: 'arrow-right' },
  },
};

/**
 * Interactive button with all controls
 */
export const Interactive: Story = {
  args: {
    children: 'Button',
    variant: 'contained',
    color: 'primary',
    size: 'medium',
    disabled: false,
    fullWidth: false,
    disableElevation: false,
    disableRipple: false,
  },
};

/**
 * Secondary button - for secondary actions
 */
export const Secondary: Story = {
  args: {
    children: 'Button',
    variant: 'contained',
    color: 'secondary',
  },
};

/**
 * Outlined button - for less prominent actions
 */
export const Outlined: Story = {
  args: {
    children: 'Button',
    variant: 'outlined',
    color: 'primary',
  },
};

/**
 * Text button - for the least prominent actions
 */
export const Text: Story = {
  args: {
    children: 'Button',
    variant: 'text',
    color: 'primary',
  },
};

/**
 * Tonal button - Material 3 style with softer background
 */
export const Tonal: Story = {
  args: {
    children: 'Button',
    variant: 'tonal',
    color: 'primary',
  },
};

/**
 * Different sizes available
 */
export const Sizes: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: '16px', alignItems: 'center' }}>
      <Button size="small" variant="contained">Small</Button>
      <Button size="medium" variant="contained">Medium</Button>
      <Button size="large" variant="contained">Large</Button>
      <Button size="extraLarge" variant="contained">Extra Large</Button>
    </div>
  ),
};

/**
 * Different colors available
 */
export const Colors: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: '16px', flexWrap: 'wrap' }}>
      <Button variant="contained" color="primary">Primary</Button>
      <Button variant="contained" color="secondary">Secondary</Button>
      <Button variant="contained" color="success">Success</Button>
      <Button variant="contained" color="error">Error</Button>
      <Button variant="contained" color="info">Info</Button>
      <Button variant="contained" color="warning">Warning</Button>
    </div>
  ),
};

/**
 * Tonal button colors - Material 3 style with softer backgrounds
 */
export const TonalColors: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: '16px', flexWrap: 'wrap' }}>
      <Button variant="tonal" color="primary">Primary</Button>
      <Button variant="tonal" color="secondary">Secondary</Button>
      <Button variant="tonal" color="success">Success</Button>
      <Button variant="tonal" color="error">Error</Button>
      <Button variant="tonal" color="info">Info</Button>
      <Button variant="tonal" color="warning">Warning</Button>
    </div>
  ),
};

/**
 * Disabled state
 */
export const Disabled: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: '16px' }}>
      <Button variant="contained" disabled>Disabled</Button>
      <Button variant="outlined" disabled>Disabled</Button>
      <Button variant="text" disabled>Disabled</Button>
      <Button variant="tonal" disabled>Tonal Disabled</Button>
    </div>
  ),
};

/**
 * All variants comparison
 */
export const Variants: Story = {
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
      <div style={{ display: 'flex', gap: '16px', alignItems: 'center' }}>
        <Button variant="contained" color="primary">Contained</Button>
        <Button variant="tonal" color="primary">Tonal</Button>
        <Button variant="outlined" color="primary">Outlined</Button>
        <Button variant="text" color="primary">Text</Button>
      </div>
    </div>
  ),
};

/**
 * Full width button
 */
export const FullWidth: Story = {
  args: {
    children: 'Full Width Button',
    variant: 'contained',
    color: 'primary',
    fullWidth: true,
  },
};
