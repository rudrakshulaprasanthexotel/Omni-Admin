import type { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';
import { Stepper, Button, Box, Typography, Paper } from '../../components';
import MuiStep from '@mui/material/Step';
import MuiStepLabel from '@mui/material/StepLabel';
import MuiStepContent from '@mui/material/StepContent';

const meta: Meta<typeof Stepper> = {
  title: 'UI Components/Stepper',
  component: Stepper,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component: 'Exotel-approved stepper component that wraps MUI\'s Stepper. Displays progress through a sequence of logical and numbered steps.',
      },
    },
  },
  tags: ['autodocs'],
  argTypes: {
    activeStep: {
      control: 'number',
      description: 'Set the active step (zero based index)',
      table: {
        type: { summary: 'number' },
        defaultValue: { summary: '0' },
      },
    },
    orientation: {
      control: 'select',
      options: ['horizontal', 'vertical'],
      description: 'The stepper orientation',
      table: {
        type: { summary: "'horizontal' | 'vertical'" },
        defaultValue: { summary: "'horizontal'" },
      },
    },
    alternativeLabel: {
      control: 'boolean',
      description: 'If set to true, the step label is placed under the icon',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof Stepper>;

const steps = ['Select campaign settings', 'Create an ad group', 'Create an ad'];

/**
 * Horizontal stepper
 */
export const Horizontal: Story = {
  render: () => {
    const [activeStep, setActiveStep] = useState(0);
    return (
      <Box sx={{ width: '100%', maxWidth: 600 }}>
        <Stepper activeStep={activeStep}>
          {steps.map((label) => (
            <MuiStep key={label}>
              <MuiStepLabel>{label}</MuiStepLabel>
            </MuiStep>
          ))}
        </Stepper>
        <Box sx={{ mt: 4, display: 'flex', gap: 2 }}>
          <Button
            variant="contained"
            onClick={() => setActiveStep((prev) => Math.min(prev + 1, steps.length - 1))}
            disabled={activeStep === steps.length - 1}
          >
            Next
          </Button>
          <Button
            variant="outlined"
            onClick={() => setActiveStep((prev) => Math.max(prev - 1, 0))}
            disabled={activeStep === 0}
          >
            Back
          </Button>
        </Box>
      </Box>
    );
  },
};

/**
 * Vertical stepper
 */
export const Vertical: Story = {
  render: () => {
    const [activeStep, setActiveStep] = useState(0);
    return (
      <Box sx={{ width: '100%', maxWidth: 600 }}>
        <Stepper activeStep={activeStep} orientation="vertical">
          {steps.map((step, index) => (
            <MuiStep key={step}>
              <MuiStepLabel>{step}</MuiStepLabel>
              <MuiStepContent>
                <Typography>Content for step {index + 1}</Typography>
                <Box sx={{ mt: 2, display: 'flex', gap: 2 }}>
                  <Button
                    variant="contained"
                    size="small"
                    onClick={() => setActiveStep((prev) => Math.min(prev + 1, steps.length - 1))}
                  >
                    {index === steps.length - 1 ? 'Finish' : 'Continue'}
                  </Button>
                  <Button
                    variant="outlined"
                    size="small"
                    onClick={() => setActiveStep((prev) => Math.max(prev - 1, 0))}
                    disabled={index === 0}
                  >
                    Back
                  </Button>
                </Box>
              </MuiStepContent>
            </MuiStep>
          ))}
        </Stepper>
      </Box>
    );
  },
};

/**
 * Alternative label stepper
 */
export const AlternativeLabel: Story = {
  render: () => {
    const [activeStep, setActiveStep] = useState(0);
    return (
      <Box sx={{ width: '100%', maxWidth: 800 }}>
        <Stepper activeStep={activeStep} alternativeLabel>
          {steps.map((label) => (
            <MuiStep key={label}>
              <MuiStepLabel>{label}</MuiStepLabel>
            </MuiStep>
          ))}
        </Stepper>
        <Box sx={{ mt: 4, display: 'flex', gap: 2, justifyContent: 'center' }}>
          <Button
            variant="contained"
            onClick={() => setActiveStep((prev) => Math.min(prev + 1, steps.length - 1))}
            disabled={activeStep === steps.length - 1}
          >
            Next
          </Button>
          <Button
            variant="outlined"
            onClick={() => setActiveStep((prev) => Math.max(prev - 1, 0))}
            disabled={activeStep === 0}
          >
            Back
          </Button>
        </Box>
      </Box>
    );
  },
};

/**
 * Non-linear stepper
 */
export const NonLinear: Story = {
  render: () => {
    const [activeStep, setActiveStep] = useState(0);
    return (
      <Box sx={{ width: '100%', maxWidth: 600 }}>
        <Stepper activeStep={activeStep} nonLinear>
          {steps.map((label, index) => (
            <MuiStep key={label} completed={index < activeStep}>
              <MuiStepLabel onClick={() => setActiveStep(index)}>
                {label}
              </MuiStepLabel>
            </MuiStep>
          ))}
        </Stepper>
        <Box sx={{ mt: 4 }}>
          <Typography>Active step: {activeStep + 1}</Typography>
        </Box>
      </Box>
    );
  },
};

/**
 * Interactive stepper with all controls
 */
export const Interactive: Story = {
  args: {
    activeStep: 0,
    orientation: 'horizontal',
    alternativeLabel: false,
  },
  render: (args) => {
    const [activeStep, setActiveStep] = useState(args.activeStep || 0);
    return (
      <Box sx={{ width: '100%', maxWidth: 600 }}>
        <Stepper {...args} activeStep={activeStep}>
          {steps.map((label) => (
            <MuiStep key={label}>
              <MuiStepLabel>{label}</MuiStepLabel>
            </MuiStep>
          ))}
        </Stepper>
      </Box>
    );
  },
};
