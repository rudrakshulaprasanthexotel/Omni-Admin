import type { Meta, StoryObj } from '@storybook/react';
import { Radio } from '../../components';
import { FormControlLabel, RadioGroup as MuiRadioGroup } from '@mui/material';
import { useState } from 'react';

const meta: Meta<typeof Radio> = {
  title: 'UI Components/Radio',
  component: Radio,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component: 'Exotel-approved radio component that wraps MUI\'s Radio. Used for single selection from a list of options.',
      },
    },
  },
  tags: ['autodocs'],
  argTypes: {
    color: {
      control: 'select',
      options: ['default', 'primary', 'secondary', 'error', 'info', 'success', 'warning'],
      description: 'The color of the component',
      table: {
        type: { summary: "'default' | 'primary' | 'secondary' | 'error' | 'info' | 'success' | 'warning'" },
        defaultValue: { summary: "'primary'" },
      },
    },
    size: {
      control: 'select',
      options: ['small', 'medium'],
      description: 'The size of the component',
      table: {
        type: { summary: "'small' | 'medium'" },
        defaultValue: { summary: "'medium'" },
      },
    },
    disabled: {
      control: 'boolean',
      description: 'If true, the component is disabled',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
    checked: {
      control: 'boolean',
      description: 'If true, the component is checked',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof Radio>;

/**
 * Unchecked radio
 */
export const Unchecked: Story = {
  args: {
    checked: false,
  },
};

/**
 * Checked radio
 */
export const Checked: Story = {
  args: {
    checked: true,
  },
};

/**
 * Different colors
 */
export const Colors: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: '16px', alignItems: 'center' }}>
      <Radio checked color="default" />
      <Radio checked color="primary" />
      <Radio checked color="secondary" />
      <Radio checked color="success" />
      <Radio checked color="error" />
      <Radio checked color="info" />
      <Radio checked color="warning" />
    </div>
  ),
};

/**
 * Different sizes
 */
export const Sizes: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: '16px', alignItems: 'center' }}>
      <Radio checked size="small" />
      <Radio checked size="medium" />
    </div>
  ),
};

/**
 * Radio group with labels
 */
export const WithLabel: Story = {
  args: {
    size: 'medium',
  },
  render: (args) => (
    <MuiRadioGroup defaultValue="female" name="radio-buttons-group">
      <FormControlLabel value="female" control={<Radio size={args.size} />} label="Female" />
      <FormControlLabel value="male" control={<Radio size={args.size} />} label="Male" />
      <FormControlLabel value="other" control={<Radio size={args.size} />} label="Other" />
    </MuiRadioGroup>
  ),
};

/**
 * Disabled state
 */
export const Disabled: Story = {
  render: (args) => (
    <MuiRadioGroup defaultValue="checked" name="disabled-radio-group">
      <FormControlLabel value="unchecked" disabled control={<Radio size={args.size} />} label="Unchecked" />
      <FormControlLabel value="checked" disabled control={<Radio size={args.size} />} label="Checked" />
    </MuiRadioGroup>
  ),
};

/**
 * Interactive radio with all controls
 */
export const Interactive: Story = {
  args: {
    checked: false,
    color: 'primary',
    size: 'medium',
    disabled: false,
  },
  render: (args) => {
    const [checked, setChecked] = useState(args.checked);
    return (
      <Radio
        {...args}
        checked={checked}
        onChange={(e) => setChecked(e.target.checked)}
      />
    );
  },
};
