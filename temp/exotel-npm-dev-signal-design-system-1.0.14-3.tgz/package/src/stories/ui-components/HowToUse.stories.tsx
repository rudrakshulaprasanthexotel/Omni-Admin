import type { Meta, StoryObj } from '@storybook/react-vite';
import { Markdown } from '@storybook/addon-docs/blocks';
import content from '../../../docs/HOW_TO_USE.md?raw';

const meta: Meta = {
  title: 'Documentation/How to Use',
  tags: ['autodocs'],
  parameters: {
    docs: {
      page: () => <Markdown>{content}</Markdown>,
    },
  },
};

export default meta;

export const Guide: StoryObj = {
  tags: ['!dev', '!test'],
  render: () => <div />,
};
