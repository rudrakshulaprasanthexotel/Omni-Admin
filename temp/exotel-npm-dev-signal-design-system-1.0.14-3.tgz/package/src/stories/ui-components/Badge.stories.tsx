import type { Meta, StoryObj } from '@storybook/react';
import { Badge, IconButton, Icon, Avatar, Button } from '../../components';

const meta: Meta<typeof Badge> = {
  title: 'UI Components/Badge',
  component: Badge,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component: 'Exotel-approved badge component that wraps MUI\'s Badge. Used to display a small badge, typically containing a count or status indicator.',
      },
    },
  },
  tags: ['autodocs'],
  argTypes: {
    badgeContent: {
      control: 'number',
      description: 'The content rendered within the badge',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
    color: {
      control: 'select',
      options: ['default', 'primary', 'secondary', 'error', 'info', 'success', 'warning'],
      description: 'The color of the component',
      table: {
        type: { summary: "'default' | 'primary' | 'secondary' | 'error' | 'info' | 'success' | 'warning'" },
        defaultValue: { summary: "'default'" },
      },
    },
    variant: {
      control: 'select',
      options: ['standard', 'dot', 'tonal'],
      description: 'The variant to use (tonal: tinted badge per Signal DS / Figma)',
      table: {
        type: { summary: "'standard' | 'dot' | 'tonal'" },
        defaultValue: { summary: "'standard'" },
      },
    },
    max: {
      control: 'number',
      description: 'Max count to show',
      table: {
        type: { summary: 'number' },
        defaultValue: { summary: '99' },
      },
    },
    showZero: {
      control: 'boolean',
      description: 'Controls whether the badge is hidden when badgeContent is zero',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
    invisible: {
      control: 'boolean',
      description: 'If true, the badge is invisible',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof Badge>;

/**
 * Badge with IconButton
 */
export const WithIconButton: Story = {
  args: {
    badgeContent: 4,
    color: 'primary',
  },
  render: (args) => (
    <Badge {...args}>
      <IconButton>
        <Icon name="mail" />
      </IconButton>
    </Badge>
  ),
};

/**
 * Badge with Avatar
 */
export const WithAvatar: Story = {
  args: {
    badgeContent: 4,
    color: 'error',
  },
  render: (args) => (
    <Badge {...args}>
      <Avatar>AB</Avatar>
    </Badge>
  ),
};

/**
 * Badge with Button
 */
export const WithButton: Story = {
  args: {
    badgeContent: 99,
    color: 'primary',
  },
  render: (args) => (
    <Badge {...args}>
      <Button variant="contained">Messages</Button>
    </Badge>
  ),
};

/**
 * Dot variant
 */
export const Dot: Story = {
  args: {
    variant: 'dot',
    color: 'error',
  },
  render: (args) => (
    <Badge {...args}>
      <IconButton>
        <Icon name="bell" />
      </IconButton>
    </Badge>
  ),
};

/**
 * Different colors
 */
export const Colors: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: '16px', alignItems: 'center' }}>
      <Badge badgeContent={4} color="default">
        <IconButton><Icon name="mail" /></IconButton>
      </Badge>
      <Badge badgeContent={4} color="primary">
        <IconButton><Icon name="mail" /></IconButton>
      </Badge>
      <Badge badgeContent={4} color="secondary">
        <IconButton><Icon name="mail" /></IconButton>
      </Badge>
      <Badge badgeContent={4} color="error">
        <IconButton><Icon name="mail" /></IconButton>
      </Badge>
      <Badge badgeContent={4} color="success">
        <IconButton><Icon name="mail" /></IconButton>
      </Badge>
      <Badge badgeContent={4} color="warning">
        <IconButton><Icon name="mail" /></IconButton>
      </Badge>
      <Badge badgeContent={4} color="info">
        <IconButton><Icon name="mail" /></IconButton>
      </Badge>
    </div>
  ),
};

/**
 * Tonal variant — light tint background with hue-matched label (Signal Design System / Figma).
 */
export const TonalColors: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: '16px', alignItems: 'center', flexWrap: 'wrap' }}>
      <Badge badgeContent={1} variant="tonal" color="default">
        <IconButton><Icon name="mail" /></IconButton>
      </Badge>
      <Badge badgeContent={1} variant="tonal" color="primary">
        <IconButton><Icon name="mail" /></IconButton>
      </Badge>
      <Badge badgeContent={1} variant="tonal" color="secondary">
        <IconButton><Icon name="mail" /></IconButton>
      </Badge>
      <Badge badgeContent={1} variant="tonal" color="error">
        <IconButton><Icon name="mail" /></IconButton>
      </Badge>
      <Badge badgeContent={1} variant="tonal" color="warning">
        <IconButton><Icon name="mail" /></IconButton>
      </Badge>
      <Badge badgeContent={1} variant="tonal" color="info">
        <IconButton><Icon name="mail" /></IconButton>
      </Badge>
      <Badge badgeContent={1} variant="tonal" color="success">
        <IconButton><Icon name="mail" /></IconButton>
      </Badge>
    </div>
  ),
};

/**
 * Max count
 */
export const MaxCount: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: '16px', alignItems: 'center' }}>
      <Badge badgeContent={99} color="primary">
        <IconButton><Icon name="mail" /></IconButton>
      </Badge>
      <Badge badgeContent={150} max={99} color="primary">
        <IconButton><Icon name="mail" /></IconButton>
      </Badge>
    </div>
  ),
};

/**
 * Interactive badge with all controls
 */
export const Interactive: Story = {
  args: {
    badgeContent: 4,
    color: 'primary',
    variant: 'standard',
    max: 99,
    showZero: false,
    invisible: false,
  },
  render: (args) => (
    <Badge {...args}>
      <IconButton>
        <Icon name="mail" />
      </IconButton>
    </Badge>
  ),
};
