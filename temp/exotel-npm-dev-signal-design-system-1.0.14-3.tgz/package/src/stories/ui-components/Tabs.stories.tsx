import type { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';
import { Tabs, Tab, Box, Typography } from '../../components';
import type { IconName } from '../../components/Icon/iconRegistry';
import MuiTab from '@mui/material/Tab';
// TabPanel is not a separate component in MUI - we'll create a simple wrapper
function TabPanel(props: { children?: React.ReactNode; index: number; value: number }) {
  const { children, value, index, ...other } = props;
  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && <Box sx={{ p: 3 }}>{children}</Box>}
    </div>
  );
}

const meta: Meta<typeof Tabs> = {
  title: 'UI Components/Tabs',
  component: Tabs,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component: 'Exotel-approved tabs component that wraps MUI\'s Tabs. Provides navigation between different views or sections.',
      },
    },
  },
  tags: ['autodocs'],
  argTypes: {
    value: {
      control: 'number',
      description: 'The value of the currently selected tab',
    },
    tabStyle: {
      control: 'select',
      options: ['default', 'button', 'topIcon'],
      description: 'Visual style of the tabs',
      table: {
        type: { summary: "'default' | 'button' | 'topIcon'" },
        defaultValue: { summary: "'default'" },
      },
    },
    variant: {
      control: 'select',
      options: ['standard', 'scrollable', 'fullWidth'],
      description: 'The variant to use',
      table: {
        type: { summary: "'standard' | 'scrollable' | 'fullWidth'" },
        defaultValue: { summary: "'standard'" },
      },
    },
    orientation: {
      control: 'select',
      options: ['horizontal', 'vertical'],
      description: 'The orientation of the tabs',
      table: {
        type: { summary: "'horizontal' | 'vertical'" },
        defaultValue: { summary: "'horizontal'" },
      },
    },
    scrollButtons: {
      control: 'select',
      options: ['auto', true, false],
      description: 'Determine behavior of scroll buttons when tabs are set to scroll',
      table: {
        type: { summary: "'auto' | true | false" },
        defaultValue: { summary: "'auto'" },
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof Tabs>;

/**
 * Basic tabs
 */
export const Basic: Story = {
  render: () => {
    const [value, setValue] = useState(0);
    return (
      <Box sx={{ width: '100%', maxWidth: 600 }}>
        <Tabs value={value} onChange={(e, newValue) => setValue(newValue as number)}>
          <MuiTab label="Item One" />
          <MuiTab label="Item Two" />
          <MuiTab label="Item Three" />
        </Tabs>
        <TabPanel value={value} index={0}>
          <Typography>Content for Item One</Typography>
        </TabPanel>
        <TabPanel value={value} index={1}>
          <Typography>Content for Item Two</Typography>
        </TabPanel>
        <TabPanel value={value} index={2}>
          <Typography>Content for Item Three</Typography>
        </TabPanel>
      </Box>
    );
  },
};

/**
 * Scrollable tabs
 */
export const Scrollable: Story = {
  render: () => {
    const [value, setValue] = useState(0);
    return (
      <Box sx={{ width: '100%', maxWidth: 400 }}>
        <Tabs
          value={value}
          onChange={(e, newValue) => setValue(newValue as number)}
          variant="scrollable"
          scrollButtons="auto"
        >
          {['Tab 1', 'Tab 2', 'Tab 3', 'Tab 4', 'Tab 5', 'Tab 6', 'Tab 7'].map((label, index) => (
            <MuiTab key={index} label={label} />
          ))}
        </Tabs>
      </Box>
    );
  },
};

/**
 * Full width tabs
 */
export const FullWidth: Story = {
  render: () => {
    const [value, setValue] = useState(0);
    return (
      <Box sx={{ width: '100%', maxWidth: 600 }}>
        <Tabs
          value={value}
          onChange={(e, newValue) => setValue(newValue as number)}
          variant="fullWidth"
        >
          <MuiTab label="Item One" />
          <MuiTab label="Item Two" />
          <MuiTab label="Item Three" />
        </Tabs>
      </Box>
    );
  },
};

/**
 * Vertical tabs
 */
export const Vertical: Story = {
  render: () => {
    const [value, setValue] = useState(0);
    return (
      <Box sx={{ display: 'flex', width: '100%', maxWidth: 600, height: 300 }}>
        <Tabs
          value={value}
          onChange={(e, newValue) => setValue(newValue as number)}
          orientation="vertical"
          variant="scrollable"
        >
          <MuiTab label="Item One" />
          <MuiTab label="Item Two" />
          <MuiTab label="Item Three" />
          <MuiTab label="Item Four" />
        </Tabs>
        <Box sx={{ p: 3, flex: 1 }}>
          <TabPanel value={value} index={0}>
            <Typography>Content for Item One</Typography>
          </TabPanel>
          <TabPanel value={value} index={1}>
            <Typography>Content for Item Two</Typography>
          </TabPanel>
          <TabPanel value={value} index={2}>
            <Typography>Content for Item Three</Typography>
          </TabPanel>
          <TabPanel value={value} index={3}>
            <Typography>Content for Item Four</Typography>
          </TabPanel>
        </Box>
      </Box>
    );
  },
};

/**
 * Tabs with icons
 */
export const WithIcons: Story = {
  render: () => {
    const [value, setValue] = useState(0);
    return (
      <Box sx={{ width: '100%', maxWidth: 600 }}>
        <Tabs value={value} onChange={(e, newValue) => setValue(newValue as number)}>
          <Tab iconProps={{ name: "chart-bar", size: "sm" }} label="Dashboard" iconPosition="start" />
          <Tab iconProps={{ name: "envelope", size: "sm" }} label="Messages" iconPosition="start" />
          <Tab iconProps={{ name: "gear", size: "sm" }} label="Settings" iconPosition="start" />
        </Tabs>
      </Box>
    );
  },
};

/**
 * Interactive tabs with all controls — use the Storybook controls panel to
 * switch between `tabStyle`, `variant`, `orientation`, and `scrollButtons`.
 */
export const Interactive: Story = {
  args: {
    tabStyle: 'default',
    variant: 'standard',
    orientation: 'horizontal',
    scrollButtons: 'auto',
  },
  render: (args) => {
    const [value, setValue] = useState(0);
    const isVertical = args.orientation === 'vertical';

    const tabs: { label: string; icon: IconName; content: string }[] = [
      { label: 'Dashboard', icon: 'chart-bar', content: 'Dashboard overview with key metrics and charts.' },
      { label: 'Messages', icon: 'envelope', content: 'Your inbox — 3 unread messages.' },
      { label: 'Settings', icon: 'gear', content: 'Account preferences and configuration.' },
      { label: 'Billing', icon: 'credit-card', content: 'Invoices and payment methods.' },
      { label: 'Team', icon: 'users', content: 'Manage team members and roles.' },
    ];

    return (
      <Box
        sx={{
          width: '100%',
          maxWidth: 650,
          ...(isVertical && { display: 'flex', height: 300 }),
        }}
      >
        <Tabs
          {...args}
          value={value}
          onChange={(_e, newValue) => setValue(newValue as number)}
        >
          {tabs.map((tab) => (
            <Tab
              key={tab.label}
              label={tab.label}
              iconProps={{ name: tab.icon, size: "sm" }}
              iconPosition="start"
            />
          ))}
        </Tabs>

        <Box sx={{ flex: 1 }}>
          {tabs.map((tab, idx) => (
            <TabPanel key={tab.label} value={value} index={idx}>
              <Typography>{tab.content}</Typography>
            </TabPanel>
          ))}
        </Box>
      </Box>
    );
  },
};

/**
 * Button tabs — segmented control / pill style (fixed width)
 */
export const ButtonTabsFixedWidth: Story = {
  render: () => {
    const [value, setValue] = useState(0);
    return (
      <Box sx={{ width: '100%' }}>
        <Tabs
          tabStyle="button"
          value={value}
          onChange={(e, newValue) => setValue(newValue as number)}
        >
          <MuiTab label="My Details" />
          <MuiTab label="Profile" />
          <MuiTab label="Password" />
          <MuiTab label="Team" />
          <MuiTab label="Plan" />
          <MuiTab label="Billing" />
          <MuiTab label="Email" />
          <MuiTab label="Notification" />
        </Tabs>
        <TabPanel value={value} index={0}>
          <Typography>My Details content</Typography>
        </TabPanel>
        <TabPanel value={value} index={1}>
          <Typography>Profile content</Typography>
        </TabPanel>
        <TabPanel value={value} index={2}>
          <Typography>Password content</Typography>
        </TabPanel>
        <TabPanel value={value} index={3}>
          <Typography>Team content</Typography>
        </TabPanel>
        <TabPanel value={value} index={4}>
          <Typography>Plan content</Typography>
        </TabPanel>
        <TabPanel value={value} index={5}>
          <Typography>Billing content</Typography>
        </TabPanel>
        <TabPanel value={value} index={6}>
          <Typography>Email content</Typography>
        </TabPanel>
        <TabPanel value={value} index={7}>
          <Typography>Notification content</Typography>
        </TabPanel>
      </Box>
    );
  },
};

/**
 * Button tabs — segmented control / pill style (fill / equal width)
 */
export const ButtonTabsFill: Story = {
  render: () => {
    const [value, setValue] = useState(0);
    return (
      <Box sx={{ width: '100%', maxWidth: 600 }}>
        <Tabs
          tabStyle="button"
          variant="fullWidth"
          value={value}
          onChange={(e, newValue) => setValue(newValue as number)}
        >
          <MuiTab label="My Details" />
          <MuiTab label="Profile" />
          <MuiTab label="CRM" />
          <MuiTab label="Plan" />
        </Tabs>
        <TabPanel value={value} index={0}>
          <Typography>My Details content</Typography>
        </TabPanel>
        <TabPanel value={value} index={1}>
          <Typography>Profile content</Typography>
        </TabPanel>
        <TabPanel value={value} index={2}>
          <Typography>CRM content</Typography>
        </TabPanel>
        <TabPanel value={value} index={3}>
          <Typography>Plan content</Typography>
        </TabPanel>
      </Box>
    );
  },
};

/**
 * Tabs with top icons — icons positioned above the label text with a bottom indicator
 */
export const WithTopIcons: Story = {
  render: () => {
    const [value, setValue] = useState(0);
    return (
      <Box sx={{ width: '100%', maxWidth: 600 }}>
        <Tabs tabStyle="topIcon" value={value} onChange={(e, newValue) => setValue(newValue as number)}>
          <Tab iconProps={{ name: "airplane", size: "md" }} label="Flights" />
          <Tab iconProps={{ name: "suitcase", size: "md" }} label="Trips" />
          <Tab iconProps={{ name: "compass", size: "md" }} label="Explore" />
        </Tabs>
      </Box>
    );
  },
};

/**
 * Button tabs with badges
 */
export const ButtonTabsWithBadges: Story = {
  render: () => {
    const [value, setValue] = useState(0);
    return (
      <Box sx={{ width: '100%' }}>
        <Tabs
          tabStyle="button"
          value={value}
          onChange={(e, newValue) => setValue(newValue as number)}
        >
          <Tab label="My Details" />
          <Tab label="Profile" />
          <Tab label="Password" />
          <Tab label="Team" />
          <Tab label="Plan" />
          <Tab label="Billing" />
          <Tab label="Email" />
          <Tab label="Notification" badge={3} />
        </Tabs>
      </Box>
    );
  },
};

/**
 * Button tabs with icons
 */
export const ButtonTabsWithIcons: Story = {
  render: () => {
    const [value, setValue] = useState(0);
    return (
      <Box sx={{ width: '100%', maxWidth: 600 }}>
        <Tabs
          tabStyle="button"
          value={value}
          onChange={(e, newValue) => setValue(newValue as number)}
        >
          <Tab iconProps={{ name: "chart-bar", size: "sm" }} label="Dashboard" iconPosition="start" />
          <Tab iconProps={{ name: "envelope", size: "sm" }} label="Messages" iconPosition="start" />
          <Tab iconProps={{ name: "gear", size: "sm" }} label="Settings" iconPosition="start" />
        </Tabs>
      </Box>
    );
  },
};
