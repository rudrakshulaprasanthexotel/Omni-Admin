/**
 * Navigation Component Stories
 *
 * Stories for the Navigation component with toolbar search.
 */

import type { Meta, StoryObj } from '@storybook/react';
import { Box } from '../../components';
import { Navigation } from '../../components/Navigation';
import tanjiroBgImage from '../../assets/tanjiro-bg-image.jpeg';
import { dummyItems } from '../../components/Navigation/dummyData';

const meta: Meta<typeof Navigation> = {
  title: 'UI Components/Navigation',
  component: Navigation,
  parameters: {
    layout: 'fullscreen',
    docs: {
      description: {
        component:
          'Navigation container with a toolbar search input. Designed for left side navigation.',
      },
    },
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof Navigation>;

export const Default: Story = {
  render: () => (
    <Box sx={{ display: 'flex', height: '100vh', width: '100%' }}>
      <Navigation items={dummyItems} />
      <div style={{ flex: 1 }}>
        <div style={{ height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <img style={{ width: '100%', height: '100%', objectFit: 'cover' }} src={tanjiroBgImage} alt="Content" />
        </div>
      </div>
    </Box>
  ),
};

export const NarrowWidth: Story = {
  render: () => (
    <Box sx={{ height: '100vh', width: 240, backgroundColor: 'background.default' }}>
      <Navigation items={dummyItems} />
    </Box>
  ),
};
