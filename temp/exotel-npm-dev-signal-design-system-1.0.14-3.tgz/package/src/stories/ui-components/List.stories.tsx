import type { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';
import { 
  List, 
  ListItem, 
  ListItemIcon, 
  ListItemText, 
  ListItemButton, 
  ListItemSecondaryAction,
  ListSubheader,
  ListDivider,
  Avatar, 
  IconButton, 
  Checkbox 
} from '../../components';
import { Icon } from '../../components';
import ListItemAvatar from '@mui/material/ListItemAvatar';

const meta: Meta<typeof List> = {
  title: 'UI Components/List',
  component: List,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component: 'Exotel-approved list component that wraps MUI\'s List. Displays a collection of items in a structured format.',
      },
    },
  },
  tags: ['autodocs'],
  argTypes: {
    dense: {
      control: 'boolean',
      description: 'If true, compact vertical padding designed for keyboard and mouse input will be used',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
    disablePadding: {
      control: 'boolean',
      description: 'If true, vertical padding will be removed from the list',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof List>;

/**
 * Basic list
 */
export const Basic: Story = {
  render: () => (
    <List sx={{ width: '100%', maxWidth: 600, bgcolor: 'background.paper' }}>
      <ListItem>
        <ListItemText primary="Inbox" secondary="Jan 9, 2014" />
      </ListItem>
      <ListItem>
        <ListItemText primary="Drafts" secondary="Jan 7, 2014" />
      </ListItem>
      <ListItem>
        <ListItemText primary="Trash" secondary="Jan 1, 2014" />
      </ListItem>
    </List>
  ),
};

/**
 * List with icons
 */
export const WithIcons: Story = {
  render: () => (
    <List sx={{ width: '100%', maxWidth: 600, bgcolor: 'background.paper' }}>
      <ListItem>
        <ListItemIcon>
          <Icon name="inbox" size="sm" />
        </ListItemIcon>
        <ListItemText primary="Inbox" />
      </ListItem>
      <ListItem>
        <ListItemIcon>
          <Icon name="paper-plane" size="sm" />
        </ListItemIcon>
        <ListItemText primary="Drafts" />
      </ListItem>
      <ListItem>
        <ListItemIcon>
          <Icon name="trash" size="sm" />
        </ListItemIcon>
        <ListItemText primary="Trash" />
      </ListItem>
    </List>
  ),
};

/**
 * List with avatars
 */
export const WithAvatars: Story = {
  render: () => (
    <List sx={{ width: '100%', maxWidth: 600, bgcolor: 'background.paper' }}>
      <ListItem>
        <ListItemAvatar>
          <Avatar>A</Avatar>
        </ListItemAvatar>
        <ListItemText primary="Avatar A" secondary="Secondary text" />
      </ListItem>
      <ListItem>
        <ListItemAvatar>
          <Avatar>B</Avatar>
        </ListItemAvatar>
        <ListItemText primary="Avatar B" secondary="Secondary text" />
      </ListItem>
      <ListItem>
        <ListItemAvatar>
          <Avatar>C</Avatar>
        </ListItemAvatar>
        <ListItemText primary="Avatar C" secondary="Secondary text" />
      </ListItem>
    </List>
  ),
};

/**
 * List with buttons
 */
export const WithButtons: Story = {
  render: () => (
    <List sx={{ width: '100%', maxWidth: 600, bgcolor: 'background.paper' }}>
      <ListItem disablePadding>
        <ListItemButton>
          <ListItemIcon>
            <Icon name="inbox" size="sm" />
          </ListItemIcon>
          <ListItemText primary="Inbox" />
        </ListItemButton>
      </ListItem>
      <ListItem disablePadding>
        <ListItemButton>
          <ListItemIcon>
            <Icon name="paper-plane" size="sm" />
          </ListItemIcon>
          <ListItemText primary="Drafts" />
        </ListItemButton>
      </ListItem>
      <ListItem disablePadding>
        <ListItemButton>
          <ListItemIcon>
            <Icon name="trash" size="sm" />
          </ListItemIcon>
          <ListItemText primary="Trash" />
        </ListItemButton>
      </ListItem>
    </List>
  ),
};

/**
 * List with secondary actions
 */
export const WithSecondaryActions: Story = {
  render: () => (
    <List sx={{ width: '100%', maxWidth: 600, bgcolor: 'background.paper' }}>
      <ListItem>
        <ListItemIcon>
          <Icon name="inbox" size="sm" />
        </ListItemIcon>
        <ListItemText primary="Inbox" secondary="Jan 9, 2014" />
        <ListItemSecondaryAction>
          <IconButton edge="end" aria-label="delete">
            <Icon name="trash" size="sm" />
          </IconButton>
        </ListItemSecondaryAction>
      </ListItem>
      <ListItem>
        <ListItemIcon>
          <Icon name="paper-plane" size="sm" />
        </ListItemIcon>
        <ListItemText primary="Drafts" secondary="Jan 7, 2014" />
        <ListItemSecondaryAction>
          <IconButton edge="end" aria-label="delete">
            <Icon name="trash" size="sm" />
          </IconButton>
        </ListItemSecondaryAction>
      </ListItem>
    </List>
  ),
};

/**
 * List with checkboxes
 */
export const WithCheckboxes: Story = {
  render: () => {
    const [checked, setChecked] = useState([0]);
    const handleToggle = (value: number) => () => {
      const currentIndex = checked.indexOf(value);
      const newChecked = [...checked];
      if (currentIndex === -1) {
        newChecked.push(value);
      } else {
        newChecked.splice(currentIndex, 1);
      }
      setChecked(newChecked);
    };

    return (
      <List sx={{ width: '100%', maxWidth: 600, bgcolor: 'background.paper' }}>
        {[0, 1, 2, 3].map((value) => {
          const labelId = `checkbox-list-label-${value}`;
          return (
            <ListItem
              key={value}
              disablePadding
            >
              <ListItemButton role={undefined} onClick={handleToggle(value)} dense>
                <ListItemText id={labelId} primary={`Line item ${value + 1}`} />
              </ListItemButton>
              <ListItemSecondaryAction>
                <Checkbox
                  edge="end"
                  onChange={handleToggle(value)}
                  checked={checked.indexOf(value) !== -1}
                  inputProps={{ 'aria-labelledby': labelId }}
                />
              </ListItemSecondaryAction>
            </ListItem>
          );
        })}
      </List>
    );
  },
};

/**
 * Dense list
 */
export const Dense: Story = {
  render: () => (
    <List dense sx={{ width: '100%', maxWidth: 600, bgcolor: 'background.paper' }}>
      <ListItem>
        <ListItemIcon>
          <Icon name="inbox" size="sm" />
        </ListItemIcon>
        <ListItemText primary="Inbox" />
      </ListItem>
      <ListItem>
        <ListItemIcon>
          <Icon name="paper-plane" size="sm" />
        </ListItemIcon>
        <ListItemText primary="Drafts" />
      </ListItem>
      <ListItem>
        <ListItemIcon>
          <Icon name="trash" size="sm" />
        </ListItemIcon>
        <ListItemText primary="Trash" />
      </ListItem>
    </List>
  ),
};

/**
 * List with dividers
 */
export const WithDividers: Story = {
  render: () => (
    <List sx={{ width: '100%', maxWidth: 600, bgcolor: 'background.paper' }}>
      <ListItem>
        <ListItemText primary="Inbox" />
      </ListItem>
      <ListDivider />
      <ListItem>
        <ListItemText primary="Drafts" />
      </ListItem>
      <ListDivider />
      <ListItem>
        <ListItemText primary="Trash" />
      </ListItem>
    </List>
  ),
};

/**
 * List with subheaders
 */
export const WithSubheaders: Story = {
  render: () => (
    <List sx={{ width: '100%', maxWidth: 600, bgcolor: 'background.paper' }}>
      <ListSubheader>Navigation</ListSubheader>
      <ListItem>
        <ListItemIcon>
          <Icon name="inbox" size="sm" />
        </ListItemIcon>
        <ListItemText primary="Inbox" />
      </ListItem>
      <ListItem>
        <ListItemIcon>
          <Icon name="paper-plane" size="sm" />
        </ListItemIcon>
        <ListItemText primary="Drafts" />
      </ListItem>
      <ListSubheader>Actions</ListSubheader>
      <ListItem>
        <ListItemIcon>
          <Icon name="download" size="sm" />
        </ListItemIcon>
        <ListItemText primary="Download" />
      </ListItem>
      <ListItem>
        <ListItemIcon>
          <Icon name="share" size="sm" />
        </ListItemIcon>
        <ListItemText primary="Share" />
      </ListItem>
    </List>
  ),
};

/**
 * List with subheaders and dividers
 */
export const WithSubheadersAndDividers: Story = {
  render: () => (
    <List sx={{ width: '100%', maxWidth: 600, bgcolor: 'background.paper' }}>
      <ListSubheader>Navigation</ListSubheader>
      <ListItem>
        <ListItemIcon>
          <Icon name="inbox" size="sm" />
        </ListItemIcon>
        <ListItemText primary="Inbox" secondary="5 new messages" />
      </ListItem>
      <ListItem>
        <ListItemIcon>
          <Icon name="paper-plane" size="sm" />
        </ListItemIcon>
        <ListItemText primary="Drafts" secondary="2 drafts" />
      </ListItem>
      <ListDivider />
      <ListSubheader>Actions</ListSubheader>
      <ListItem>
        <ListItemIcon>
          <Icon name="download" size="sm" />
        </ListItemIcon>
        <ListItemText primary="Download" />
      </ListItem>
      <ListItem>
        <ListItemIcon>
          <Icon name="share" size="sm" />
        </ListItemIcon>
        <ListItemText primary="Share" />
      </ListItem>
      <ListDivider />
      <ListSubheader>Settings</ListSubheader>
      <ListItem>
        <ListItemIcon>
          <Icon name="settings" size="sm" />
        </ListItemIcon>
        <ListItemText primary="Settings" />
      </ListItem>
    </List>
  ),
};

/**
 * List with selected state
 */
export const WithSelected: Story = {
  render: () => {
    const [selectedIndex, setSelectedIndex] = useState(1);
    return (
      <List sx={{ width: '100%', maxWidth: 600, bgcolor: 'background.paper' }}>
        <ListItem 
          selected={selectedIndex === 0}
          onClick={() => setSelectedIndex(0)}
          sx={{ cursor: 'pointer' }}
        >
          <ListItemIcon>
            <Icon name="inbox" size="sm" />
          </ListItemIcon>
          <ListItemText primary="Inbox" />
        </ListItem>
        <ListItem 
          selected={selectedIndex === 1}
          onClick={() => setSelectedIndex(1)}
          sx={{ cursor: 'pointer' }}
        >
          <ListItemIcon>
            <Icon name="paper-plane" size="sm" />
          </ListItemIcon>
          <ListItemText primary="Drafts" />
        </ListItem>
        <ListItem 
          selected={selectedIndex === 2}
          onClick={() => setSelectedIndex(2)}
          sx={{ cursor: 'pointer' }}
        >
          <ListItemIcon>
            <Icon name="trash" size="sm" />
          </ListItemIcon>
          <ListItemText primary="Trash" />
        </ListItem>
      </List>
    );
  },
};

/**
 * Interactive list with all controls
 */
export const Interactive: Story = {
  args: {
    dense: false,
    disablePadding: false,
  },
  render: (args) => (
    <List {...args} sx={{ width: '100%', maxWidth: 600, bgcolor: 'background.paper' }}>
      <ListItem>
        <ListItemText primary="Item One" secondary="Secondary text" />
      </ListItem>
      <ListItem>
        <ListItemText primary="Item Two" secondary="Secondary text" />
      </ListItem>
      <ListItem>
        <ListItemText primary="Item Three" secondary="Secondary text" />
      </ListItem>
    </List>
  ),
};
