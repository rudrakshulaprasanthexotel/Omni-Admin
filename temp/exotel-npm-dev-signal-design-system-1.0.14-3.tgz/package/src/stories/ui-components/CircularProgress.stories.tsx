import type { Meta, StoryObj } from '@storybook/react';
import { CircularProgress } from '../../components';

const meta: Meta<typeof CircularProgress> = {
  title: 'UI Components/CircularProgress',
  component: CircularProgress,
  parameters: { layout: 'centered' },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof CircularProgress>;

export const Indeterminate: Story = {};
export const Determinate: Story = { args: { variant: 'determinate', value: 75 } };
