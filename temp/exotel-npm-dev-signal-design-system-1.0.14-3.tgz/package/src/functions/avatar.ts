export const getInitials = (name: string) => {
    const words = name.split(' ');

    if (words.length === 1) {
        return words[0][0].toUpperCase();
    }
    return words[0][0].toUpperCase() + words[words.length - 1][0].toUpperCase();
}

export function stringToColor(string: string) {
    let hash = 0;
    let i;

    for (i = 0; i < string.length; i += 1) {
      hash = string.charCodeAt(i) + ((hash << 5) - hash);
    }
  
    let color = '#';
  
    for (i = 0; i < 3; i += 1) {
      const value = (hash >> (i * 8)) & 0xff;
      color += `00${value.toString(16)}`.slice(-2);
    }
  
    return color;
}