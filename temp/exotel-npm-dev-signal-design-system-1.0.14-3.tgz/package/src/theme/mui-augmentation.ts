/**
 * MUI module augmentation for Exotel Design System.
 *
 * Augments palette (surface elevations, custom palette, appLauncher),
 * typography variants, and component prop overrides (Chip, Button, TextField, InputBase).
 *
 * ---
 * **Extending in a consuming project**
 *
 * Create a declaration file (e.g. `src/design-system.d.ts`) and augment the
 * design system module — no need to import `@mui/material/styles` directly:
 *
 * ```ts
 * declare module "@exotel-npm-dev/signal-design-system" {
 *   // Adds `brand` to MUI Palette / PaletteOptions automatically
 *   interface ExotelPaletteExtensions {
 *     brand: { main: string; contrast: string };
 *   }
 *   interface ExotelPaletteOptionsExtensions {
 *     brand?: { main: string; contrast: string };
 *   }
 *
 *   // Adds `display1` to MUI TypographyVariants / options
 *   interface ExotelTypographyExtensions {
 *     display1: React.CSSProperties;
 *   }
 *   interface ExotelTypographyOptionsExtensions {
 *     display1: React.CSSProperties;
 *   }
 * }
 * ```
 *
 * TypeScript declaration-merges these interfaces, and the `extends` clauses
 * below propagate the additions into the MUI theme automatically.
 */
import type { CSSProperties } from "react";

// ---------------------------------------------------------------------------
// Base interfaces
// ---------------------------------------------------------------------------

export interface SurfaceElevations {
  elevation0: string;
  elevation1: string;
  elevation2: string;
  elevation3: string;
  elevation4: string;
  elevation5: string;
  elevation6: string;
  elevation7: string;
  elevation8: string;
  elevation9: string;
  elevation10: string;
  elevation11: string;
  elevation12: string;
  elevation13: string;
  elevation14: string;
  elevation15: string;
  elevation16: string;
  elevation17: string;
  elevation18: string;
  elevation19: string;
  elevation20: string;
  elevation21: string;
  elevation22: string;
  elevation23: string;
  elevation24: string;
}

export interface CustomPalette {
  [key: string]: string;
}

export interface AppLauncherTrialChip {
  bg: string;
  text: string;
}

export interface AppLauncherPalette {
  trialChip?: AppLauncherTrialChip;
}

// ---------------------------------------------------------------------------
// Extension points — consumers augment these via
//   declare module "@exotel-npm-dev/signal-design-system" { … }
// The `extends` clauses in the MUI augmentation blocks below propagate
// any new members into the corresponding MUI interfaces.
// ---------------------------------------------------------------------------

/** Merge additional properties into MUI `Palette`. */
export interface ExotelPaletteExtensions {}

/** Merge additional properties into MUI `PaletteOptions`. */
export interface ExotelPaletteOptionsExtensions {}

/** Merge additional properties into MUI `TypographyVariants`. */
export interface ExotelTypographyExtensions {}

/** Merge additional properties into MUI `TypographyVariantsOptions`. */
export interface ExotelTypographyOptionsExtensions {}

/** Merge additional variant overrides into MUI `TypographyPropsVariantOverrides`. */
export interface ExotelTypographyPropsExtensions {}

/** Merge additional variant overrides into MUI `ChipPropsVariantOverrides`. */
export interface ExotelChipVariantExtensions {}

/** Merge additional size overrides into MUI `ButtonPropsSizeOverrides`. */
export interface ExotelButtonSizeExtensions {}

/** Merge additional size overrides into MUI `TextFieldPropsSizeOverrides`. */
export interface ExotelTextFieldSizeExtensions {}

/** Merge additional size overrides into MUI `InputBasePropsSizeOverrides`. */
export interface ExotelInputBaseSizeExtensions {}

// ---------------------------------------------------------------------------
// MUI module augmentations
// ---------------------------------------------------------------------------

declare module "@mui/material/styles" {
  interface Palette extends ExotelPaletteExtensions {
    surface: SurfaceElevations;
    custom: CustomPalette;
    appLauncher?: AppLauncherPalette;
  }

  interface PaletteOptions extends ExotelPaletteOptionsExtensions {
    surface?: Partial<SurfaceElevations>;
    custom?: Partial<CustomPalette>;
    appLauncher?: Partial<AppLauncherPalette>;
  }

  interface Theme {
    appLauncher?: AppLauncherPalette;
  }

  interface ColorSystemOptions {
    appLauncher?: Partial<AppLauncherPalette>;
  }

  interface ThemeVars {
    surface: SurfaceElevations;
    custom: CustomPalette;
    appLauncher?: AppLauncherPalette;
  }

  interface TypographyVariants extends ExotelTypographyExtensions {
    fontWeightSemiBold: number;
    title1: CSSProperties;
    title2: CSSProperties;
    title3: CSSProperties;
    label1: CSSProperties;
    label2: CSSProperties;
    label3: CSSProperties;
    body3: CSSProperties;
  }

  interface TypographyVariantsOptions extends ExotelTypographyOptionsExtensions {
    fontWeightSemiBold: number;
    title1: CSSProperties;
    title2: CSSProperties;
    title3: CSSProperties;
    label1: CSSProperties;
    label2: CSSProperties;
    label3: CSSProperties;
    body3: CSSProperties;
  }
}

declare module "@mui/material/Typography" {
  interface TypographyPropsVariantOverrides extends ExotelTypographyPropsExtensions {
    fontWeightSemiBold: true;
    title1: true;
    title2: true;
    title3: true;
    label1: true;
    label2: true;
    label3: true;
    body3: true;
  }
}

declare module "@mui/material/Chip" {
  interface ChipPropsVariantOverrides extends ExotelChipVariantExtensions {
    filter: true;
    tonal: true;
  }
}

declare module "@mui/material/Button" {
  interface ButtonPropsSizeOverrides extends ExotelButtonSizeExtensions {
    extraLarge: true;
  }
}

declare module "@mui/material/TextField" {
  interface TextFieldPropsSizeOverrides extends ExotelTextFieldSizeExtensions {
    large: true;
  }
}

declare module "@mui/material/InputBase" {
  interface InputBasePropsSizeOverrides extends ExotelInputBaseSizeExtensions {
    large: true;
  }
}
