/**
 * Exotel Design System Theme
 *
 * This file contains the main theme configuration for the Exotel Design System.
 * It wraps MUI's createTheme with Exotel-specific design tokens.
 *
 * The theme will be extended as the design system grows to include:
 * - Color palette (primary, secondary, error, warning, info, success)
 * - Typography scale
 * - Spacing system
 * - Component overrides
 * - Custom design tokens
 */

import "./mui-augmentation";
import { extendTheme, alpha } from "@mui/material/styles";
// This is required to augment the theme with DataGrid component customizations
import type {} from "@mui/x-data-grid-pro/themeAugmentation";
import NotoSansTtf from "../assets/NotoSans-VariableFont_wdth,wght.ttf";
import IBMPlexSansTtf from "../assets/IBMPlexSans-VariableFont_wdth,wght.ttf";
import type { ThemeOptions } from "@mui/material/styles";
/**
 * COMPLETE MUI Theme Configuration with CSS Variables
 *
 * This file contains all theme tokens consumed by MUI components.
 * Uses MUI's CSS Variables (CssVarsProvider) for native dark mode support.
 *
 * All sections are explicitly defined even if they match MUI defaults to ensure
 * visibility and easy customization.
 */

export const FONT_OPTIONS = {
  "noto-sans": { family: "Noto Sans", src: NotoSansTtf },
  "ibm-plex-sans": { family: "IBM Plex Sans", src: IBMPlexSansTtf },
} as const;

export type FontKey = keyof typeof FONT_OPTIONS;

export const DEFAULT_FONT: FontKey = "noto-sans";

/**
 * Creates the Exotel theme using MUI CSS Variables
 * Uses extendTheme with colorSchemes for native dark mode support
 * @returns MUI Theme instance with CSS Variables
 */
const fontWeights = {
  light: 300,
  regular: 400,
  medium: 500,
  semiBold: 600,
  bold: 700,
} as const;

// =============================================================================
// SHARED STYLE HELPERS — used by both MuiButton and MuiIconButton.
// Edit once → every component that calls these helpers updates automatically.
// =============================================================================

/**
 * Soft-outlined style: neutral divider border + subtle shadow in light mode,
 * currentColor border in dark mode.
 * Returns border-color / shadow / hover / active / disabled states.
 * The caller is responsible for adding `border: "1px solid"` when needed
 * (MUI Button's outlined slot already has the border; IconButton does not).
 */
function createSharedOutlinedStyles(themeInstance: any) {
  if (themeInstance.palette.mode === "dark") {
    return {
      borderColor: "currentColor",
      "&:hover": { borderColor: "currentColor" },
      "&:active": { borderColor: "currentColor" },
      "&:disabled": { borderColor: "currentColor" },
    };
  }

  const borderColor = themeInstance.palette.divider;
  const softOutlinedShadow = "0px 1px 2px 0px rgba(10, 13, 18, 0.05)";
  const softOutlinedShadowHover = "0px 2px 4px 0px rgba(10, 13, 18, 0.08)";
  const hoverBgAlpha = 0.04;

  return {
    borderColor,
    boxShadow: softOutlinedShadow,
    backgroundColor: "transparent",
    "&:hover": {
      boxShadow: softOutlinedShadowHover,
      backgroundColor: alpha(themeInstance.palette.action.hover, hoverBgAlpha),
      borderColor,
    },
    "&:active": { boxShadow: "none" },
    "&:disabled": {
      boxShadow: "none",
      borderColor: alpha(borderColor, 0.3),
    },
  };
}

/**
 * Contained style: filled background, contrast text, no elevation.
 *
 * @param palette  A specific color palette (e.g. `theme.palette.primary`).
 *                 Pass `undefined` for the default (no-color) contained look.
 */
function createSharedContainedStyles(themeInstance: any, palette?: any) {
  const noShadow = { boxShadow: "none" } as const;

  if (!palette) {
    return {
      ...noShadow,
      backgroundColor:
        (themeInstance.vars?.palette?.action?.selected as string) ||
        themeInstance.palette.action.selected,
      color:
        (themeInstance.vars?.palette?.text?.primary as string) ||
        themeInstance.palette.text.primary,
      "&:hover": {
        ...noShadow,
        backgroundColor:
          (themeInstance.vars?.palette?.action?.focus as string) ||
          themeInstance.palette.action.focus,
      },
      "&:disabled": {
        ...noShadow,
        backgroundColor:
          (themeInstance.vars?.palette?.action?.disabledBackground as string) ||
          themeInstance.palette.action.disabledBackground,
        color:
          (themeInstance.vars?.palette?.action?.disabled as string) ||
          themeInstance.palette.action.disabled,
      },
    };
  }

  return {
    ...noShadow,
    backgroundColor: palette.main,
    color: palette.contrastText,
    "&:hover": {
      ...noShadow,
      backgroundColor: palette.dark,
    },
    "&:disabled": {
      ...noShadow,
      backgroundColor:
        (themeInstance.vars?.palette?.action?.disabledBackground as string) ||
        themeInstance.palette.action.disabledBackground,
      color:
        (themeInstance.vars?.palette?.action?.disabled as string) ||
        themeInstance.palette.action.disabled,
    },
  };
}

export function createExotelTheme(fontKey: FontKey = DEFAULT_FONT, themeOverrides?: ThemeOptions) {
  const activeFont = FONT_OPTIONS[fontKey];
  const theme = extendTheme({
    // Use class-based selector so dark mode is driven by a CSS class on <html>,
    // NOT by @media (prefers-color-scheme). This must be a top-level option —
    // nesting it inside `cssVariables` has no effect.
    colorSchemeSelector: "class",

    // ============================================================================
    // COLOR SCHEMES - Light and Dark mode palettes
    // ============================================================================
    // MUI automatically handles dark mode colors - we only define light mode
    // and let MUI generate dark mode values natively

    colorSchemes: {
      light: {
        palette: {
          mode: "light",
          appLauncher: {
            trialChip: {
              bg: "#E8EEFF",
              text: "#1565C0",
            },
          },

          // Common colors used across light and dark modes
          common: {
            black: "#000",
            white: "#fff",
          },

          // Primary color - Main brand color used for primary actions
          // Affects: Primary buttons, links, selected states, focus indicators
          primary: {
            50: "#e3f2fd",
            100: "#bbdefb",
            200: "#90caf9",
            300: "#64b5f6",
            400: "#42a5f5",
            500: "#2196f3",
            600: "#1e88e5",
            700: "#1976d2", // main (light mode)
            800: "#1565c0",
            900: "#0d47a1",
            A100: "#82b1ff",
            A200: "#448aff",
            A400: "#2979ff",
            A700: "#2962ff",
            main: "#394FB6", // Primary brand color - affects all primary-colored components
            light: "#6175C5", // Lighter shade (calculated with ~20% lighten)
            dark: "#28377F", // Darker shade (calculated with ~30% darken)
            contrastText: "#fff",
          },

          // Secondary color - Used for secondary actions and accents
          // Affects: Secondary buttons, secondary text, accent elements
          secondary: {
            50: "#f3e5f5",
            100: "#e1bee7",
            200: "#ce93d8",
            300: "#ba68c8",
            400: "#ab47bc",
            500: "#9c27b0",
            600: "#8e24aa",
            700: "#7b1fa2",
            800: "#6a1b9a",
            900: "#4a148c",
            A100: "#ea80fc",
            A200: "#e040fb",
            A400: "#d500f9",
            A700: "#aa00ff",
            main: "#9c27b0",
            light: "#ba68c8",
            dark: "#7b1fa2",
            contrastText: "#fff",
          },

          // Error color - Used for error states and destructive actions
          // Affects: Error buttons, error text, error borders, Alert error variant
          error: {
            50: "#ffebee",
            100: "#ffcdd2",
            200: "#ef9a9a",
            300: "#e57373",
            400: "#ef5350",
            500: "#f44336",
            600: "#e53935",
            700: "#d32f2f", // main (light mode)
            800: "#c62828",
            900: "#b71c1c",
            A100: "#ff8a80",
            A200: "#ff5252",
            A400: "#ff1744",
            A700: "#d50000",
            main: "#d32f2f",
            light: "#ef5350",
            dark: "#c62828",
            contrastText: "#fff",
          },

          // Warning color - Used for warning states
          // Affects: Warning buttons, warning text, Alert warning variant
          warning: {
            50: "#fff3e0",
            100: "#ffe0b2",
            200: "#ffcc80",
            300: "#ffb74d",
            400: "#ffa726",
            500: "#ff9800",
            600: "#fb8c00",
            700: "#f57c00",
            800: "#ef6c00",
            900: "#e65100",
            A100: "#ffd180",
            A200: "#ffab40",
            A400: "#ff9100",
            A700: "#ff6d00",
            main: "#ed6c02", // closest to orange[800] that passes 3:1 contrast
            light: "#ff9800",
            dark: "#e65100",
            contrastText: "#000",
          },

          // Info color - Used for informational states
          // Affects: Info buttons, info text, Alert info variant
          info: {
            50: "#e1f5fe",
            100: "#b3e5fc",
            200: "#81d4fa",
            300: "#4fc3f7",
            400: "#29b6f6",
            500: "#03a9f4",
            600: "#039be5",
            700: "#0288d1", // main (light mode)
            800: "#0277bd",
            900: "#01579b",
            A100: "#80d8ff",
            A200: "#40c4ff",
            A400: "#00b0ff",
            A700: "#0091ea",
            main: "#0288d1",
            light: "#03a9f4",
            dark: "#01579b",
            contrastText: "#fff",
          },

          // Success color - Used for success states
          // Affects: Success buttons, success text, Alert success variant
          success: {
            50: "#e8f5e9",
            100: "#c8e6c9",
            200: "#a5d6a7",
            300: "#81c784",
            400: "#66bb6a",
            500: "#4caf50",
            600: "#43a047",
            700: "#388e3c",
            800: "#2e7d32",
            900: "#1b5e20",
            A100: "#b9f6ca",
            A200: "#69f0ae",
            A400: "#00e676",
            A700: "#00c853",
            main: "#2e7d32",
            light: "#4caf50",
            dark: "#1b5e20",
            contrastText: "#fff",
          },

          // Grey scale - Used for neutral elements
          // Affects: Dividers, disabled states, borders, backgrounds
          grey: {
            50: "#fafafa",
            100: "#f5f5f5",
            200: "#eeeeee",
            300: "#e0e0e0",
            400: "#bdbdbd",
            500: "#9e9e9e",
            600: "#757575",
            700: "#616161",
            800: "#424242",
            900: "#212121",
            A100: "#f5f5f5",
            A200: "#eeeeee",
            A400: "#bdbdbd",
            A700: "#616161",
          },

          // Text colors (light mode)
          // Affects: Typography component colors, text in all components
          text: {
            primary: "rgba(0, 0, 0, 0.87)", // Most important text
            secondary: "rgba(0, 0, 0, 0.6)", // Secondary text
            disabled: "rgba(0, 0, 0, 0.38)", // Disabled text
          },

          // Divider color
          // Affects: Divider component, borders between sections
          divider: "rgba(0, 0, 0, 0.12)",

          // Background colors (light mode)
          // Affects: Page background, Card background, Paper component
          background: {
            paper: "#fff", // Card, Paper, Dialog backgrounds
            default: "#fff", // Main page background
          },

          // Action colors - Used for interactive states
          // Affects: Hover states, focus states, selected states, disabled states
          action: {
            active: "rgba(0, 0, 0, 0.54)", // Active icon/button
            hover: "rgba(0, 0, 0, 0.04)", // Hover background
            hoverOpacity: 0.04,
            selected: "rgba(0, 0, 0, 0.08)", // Selected background
            selectedOpacity: 0.08,
            disabled: "rgba(0, 0, 0, 0.26)", // Disabled text/icon
            disabledBackground: "rgba(0, 0, 0, 0.12)", // Disabled background
            disabledOpacity: 0.38,
            focus: "rgba(0, 0, 0, 0.12)", // Focus background
            focusOpacity: 0.12,
            activatedOpacity: 0.12,
          },

          // Contrast threshold for determining text color on colored backgrounds
          // Used by getContrastText() function
          contrastThreshold: 3,

          // Tonal offset for light/dark color generation
          // Used to generate light and dark shades from main color
          tonalOffset: 0.2,

          // Defining Custom palette for light mode
          surface: {
            elevation0: '#F1F1F1',
            elevation1: '#FFFFFF',
            elevation2: '#FFFFFF',
            elevation3: '#FFFFFF',
            elevation4: '#FFFFFF',
            elevation5: '#FFFFFF',
            elevation6: '#FFFFFF',
            elevation7: '#FFFFFF',
            elevation8: '#FFFFFF',
            elevation9: '#FFFFFF',
            elevation10: '#FFFFFF',
            elevation11: '#FFFFFF',
            elevation12: '#FFFFFF',
            elevation13: '#FFFFFF',
            elevation14: '#FFFFFF',
            elevation15: '#FFFFFF',
            elevation16: '#FFFFFF',
            elevation17: '#FFFFFF',
            elevation18: '#FFFFFF',
            elevation19: '#FFFFFF',
            elevation20: '#FFFFFF',
            elevation21: '#FFFFFF',
            elevation22: '#FFFFFF',
            elevation23: '#FFFFFF',
            elevation24: '#FFFFFF',
          },
          custom: {
            highlight: '#ECEEF9',
          }
        },
      },
      // Dark mode - MUI will automatically generate dark colors
      // No manual definitions needed - MUI handles it natively
      // We only need to specify mode, MUI generates the rest
      dark: {
        palette: {
          mode: "dark",
          appLauncher: {
            trialChip: {
              bg: "#1E3A5F",
              text: "#90CAF9",
            },
          },
          // Defining Custom palette for dark mode
          surface: {
            elevation0: '#121212',
            elevation1: '#1E1E1E',
            elevation2: '#232323',
            elevation3: '#252525',
            elevation4: '#272727',
            elevation5: '#2A2A2A',
            elevation6: '#2C2C2C',
            elevation7: '#2C2C2C',
            elevation8: '#2E2E2E',
            elevation9: '#2E2E2E',
            elevation10: '#313131',
            elevation11: '#313131',
            elevation12: '#333333',
            elevation13: '#333333',
            elevation14: '#333333',
            elevation15: '#333333',
            elevation16: '#363636',
            elevation17: '#363636',
            elevation18: '#363636',
            elevation19: '#363636',
            elevation20: '#383838',
            elevation21: '#383838',
            elevation22: '#383838',
            elevation23: '#383838',
            elevation24: '#383838',
          },
          custom: {
            highlight: '#2A2F4A',
          }
        },
      },
    },

    // ============================================================================
    // TYPOGRAPHY - Font system for all text
    // ============================================================================
    // Typography is shared across both light and dark modes
    // Changing typography affects: All Typography components, Button text, Input labels,
    // Card headers, Dialog titles, and all text rendering.
    typography: {
      // Base font family - Applied to all text unless overridden
      fontFamily: `"${activeFont.family}", "Inter", "Roboto", sans-serif`,

      // Base font size in pixels
      fontSize: 14,

      // Font weight options
      fontWeightLight: fontWeights.light,
      fontWeightRegular: fontWeights.regular,
      fontWeightMedium: fontWeights.medium,
      fontWeightSemiBold: fontWeights.semiBold,
      fontWeightBold: fontWeights.bold,

      // HTML root font size (used for rem calculations)
      htmlFontSize: 16,

      // Typography variants - Exotel Design System rules
      h1: {
        fontWeight: fontWeights.bold,
        fontSize: "60px",
        lineHeight: 1.17,
        letterSpacing: "-1.5px",
        textDecoration: "none",
      },
      h2: {
        fontWeight: fontWeights.bold,
        fontSize: "48px",
        lineHeight: 1.2,
        letterSpacing: "-0.5px",
        textDecoration: "none",
      },
      h3: {
        fontWeight: fontWeights.bold,
        fontSize: "32px",
        lineHeight: 1.17,
        letterSpacing: "0px",
        textDecoration: "none",
      },
      h4: {
        fontWeight: fontWeights.bold,
        fontSize: "24px",
        lineHeight: 1.24,
        letterSpacing: "0.25px",
        textDecoration: "none",
      },
      h5: {
        fontWeight: fontWeights.bold,
        fontSize: "20px",
        lineHeight: 1.33,
        letterSpacing: "0px",
        textDecoration: "none",
      },
      h6: {
        fontWeight: fontWeights.bold,
        fontSize: "16px",
        lineHeight: 1.6,
        letterSpacing: "0.15px",
        textDecoration: "none",
      },

      // Title variants
      title1: {
        fontWeight: fontWeights.semiBold,
        fontSize: "12px",
        lineHeight: 1.57,
        letterSpacing: "0.1px",
        textDecoration: "none",
      },
      title2: {
        fontWeight: fontWeights.semiBold,
        fontSize: "14px",
        lineHeight: 1.57,
        letterSpacing: "0.1px",
        textDecoration: "none",
      },
      title3: {
        fontWeight: fontWeights.semiBold,
        fontSize: "16px",
        lineHeight: 1.75,
        letterSpacing: "0.15px",
        textDecoration: "none",
      },

      // Label variants
      label1: {
        fontWeight: fontWeights.medium,
        fontSize: "12px",
        lineHeight: 1.57,
        letterSpacing: "0.1px",
        textDecoration: "none",
      },
      label2: {
        fontWeight: fontWeights.medium,
        fontSize: "14px",
        lineHeight: 1.57,
        letterSpacing: "0.1px",
        textDecoration: "none",
      },
      label3: {
        fontWeight: fontWeights.medium,
        fontSize: "16px",
        lineHeight: 1.75,
        letterSpacing: "0.15px",
        textDecoration: "none",
      },

      // Body variants
      body1: {
        fontWeight: fontWeights.regular,
        fontSize: "16px",
        lineHeight: 1.5,
        letterSpacing: "0.15px",
        textDecoration: "none",
      },
      body2: {
        fontWeight: fontWeights.regular,
        fontSize: "14px",
        lineHeight: 1.43,
        letterSpacing: "0.17px",
        textDecoration: "none",
      },
      body3: {
        fontWeight: fontWeights.regular,
        fontSize: "12px",
        lineHeight: 1.32,
        letterSpacing: "0px",
        textDecoration: "none",
      },

      // Meta variants
      caption: {
        fontWeight: fontWeights.regular,
        fontSize: "12px",
        lineHeight: 1.66,
        letterSpacing: "0.4px",
        textDecoration: "none",
      },
      overline: {
        fontWeight: fontWeights.regular,
        fontSize: "12px",
        lineHeight: 2.66,
        letterSpacing: "1px",
        textDecoration: "none",
        textTransform: "uppercase",
      },
    },

    // ============================================================================
    // SPACING - Consistent spacing system
    // ============================================================================
    // Changing spacing affects: Margins, paddings, gaps in all components.
    // Default is 8px per unit (e.g., spacing(2) = 16px)
    // Material Design uses an 8dp grid system for visual balance.
    spacing: 8, // Base spacing unit in pixels

    // ============================================================================
    // BREAKPOINTS - Responsive design breakpoints
    // ============================================================================
    // Changing breakpoints affects: Grid layout, responsive typography, component visibility.
    // Used by: Grid, Hidden, useMediaQuery, sx prop responsive values
    breakpoints: {
      values: {
        xs: 0, // Extra small devices (phones)
        sm: 600, // Small devices (tablets)
        md: 900, // Medium devices (small laptops)
        lg: 1200, // Large devices (desktops)
        xl: 1536, // Extra large devices (large desktops)
      },
      unit: "px", // Unit for breakpoint values
      step: 5, // Step value for exclusive breakpoints (max-width calculations)
    },

    // ============================================================================
    // SHAPE - Border radius and shape customization
    // ============================================================================
    // Changing shape affects: Border radius of Buttons, Cards, Paper, Dialogs, TextFields, etc.
    shape: {
      borderRadius: 8, // Default border radius in pixels
    },

    // ============================================================================
    // SHADOWS - Elevation system
    // ============================================================================
    // Changing shadows affects: Card elevation, Button elevation, AppBar shadow, Paper elevation.
    // Material Design uses elevation to show hierarchy. Higher numbers = more elevation.
    shadows: [
      "none", // 0 - No shadow
      "0px 2px 1px -1px rgba(0,0,0,0.2), 0px 1px 1px 0px rgba(0,0,0,0.14), 0px 1px 3px 0px rgba(0,0,0,0.12)", // 1
      "0px 3px 1px -2px rgba(0,0,0,0.2), 0px 2px 2px 0px rgba(0,0,0,0.14), 0px 1px 5px 0px rgba(0,0,0,0.12)", // 2
      "0px 3px 3px -2px rgba(0,0,0,0.2), 0px 3px 4px 0px rgba(0,0,0,0.14), 0px 1px 8px 0px rgba(0,0,0,0.12)", // 3
      "0px 2px 4px -1px rgba(0,0,0,0.2), 0px 4px 5px 0px rgba(0,0,0,0.14), 0px 1px 10px 0px rgba(0,0,0,0.12)", // 4
      "0px 3px 5px -1px rgba(0,0,0,0.2), 0px 5px 8px 0px rgba(0,0,0,0.14), 0px 1px 14px 0px rgba(0,0,0,0.12)", // 5
      "0px 3px 5px -1px rgba(0,0,0,0.2), 0px 6px 10px 0px rgba(0,0,0,0.14), 0px 1px 18px 0px rgba(0,0,0,0.12)", // 6
      "0px 4px 5px -2px rgba(0,0,0,0.2), 0px 7px 10px 1px rgba(0,0,0,0.14), 0px 2px 16px 1px rgba(0,0,0,0.12)", // 7
      "0px 5px 5px -3px rgba(0,0,0,0.2), 0px 8px 10px 1px rgba(0,0,0,0.14), 0px 3px 14px 2px rgba(0,0,0,0.12)", // 8
      "0px 5px 6px -3px rgba(0,0,0,0.2), 0px 9px 12px 1px rgba(0,0,0,0.14), 0px 3px 16px 2px rgba(0,0,0,0.12)", // 9
      "0px 6px 6px -3px rgba(0,0,0,0.2), 0px 10px 14px 1px rgba(0,0,0,0.14), 0px 4px 18px 3px rgba(0,0,0,0.12)", // 10
      "0px 6px 7px -4px rgba(0,0,0,0.2), 0px 11px 15px 1px rgba(0,0,0,0.14), 0px 4px 20px 3px rgba(0,0,0,0.12)", // 11
      "0px 7px 8px -4px rgba(0,0,0,0.2), 0px 12px 17px 2px rgba(0,0,0,0.14), 0px 5px 22px 4px rgba(0,0,0,0.12)", // 12
      "0px 7px 8px -4px rgba(0,0,0,0.2), 0px 13px 19px 2px rgba(0,0,0,0.14), 0px 5px 24px 4px rgba(0,0,0,0.12)", // 13
      "0px 7px 9px -4px rgba(0,0,0,0.2), 0px 14px 21px 2px rgba(0,0,0,0.14), 0px 5px 26px 4px rgba(0,0,0,0.12)", // 14
      "0px 8px 9px -5px rgba(0,0,0,0.2), 0px 15px 22px 2px rgba(0,0,0,0.14), 0px 6px 28px 5px rgba(0,0,0,0.12)", // 15
      "0px 8px 10px -5px rgba(0,0,0,0.2), 0px 16px 24px 2px rgba(0,0,0,0.14), 0px 6px 30px 5px rgba(0,0,0,0.12)", // 16
      "0px 8px 11px -5px rgba(0,0,0,0.2), 0px 17px 26px 2px rgba(0,0,0,0.14), 0px 6px 32px 5px rgba(0,0,0,0.12)", // 17
      "0px 9px 11px -5px rgba(0,0,0,0.2), 0px 18px 28px 2px rgba(0,0,0,0.14), 0px 7px 34px 6px rgba(0,0,0,0.12)", // 18
      "0px 9px 12px -6px rgba(0,0,0,0.2), 0px 19px 29px 2px rgba(0,0,0,0.14), 0px 7px 36px 6px rgba(0,0,0,0.12)", // 19
      "0px 10px 13px -6px rgba(0,0,0,0.2), 0px 20px 31px 3px rgba(0,0,0,0.14), 0px 8px 38px 7px rgba(0,0,0,0.12)", // 20
      "0px 10px 13px -6px rgba(0,0,0,0.2), 0px 21px 33px 3px rgba(0,0,0,0.14), 0px 8px 40px 7px rgba(0,0,0,0.12)", // 21
      "0px 10px 14px -6px rgba(0,0,0,0.2), 0px 22px 35px 3px rgba(0,0,0,0.14), 0px 8px 42px 7px rgba(0,0,0,0.12)", // 22
      "0px 11px 14px -7px rgba(0,0,0,0.2), 0px 23px 36px 3px rgba(0,0,0,0.14), 0px 9px 44px 8px rgba(0,0,0,0.12)", // 23
      "0px 11px 15px -7px rgba(0,0,0,0.2), 0px 24px 38px 3px rgba(0,0,0,0.14), 0px 9px 46px 8px rgba(0,0,0,0.12)", // 24
    ],

    // ============================================================================
    // Z-INDEX - Layering system
    // ============================================================================
    // Changing zIndex affects: Component stacking order (which components appear on top).
    // Higher values appear above lower values. Used for modals, tooltips, drawers, etc.
    zIndex: {
      mobileStepper: 1000, // Mobile stepper component
      fab: 1050, // Floating Action Button
      speedDial: 1050, // Speed Dial component
      appBar: 1100, // AppBar component
      drawer: 1200, // Drawer component
      modal: 1300, // Modal/Dialog component
      snackbar: 1400, // Snackbar component
      tooltip: 1500, // Tooltip component (highest)
    },

    // ============================================================================
    // TRANSITIONS - Animation timing and easing
    // ============================================================================
    // Changing transitions affects: Animation speed and easing curves for all animated components.
    // Used by: Collapse, Fade, Grow, Slide, Zoom, and all transition animations.
    transitions: {
      // Easing curves - Control how animations accelerate/decelerate
      easing: {
        // Most common easing curve - smooth acceleration and deceleration
        easeInOut: "cubic-bezier(0.4, 0, 0.2, 1)",
        // Objects enter screen at full velocity, slowly decelerate
        easeOut: "cubic-bezier(0.0, 0, 0.2, 1)",
        // Objects leave screen at full velocity, no deceleration
        easeIn: "cubic-bezier(0.4, 0, 1, 1)",
        // Sharp curve for objects that may return to screen
        sharp: "cubic-bezier(0.4, 0, 0.6, 1)",
      },
      // Duration values in milliseconds
      duration: {
        shortest: 150, // Fastest transitions
        shorter: 200,
        short: 250,
        standard: 300, // Most common duration
        complex: 375, // Complex animations
        enteringScreen: 225, // When something enters screen
        leavingScreen: 195, // When something leaves screen
      },
    },

    // ============================================================================
    // COMPONENTS - Component default props and style overrides
    // ============================================================================
    // Changing components affects: Default props and global styles for specific components.
    // Use defaultProps to change default prop values globally.
    // Use styleOverrides to change default styles globally.
    components: {
      MuiCssBaseline: {
        styleOverrides: Object.values(FONT_OPTIONS)
          .map(
            (f) => `
          @font-face {
            font-family: '${f.family}';
            font-style: normal;
            font-display: swap;
            font-weight: 100 900;
            src: local('${f.family}'), url(${f.src}) format('truetype');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF;
          }`
          )
          .join("\n"),
      },
      // Button component customization
      MuiButton: {
        defaultProps: {
          // Uncomment to change default Button props globally:
          // variant: 'contained', // 'text' | 'outlined' | 'contained'
          // color: 'primary', // 'inherit' | 'primary' | 'secondary' | 'success' | 'error' | 'info' | 'warning'
          // size: 'medium', // 'small' | 'medium' | 'large' | 'extraLarge'
          disableElevation: true,
          // disableRipple: false,
        },
        // Size-specific variants - Dimensions from Figma design
        // Using padding-based approach instead of fixed height for better icon handling
        variants: [
          {
            props: { size: "extraLarge" },
            style: ({ theme }) => {
              // Target height: 44px
              // Font size: 16px, line-height: 1.5 = 24px
              // Vertical padding: (44 - 24) / 2 = 10px per side
              return {
                padding: "10px 24px",
                minHeight: 44,
                borderRadius: "8px",
                ...theme.typography.label3,
              };
            },
          },
          {
            props: { size: "large" },
            style: ({ theme }) => {
              // Target height: 40px
              // Font size: 14px, line-height: 1.5 = 21px
              // Vertical padding: (40 - 21) / 2 = 9.5px per side (round to 10px)
              return {
                padding: "10px 20px",
                minHeight: 40,
                borderRadius: "8px",
                ...theme.typography.label2,
              };
            },
          },
          {
            props: { size: "medium" },
            style: ({ theme }) => {
              // Target height: 32px
              // Font size: 14px, line-height: 1.5 = 21px
              // Vertical padding: (32 - 21) / 2 = 5.5px per side (round to 6px)
              return {
                padding: "6px 12px",
                minHeight: 32,
                borderRadius: "8px",
                ...theme.typography.label2,
              };
            },
          },
          {
            props: { size: "small" },
            style: ({ theme }) => {
              // Target height: 24px
              // Font size: 12px, line-height: 1.5 = 18px
              // Vertical padding: (24 - 18) / 2 = 3px per side
              // Horizontal padding: 8px for proper icon spacing
              return {
                padding: "3px 8px",
                minHeight: 24,
                borderRadius: "6px",
                ...theme.typography.label1,
              };
            },
          },
        ],
        styleOverrides: {
          root: ({ theme: themeInstance, ownerState }) => {
            // Helper function to create tonal styles for a given color palette
            const createTonalStyles = (
              palette: typeof themeInstance.palette.primary,
            ) => {
              const isDark = themeInstance.palette.mode === "dark";
              const bgAlpha = isDark ? 0.16 : 0.12;
              const hoverAlpha = isDark ? 0.2 : 0.16;
              const disabledAlpha = isDark ? 0.1 : 0.08;

              return {
                backgroundColor: alpha(palette.main, bgAlpha),
                color: palette.main,
                boxShadow: "none",
                "&:hover": {
                  backgroundColor: alpha(palette.main, hoverAlpha),
                  boxShadow: "none",
                },
                "&:disabled": {
                  backgroundColor: alpha(palette.main, disabledAlpha),
                  color: themeInstance.palette.action.disabled,
                },
              };
            };

            // Typography is now handled by size-specific variants above
            // Only apply base styles that are not size-dependent
            return {
              // Disable uppercase transformation (applies to all sizes)
              textTransform: "none",

              // Icon color for contained buttons - white in light mode, inverted (black) in dark mode
              "&.MuiButton-contained .MuiButton-startIcon, &.MuiButton-contained .MuiButton-endIcon":
                {
                  color:
                    themeInstance.palette.mode === "dark"
                      ? themeInstance.palette.common.black
                      : themeInstance.palette.common.white,
                },

              // Icon spacing - ensure proper gap between icon and text
              "& .MuiButton-startIcon": {
                marginLeft: 0,
                marginRight: "8px",
              },
              "& .MuiButton-endIcon": {
                marginLeft: "8px",
                marginRight: 0,
              },
              // Smaller icon spacing and size for small buttons
              "&.MuiButton-sizeSmall .MuiButton-startIcon": {
                marginRight: "4px",
                fontSize: "16px", // 16x16px icon size for small buttons
                "& svg": {
                  width: "16px",
                  height: "16px",
                },
              },
              "&.MuiButton-sizeSmall .MuiButton-endIcon": {
                marginLeft: "4px",
                fontSize: "16px", // 16x16px icon size for small buttons
                "& svg": {
                  width: "16px",
                  height: "16px",
                },
              },

              // Tonal button styles - target via data-variant attribute and MUI color classes
              // These work independently of size variants
              '&[data-variant="tonal"].MuiButton-colorPrimary':
                createTonalStyles(themeInstance.palette.primary),
              '&[data-variant="tonal"].MuiButton-colorSecondary':
                createTonalStyles(themeInstance.palette.secondary),
              '&[data-variant="tonal"].MuiButton-colorError': createTonalStyles(
                themeInstance.palette.error,
              ),
              '&[data-variant="tonal"].MuiButton-colorSuccess':
                createTonalStyles(themeInstance.palette.success),
              '&[data-variant="tonal"].MuiButton-colorWarning':
                createTonalStyles(themeInstance.palette.warning),
              '&[data-variant="tonal"].MuiButton-colorInfo': createTonalStyles(
                themeInstance.palette.info,
              ),
            };
          },
          // Soft Outlined Button variant styling — delegates to shared helper
          // so IconButton outlined uses the exact same styles.
          outlined: ({ theme: themeInstance }) =>
            createSharedOutlinedStyles(themeInstance),
          startIcon: {
            color: "inherit !important",
          },
          endIcon: {
            color: "inherit !important",
          },
        },
      },

      // Tabs container customization
      MuiTabs: {
        styleOverrides: {
          root: ({ theme: themeInstance }) => {
            const br = Number(themeInstance.shape.borderRadius) || 8;
            return {
              '&[data-variant="topIcon"]': {
                "& .MuiTab-root": {
                  gap: themeInstance.spacing(0.5),
                  "& .MuiTab-iconWrapper": {
                    marginBottom: 0,
                  },
                },
                "& .MuiTabs-indicator": {
                  backgroundColor: "transparent",
                  height: 3,
                  "&::before": {
                    content: '""',
                    display: "block",
                    position: "absolute",
                    left: 16,
                    right: 16,
                    top: 0,
                    bottom: 0,
                    borderRadius: `${br}px ${br}px 0 0`,
                    backgroundColor:
                      (themeInstance.vars?.palette?.primary?.main as string) ||
                      themeInstance.palette.primary.main,
                  },
                },
              },

              '&[data-variant="button"]': {
                backgroundColor:
                  (themeInstance.vars?.palette?.action?.hover as string) ||
                  themeInstance.palette.action.hover,
                borderRadius: br,
                padding: "4px",
                minHeight: 40,
                "& .MuiTabs-indicator": {
                  height: "100%",
                  bottom: 0,
                  borderRadius: `${br - 2}px`,
                  backgroundColor:
                    (themeInstance.vars?.palette?.background?.paper as string) ||
                    themeInstance.palette.background.paper,
                  boxShadow: "0px 1px 1px rgba(10, 13, 18, 0.05)",
                  zIndex: 0,
                },
                "& .MuiTabs-flexContainer": {
                  gap: "4px",
                  position: "relative",
                  zIndex: 1,
                },
                "& .MuiTab-root": {
                  minHeight: 32,
                  height: 32,
                  borderRadius: `${br - 2}px`,
                  padding: "6px 16px",
                  zIndex: 1,
                  color:
                    (themeInstance.vars?.palette?.text?.primary as string) ||
                    themeInstance.palette.text.primary,
                  opacity: 1,
                  transition: themeInstance.transitions.create(
                    ["color"],
                    { duration: themeInstance.transitions.duration.short },
                  ),
                  "& .MuiTouchRipple-root": {
                    display: "none",
                  },
                  "&.Mui-selected": {
                    color:
                      (themeInstance.vars?.palette?.primary?.main as string) ||
                      themeInstance.palette.primary.main,
                  },
                  "&:hover:not(.Mui-selected)": {
                    backgroundColor: alpha(
                      themeInstance.palette.action.hover,
                      themeInstance.palette.action.hoverOpacity * 2,
                    ),
                    borderRadius: `${br - 2}px`,
                  },
                },
              },
            };
          },
        },
      },

      // Tab component customization
      MuiTab: {
        styleOverrides: {
          root: {
            textTransform: "none",
            "& .MuiBadge-root": {
              display: "inline-flex",
              alignItems: "center",
              gap: "4px",
              "& .MuiBadge-badge": {
                position: "static",
                transform: "none",
              },
            },
            "&.MuiTab-labelIcon": {
              minHeight: "auto",
              "& .MuiTab-wrapper": {
                flexDirection: "row",
                alignItems: "center",
                gap: "8px",
              },
              "& .MuiTab-iconWrapper": {
                marginRight: "8px",
                marginBottom: 0,
                display: "flex",
                alignItems: "center",
              },
            },
          },
          labelIcon: {
            paddingBlock: '14px'
          }
        },
      },

      // Menu component customization
      MuiMenu: {
        styleOverrides: {
          paper: ({ theme: themeInstance }) => ({
            padding: themeInstance.spacing(0.5),
          }),
          list: {
            padding: 0,
          },
        },
      },

      // MenuItem component customization
      MuiMenuItem: {
        styleOverrides: {
          root: ({ theme: themeInstance }) => ({
            borderRadius: themeInstance.shape.borderRadius,
            marginBlock: themeInstance.spacing(0.5),
            ...themeInstance.typography.body3,
          }),
        },
      },

      // ListItemIcon component customization
      MuiListItemIcon: {
        styleOverrides: {
          root: ({ theme: themeInstance }) => ({
            minWidth: themeInstance.spacing(4), // 32px for icon spacing
          }),
        },
      },

      // ListItemText component customization
      MuiListItemText: {
        styleOverrides: {
          root: {
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap',
          },
          primary: ({ theme: themeInstance }) => ({
            ...themeInstance.typography.body2,
          }),
          secondary: ({ theme: themeInstance }) => ({
            ...themeInstance.typography.body3,
          }),
        },
      },

      // // ListItemButton component customization
      MuiListItemButton: {
        styleOverrides: {
          root: ({ theme: themeInstance }) => ({
            padding: themeInstance.spacing(0.5, 1),
            borderRadius: themeInstance.shape.borderRadius,
            marginBlock: themeInstance.spacing(0.5),
            // Selected state
            "&.Mui-selected": {
              backgroundColor: themeInstance.vars?.palette?.custom?.highlight,
              "&:hover": {
                backgroundColor: themeInstance.vars?.palette?.custom?.highlight,
              },
            },
          })
        },
      },

      // Dialog component customization
      MuiDialog: {
        styleOverrides: {
          paper: ({ theme: themeInstance }) => ({
            // Border radius matches Exotel system
            borderRadius: themeInstance.shape.borderRadius,
            // No custom shadows - use MUI defaults
            // Max height handled by Dialog component (responsive)
            // Flex layout ensures Header/Footer stay fixed, Body scrolls
            display: "flex",
            flexDirection: "column",
          }),
        },
      },

      // InputBase component (base for all input components)
      // Size-based height and padding lives here so it applies to every variant
      // (Outlined, Filled, Standard) and to picker text fields.
      MuiInputBase: {
        styleOverrides: {
          root: ({ theme: themeInstance, ownerState }) => {
            const size = (ownerState as any)?.size || "medium";

            const heightMap: Record<string, number> = {
              small: 32,
              medium: 40,
              large: 50,
            };

            const targetHeight = heightMap[size] || heightMap.medium;

            const lineHeight = 16;
            const border = 2; // 1px top + 1px bottom
            const verticalPadding = (targetHeight - border - lineHeight) / 2;

            const horizontalPadding = themeInstance.spacing(1.5); // 12px

            return {
              boxShadow: "0 1px 2px 0 rgba(10, 13, 18, 0.05)",
              fontWeight: fontWeights.medium,
              color:
                (themeInstance.vars?.palette?.text?.primary as string) ||
                themeInstance.palette.text.primary,
              height: ownerState.multiline ? "auto" : `${targetHeight}px`,
              minHeight: ownerState.multiline ? "auto" : `${targetHeight}px`,
              maxHeight: ownerState.multiline ? "auto" : `${targetHeight}px`,
              paddingTop: `${verticalPadding}px`,
              paddingBottom: `${verticalPadding}px`,
              paddingLeft: horizontalPadding + " !important",
              paddingRight: horizontalPadding,
              boxSizing: "border-box",
              "& .MuiInputBase-input": {
                padding: 0,
              },
            };
          },
          input: ({ theme: themeInstance, ownerState }) => ({
            fontSize:
              ownerState.size === "small"
                ? themeInstance.typography?.body3?.fontSize
                : ownerState.size === "large"
                  ? themeInstance.typography?.body1?.fontSize
                  : themeInstance.typography?.body2?.fontSize,
            color:
              (themeInstance.vars?.palette?.text?.primary as string) ||
              themeInstance.palette.text.primary,
            "&::placeholder": {
              color:
                (themeInstance.vars?.palette?.text?.secondary as string) ||
                themeInstance.palette.text.secondary,
              opacity: 0.7,
            },
          }),
        },
      },

      // DialogTitle component customization
      MuiDialogTitle: {
        styleOverrides: {
          root: ({ theme: themeInstance }) => ({
            // Typography uses Exotel heading tokens
            fontSize: themeInstance.typography.h6.fontSize,
            fontWeight: themeInstance.typography.h6.fontWeight,
            lineHeight: themeInstance.typography.h6.lineHeight,
            // Match Drawer header styling exactly
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            minHeight: 40,
            padding: themeInstance.spacing(1, 2),
            borderBottom: `1px solid ${themeInstance.palette.divider}`,
            backgroundColor: themeInstance.palette.action.hover,
            flexShrink: 0,
          }),
        },
      },

      // DialogContent component customization
      MuiDialogContent: {
        styleOverrides: {
          root: ({ theme: themeInstance }) => ({
            // Padding for structured layout
            padding: themeInstance.spacing(3, 2),
            paddingTop: `${themeInstance.spacing(3)} !important`,
            // Ensure proper scrolling behavior - only Body scrolls
            overflowY: "auto",
            flex: 1,
            display: "flex",
            flexDirection: "column",
            backgroundColor: "background.paper",
            // When dividers prop is used, maintain padding but remove default border styling
            // Dividers are handled by DialogTitle (borderBottom) and DialogActions (borderTop)
            "&.MuiDialogContent-dividers": {
              paddingTop: themeInstance.spacing(3),
              paddingBottom: themeInstance.spacing(3),
              borderTop: "none",
              borderBottom: "none",
            },
          }),
        },
      },

      // DialogActions component customization
      MuiDialogActions: {
        styleOverrides: {
          root: ({ theme: themeInstance }) => ({
            display: "flex",
            alignItems: "center",
            justifyContent: "flex-end",
            gap: themeInstance.spacing(2),
            minHeight: 64,
            padding: themeInstance.spacing(1, 2),
            borderTop: `1px solid ${themeInstance.palette.divider}`,
            backgroundColor: themeInstance.palette.background.paper,
            flexShrink: 0,
            ".MuiPickersLayout-root &": {
              backgroundColor: "transparent",
              minHeight: "auto",
            },
          }),
        },
      },

      // Drawer component customization
      MuiDrawer: {
        styleOverrides: {
          paper: ({ theme: themeInstance }) => ({
            // Drawer width should respect existing Exotel sizing rules
            // Default width for temporary drawers
            width: "100%",
            maxWidth: 600,
            // Border radius matches Exotel system
            borderRadius: 0,
            // No custom shadows - use MUI defaults
            // Background uses theme surface token (handled by component)
          }),
          paperAnchorLeft: {
            // Left anchor specific styles if needed
          },
          paperAnchorRight: {
            // Right anchor specific styles if needed
          },
          paperAnchorTop: {
            // Top anchor specific styles if needed
          },
          paperAnchorBottom: {
            // Bottom anchor specific styles if needed
          },
        },
      },

      // TextField component customization
      // Only supporting outlined variant
      MuiTextField: {
        defaultProps: {
          variant: "outlined", // Default to outlined only
        },
        styleOverrides: {
          root: ({ theme: themeInstance }) => ({
            // Ensure text field uses theme colors
            "& .MuiInputBase-root": {
              backgroundColor:
                (themeInstance.vars?.palette?.background?.paper as string) ||
                themeInstance.palette.background.paper,
              color:
                (themeInstance.vars?.palette?.text?.primary as string) ||
                themeInstance.palette.text.primary,
              gap: themeInstance.spacing(0.75),
            },
          }),
        },
      },

      // InputLabel component customization
      // Adjust unshrunk label font-size while preserving shrunk label visual size
      MuiInputLabel: {
        styleOverrides: {
          root: ({ theme: themeInstance, ownerState }) => {
            const size = (ownerState as any)?.size || "medium";

            // Unshrunk label font sizes
            const unshrunkFontSizeMap: Record<string, string> = {
              small: "12px",
              medium: "14px",
              large: "14px", // Large uses same as medium
            };

            const unshrunkFontSize =
              unshrunkFontSizeMap[size] || unshrunkFontSizeMap.medium;
            const baseFontSize = parseFloat(unshrunkFontSize);

            // Calculate scale to preserve shrunk label visual size
            // MUI default: base 16px, shrunk scale 0.75 = 12px visual
            // We want shrunk to look like 12px (MUI default shrunk size)
            // scale = 12px / baseFontSize
            // For small (12px base), we use 0.75 to maintain shrink animation effect
            // (resulting in 9px shrunk, which is acceptable for small size)
            const shrunkScale = size === "small" ? 0.75 : 12 / baseFontSize;

            return {
              color:
                (themeInstance.vars?.palette?.text?.secondary as string) ||
                themeInstance.palette.text.secondary,
              "&.Mui-focused": {
                color:
                  (themeInstance.vars?.palette?.primary?.main as string) ||
                  themeInstance.palette.primary.main,
              },
              fontSize: unshrunkFontSize,
              // Preserve MUI's shrink transform but adjust scale proportionally
              // MUI default transform: translate(14px, -9px) scale(0.75)
              "&.MuiInputLabel-shrink": {
                transform: `translate(14px, -9px) scale(${shrunkScale})`,
                transformOrigin: "top left",
              },
            };
          },
        },
      },

      // FormLabel component customization (for external labels)
      MuiFormLabel: {
        styleOverrides: {
          root: ({ theme: themeInstance }) => ({
            fontSize: themeInstance.typography.body2.fontSize,
            marginBottom: themeInstance.spacing(0.5),
            fontWeight: fontWeights.medium,
            "& .MuiFormLabel-asterisk": {
              color:
                (themeInstance.vars?.palette?.error?.main as string) ||
                themeInstance.palette.error.main,
            },
          }),
        },
      },

      // FormHelperText component customization
      MuiFormHelperText: {
        styleOverrides: {
          root: ({ theme: themeInstance }) => ({
            color:
              (themeInstance.vars?.palette?.text?.secondary as string) ||
              themeInstance.palette.text.secondary,
            marginTop: themeInstance.spacing(0.5), // Space between input and helper text
            marginLeft: 0,
            marginRight: 0,
            fontSize: themeInstance.typography.body3.fontSize, // 12px
          }),
        },
      },

      // OutlinedInput component customization
      // Size-based height/padding is handled by MuiInputBase above.
      // Only outlined-specific visuals (background, border colors) remain here.
      MuiOutlinedInput: {
        styleOverrides: {
          root: ({ theme: themeInstance }) => ({
            backgroundColor:
              (themeInstance.vars?.palette?.background?.paper as string) ||
              themeInstance.palette.background.paper,
            "& .MuiOutlinedInput-notchedOutline": {
              borderColor:
                (themeInstance.vars?.palette?.divider as string) ||
                themeInstance.palette.divider,
            },
            "&:hover .MuiOutlinedInput-notchedOutline": {
              borderColor:
                (themeInstance.vars?.palette?.text?.primary as string) ||
                themeInstance.palette.text.primary,
            },
            "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
              borderColor:
                (themeInstance.vars?.palette?.primary?.main as string) ||
                themeInstance.palette.primary.main,
            },
          }),
        },
      },

      // Card component customization
      MuiCard: {
        defaultProps: {
          // Uncomment to change default Card props globally:
          // variant: 'elevation', // 'elevation' | 'outlined'
          // elevation: 1,
        },
        styleOverrides: {
          // Uncomment to override Card styles globally:
          // root: {
          //   borderRadius: theme.shape.borderRadius * 2, // Larger border radius
          // },
        },
      },

      // AppBar component customization
      MuiAppBar: {
        defaultProps: {
          // Uncomment to change default AppBar props globally:
          // position: 'static', // 'fixed' | 'absolute' | 'sticky' | 'static' | 'relative'
          // color: 'primary', // 'default' | 'inherit' | 'primary' | 'secondary' | 'transparent' | 'error' | 'info' | 'success' | 'warning'
          // elevation: 4,
        },
        styleOverrides: {
          // Uncomment to override AppBar styles globally:
          // root: {
          //   // Custom styles
          // },
        },
      },

      // Typography component customization
      MuiTypography: {
        defaultProps: {
          // Uncomment to change default Typography props globally:
          // variant: 'body1', // 'h1' | 'h2' | 'h3' | 'h4' | 'h5' | 'h6' | 'subtitle1' | 'subtitle2' | 'body1' | 'body2' | 'button' | 'caption' | 'overline'
          // color: 'text.primary', // 'initial' | 'inherit' | 'primary' | 'secondary' | 'text.primary' | 'text.secondary' | 'text.disabled' | 'error'
        },
        styleOverrides: {
          // Uncomment to override Typography styles globally:
          // root: {
          //   // Custom styles
          // },
        },
      },

      // DataGrid component customization (MUI X)
      MuiDataGrid: {
        defaultProps: {
          // Default props are handled in DataTable component wrapper
        },
        styleOverrides: {
          root: ({ theme: themeInstance }) => {
            const borderColor =
              (themeInstance?.vars?.palette?.divider as string) ||
              themeInstance.palette.divider;
            const borderRadius = themeInstance.shape.borderRadius;
            return {
              border: "none",
              '& .MuiDataGrid-scrollShadow': {
                display: 'none',
              },
              '& .MuiDataGrid-main': {
                backgroundColor:
                  themeInstance?.vars?.palette?.surface?.elevation1,
                borderTop: `1px solid ${borderColor}`,
                borderLeft: `1px solid ${borderColor}`,
                borderRight: `1px solid ${borderColor}`,
                borderTopLeftRadius: `${borderRadius}px`,
                borderTopRightRadius: `${borderRadius}px`,
              },
              '& .MuiDataGrid-footerContainer': {
                borderLeft: `1px solid ${borderColor}`,
                borderRight: `1px solid ${borderColor}`,
                borderBottom: `1px solid ${borderColor}`,
                borderBottomLeftRadius: `${borderRadius}px`,
                borderBottomRightRadius: `${borderRadius}px`,
                overflow: 'hidden',
              },
            };
          },
          columnHeaders: ({ theme: themeInstance }) => ({
            backgroundColor: themeInstance?.vars?.palette?.surface?.elevation0,
            '& .MuiDataGrid-filler': {
              backgroundColor: themeInstance?.vars?.palette?.surface?.elevation0 + ' !important',
            },
            '& .MuiDataGrid-row--borderBottom': {
              height: '40px !important',
            }
          }),
          columnHeader: ({ theme: themeInstance }) => ({
            backgroundColor: themeInstance?.vars?.palette?.surface?.elevation0,
            borderBottom: 'none !important',
          }),
          cell: {},
          "cell--pinnedLeft": ({ theme: themeInstance }) => ({
            backgroundColor: themeInstance?.vars?.palette?.surface?.elevation1,
          }),
          "cell--pinnedRight": ({ theme: themeInstance }) => ({
            backgroundColor: themeInstance?.vars?.palette?.surface?.elevation1,
          }),
          "filler--pinnedLeft": ({ theme: themeInstance }) => ({
            backgroundColor: themeInstance?.vars?.palette?.surface?.elevation1,
          }),
          "filler--pinnedRight": ({ theme: themeInstance }) => ({
            backgroundColor: themeInstance?.vars?.palette?.surface?.elevation1,
          }),
          row: {},
          toolbar: () => ({
            border: "none",
            padding: "0px",
            flex: "none",
            display: "block",
          }),
          iconButtonContainer: {},
          menu: {},
          panelWrapper: ({ theme: themeInstance }) => ({
            backgroundColor: themeInstance.vars?.palette?.background?.paper,
            backgroundImage: 'var(--mui-overlays-8)',
          }),
          overlayWrapper: {
            top: 0
          }
        },
      },

      // IconButton component customization
      // Supports shape (circle, square) and variant (text, outlined, contained).
      // Uses the same shared helpers as MuiButton so style changes propagate to both.
      MuiIconButton: {
        styleOverrides: {
          root: ({ theme: themeInstance }) => {
            const colors = ["primary", "secondary", "error", "warning", "info", "success"] as const;

            const textColorStyles = Object.fromEntries(
              colors.map((c) => {
                const palette = themeInstance.palette[c];
                const vars = themeInstance.vars?.palette?.[c];
                return [
                  `&.MuiIconButton-color${c.charAt(0).toUpperCase() + c.slice(1)}`,
                  {
                    color: (vars?.main as string) || palette.main,
                    "&:hover": { backgroundColor: alpha(palette.main, 0.08) },
                  },
                ];
              }),
            );

            const outlinedColorStyles = Object.fromEntries(
              colors.map((c) => {
                const palette = themeInstance.palette[c];
                const vars = themeInstance.vars?.palette?.[c];
                const isDark = themeInstance.palette.mode === "dark";
                return [
                  `&.MuiIconButton-color${c.charAt(0).toUpperCase() + c.slice(1)}`,
                  {
                    color: (vars?.main as string) || palette.main,
                    ...(isDark
                      ? { borderColor: "currentColor", "&:hover": { borderColor: "currentColor", backgroundColor: alpha(palette.main, 0.08) } }
                      : { "&:hover": { backgroundColor: alpha(palette.main, 0.08) } }),
                  },
                ];
              }),
            );

            const containedColorStyles = Object.fromEntries(
              colors.map((c) => [
                `&.MuiIconButton-color${c.charAt(0).toUpperCase() + c.slice(1)}`,
                createSharedContainedStyles(themeInstance, themeInstance.palette[c]),
              ]),
            );

            return {
              borderRadius: themeInstance.shape.borderRadius,
              color:
                (themeInstance.vars?.palette?.text?.primary as string) ||
                themeInstance.palette.text.primary,
              "&:hover": {
                backgroundColor:
                  (themeInstance.vars?.palette?.action?.hover as string) ||
                  themeInstance.palette.action.hover,
              },
              "&:disabled": {
                color:
                  (themeInstance.vars?.palette?.action?.disabled as string) ||
                  themeInstance.palette.action.disabled,
              },

              // --- Shape ---
              '&[data-shape="circle"]': { borderRadius: "50%" },
              '&[data-shape="square"]': { borderRadius: themeInstance.shape.borderRadius },

              // --- Variant: text (default) ---
              ...textColorStyles,

              // --- Variant: outlined (same helper as MuiButton.outlined) ---
              '&[data-variant="outlined"]': {
                border: "1px solid",
                ...createSharedOutlinedStyles(themeInstance),
                ...outlinedColorStyles,
              },

              // --- Variant: contained (same helper as MuiButton contained) ---
              '&[data-variant="contained"]': {
                ...createSharedContainedStyles(themeInstance),
                ...containedColorStyles,
              },
            };
          },
        },
      },

      // Paper component customization
      // Paper is used by many components (Popover, Menu, Select dropdown, DatePicker, etc.)
      // CRITICAL: Must use CSS variables for automatic light/dark mode adaptation
      MuiPaper: {
        styleOverrides: {
          root: ({ theme: themeInstance }) => ({
            // Use CSS variables for automatic light/dark adaptation
            backgroundColor:
              (themeInstance.vars?.palette?.background?.paper as string) ||
              themeInstance.palette.background.paper,
            color:
              (themeInstance.vars?.palette?.text?.primary as string) ||
              themeInstance.palette.text.primary,
            '&.MuiPickerPopper-paper': {
              borderRadius: themeInstance.shape.borderRadius,
              overflow: 'hidden',
            }
            // Border for better visibility in dark mode (optional, can be removed if not needed)
            // borderColor: (themeInstance.vars?.palette?.divider as string) || themeInstance.palette.divider,
          }),
        },
      },

      // Popover component customization
      // Used by Select, MultiSelect, DatePicker dropdowns
      MuiPopover: {
        styleOverrides: {
          paper: ({ theme: themeInstance }) => ({
            // Use CSS variables for automatic light/dark adaptation
            backgroundColor:
              (themeInstance.vars?.palette?.background?.paper as string) ||
              themeInstance.palette.background.paper,
            color:
              (themeInstance.vars?.palette?.text?.primary as string) ||
              themeInstance.palette.text.primary,
            // Use theme elevation
            boxShadow: themeInstance.shadows[8],
          }),
        },
      },

      // Select component customization
      // Ensures dropdown menu has correct background in dark mode
      MuiSelect: {
        styleOverrides: {
          // The select input field itself
          select: ({ theme: themeInstance }) => ({
            backgroundColor: "transparent", // Let TextField handle background
            color:
              (themeInstance.vars?.palette?.text?.primary as string) ||
              themeInstance.palette.text.primary,
          }),
        },
      },

      // Pickers Popper (dropdown container)
      MuiPickersPopper: {
        styleOverrides: {
          paper: ({ theme: themeInstance }) => ({
            backgroundColor:
              (themeInstance.vars?.palette?.background?.paper as string) ||
              themeInstance.palette.background.paper,
            color:
              (themeInstance.vars?.palette?.text?.primary as string) ||
              themeInstance.palette.text.primary,
            boxShadow: themeInstance.shadows[8],
          }),
        },
      },

      // Pickers Layout (main calendar container)
      MuiPickersLayout: {
        styleOverrides: {
          root: ({ theme: themeInstance }) => ({
            backgroundColor:
              (themeInstance.vars?.palette?.background?.paper as string) ||
              themeInstance.palette.background.paper,
            color:
              (themeInstance.vars?.palette?.text?.primary as string) ||
              themeInstance.palette.text.primary,
          }),
          contentWrapper: ({ theme: themeInstance }) => ({
            backgroundColor:
              (themeInstance.vars?.palette?.background?.paper as string) ||
              themeInstance.palette.background.paper,
          }),
        },
      },

      // Date Calendar (single calendar view)
      MuiDateCalendar: {
        styleOverrides: {
          root: ({ theme: themeInstance }) => ({
            backgroundColor:
              (themeInstance.vars?.palette?.background?.paper as string) ||
              themeInstance.palette.background.paper,
            color:
              (themeInstance.vars?.palette?.text?.primary as string) ||
              themeInstance.palette.text.primary,
          }),
        },
      },

      // Date Range Calendar (dual calendar view for date range picker)
      MuiDateRangeCalendar: {
        styleOverrides: {
          root: ({ theme: themeInstance }) => ({
            backgroundColor:
              (themeInstance.vars?.palette?.background?.paper as string) ||
              themeInstance.palette.background.paper,
            color:
              (themeInstance.vars?.palette?.text?.primary as string) ||
              themeInstance.palette.text.primary,
          }),
        },
      },

      // Calendar header (month/year selector)
      MuiPickersCalendarHeader: {
        styleOverrides: {
          root: ({ theme: themeInstance }) => ({
            color:
              (themeInstance.vars?.palette?.text?.primary as string) ||
              themeInstance.palette.text.primary,
          }),
          labelContainer: ({ theme: themeInstance }) => ({
            color:
              (themeInstance.vars?.palette?.text?.primary as string) ||
              themeInstance.palette.text.primary,
          }),
        },
      },

      // Individual day cells in calendar
      MuiPickersDay: {
        styleOverrides: {
          root: ({ theme: themeInstance }) => ({
            color:
              (themeInstance.vars?.palette?.text?.primary as string) ||
              themeInstance.palette.text.primary,
            backgroundColor: "transparent",
            "&:hover": {
              backgroundColor:
                (themeInstance.vars?.palette?.action?.hover as string) ||
                themeInstance.palette.action.hover,
            },
            "&.Mui-selected": {
              backgroundColor:
                (themeInstance.vars?.palette?.primary?.main as string) ||
                themeInstance.palette.primary.main,
              color:
                (themeInstance.vars?.palette?.primary
                  ?.contrastText as string) ||
                themeInstance.palette.primary.contrastText,
              "&:hover": {
                backgroundColor:
                  (themeInstance.vars?.palette?.primary?.dark as string) ||
                  themeInstance.palette.primary.dark,
              },
            },
          }),
        },
      },

      // Day of week labels (Mon, Tue, Wed, etc.)
      MuiDayCalendar: {
        styleOverrides: {
          weekDayLabel: ({ theme: themeInstance }) => ({
            color:
              (themeInstance.vars?.palette?.text?.secondary as string) ||
              themeInstance.palette.text.secondary,
          }),
        },
      },

      // Month/Year picker views
      MuiPickersYear: {
        styleOverrides: {
          yearButton: ({ theme: themeInstance }) => ({
            color:
              (themeInstance.vars?.palette?.text?.primary as string) ||
              themeInstance.palette.text.primary,
            "&:hover": {
              backgroundColor:
                (themeInstance.vars?.palette?.action?.hover as string) ||
                themeInstance.palette.action.hover,
            },
            "&.Mui-selected": {
              backgroundColor:
                (themeInstance.vars?.palette?.primary?.main as string) ||
                themeInstance.palette.primary.main,
              color:
                (themeInstance.vars?.palette?.primary
                  ?.contrastText as string) ||
                themeInstance.palette.primary.contrastText,
            },
          }),
        },
      },

      MuiPickersMonth: {
        styleOverrides: {
          monthButton: ({ theme: themeInstance }) => ({
            color:
              (themeInstance.vars?.palette?.text?.primary as string) ||
              themeInstance.palette.text.primary,
            "&:hover": {
              backgroundColor:
                (themeInstance.vars?.palette?.action?.hover as string) ||
                themeInstance.palette.action.hover,
            },
            "&.Mui-selected": {
              backgroundColor:
                (themeInstance.vars?.palette?.primary?.main as string) ||
                themeInstance.palette.primary.main,
              color:
                (themeInstance.vars?.palette?.primary
                  ?.contrastText as string) ||
                themeInstance.palette.primary.contrastText,
            },
          }),
        },
      },

      // Shortcuts panel (Today, Yesterday, Last 7 days, etc.)
      MuiPickersShortcuts: {
        styleOverrides: {
          root: ({ theme: themeInstance }) => ({
            backgroundColor:
              (themeInstance.vars?.palette?.background?.paper as string) ||
              themeInstance.palette.background.paper,
            borderRight: `1px solid ${(themeInstance.vars?.palette?.divider as string) || themeInstance.palette.divider}`,
          }),
        },
      },

      // Action bar (Cancel/Accept buttons)
      MuiPickersActionBar: {
        styleOverrides: {
          root: ({ theme: themeInstance }) => ({
            backgroundColor: 'transparent',
            borderTop: `1px solid ${(themeInstance.vars?.palette?.divider as string) || themeInstance.palette.divider}`,
          }),
        },
      },

      MuiChip: {
        styleOverrides: {
          root: ({ theme: themeInstance }) => ({
            border: "none",
            borderRadius: themeInstance.shape.borderRadius,
            fontWeight: fontWeights.medium,
            lineHeight: 1.38,
            letterSpacing: '0.16px'
          }),
        },
      },
    },
  }, themeOverrides);

  // Return the theme (extendTheme already creates it)
  return theme;
}

// Export the theme
export const exotelTheme = createExotelTheme();
