import type { Meta, StoryObj } from '@storybook/react';
import { AppBar, Icon } from '../../components';
import type { AvatarMenuFooterInfo, AvatarMenuGroup, Product, ThemeMode } from '../../components';

function makeProducts(): Product[] {
  return [
    { id: 'home', name: 'Home', icon: <Icon name="house" size="md" />, section: 'home', order: 0, onProductClick: () => console.log('home') },
    { id: 'ecc', name: 'Enterprise Contact Centre', icon: <Icon name="headset" size="md" />, section: 'products', order: 0, onProductClick: () => console.log('ecc') },
    { id: 'voicebot', name: 'Voicebot', icon: <Icon name="phone" size="md" />, section: 'products', isTrial: true, order: 1, onProductClick: () => console.log('voicebot') },
    { id: 'chatbot', name: 'Chatbot', icon: <Icon name="chat" size="md" />, section: 'products', order: 2, onProductClick: () => console.log('chatbot') },
    { id: 'campaigns', name: 'Campaigns', icon: <Icon name="chart-line" size="md" />, section: 'recommended', order: 0, onProductClick: () => console.log('campaigns') },
    { id: 'engage', name: 'Engage', icon: <Icon name="envelope" size="md" />, section: 'explore', order: 0, onProductClick: () => console.log('engage') },
  ];
}

const DEFAULT_PRODUCTS = makeProducts();

const EXOTEL_LOGO_URL =
  'https://ik.imagekit.io/kx5hycpnh/LogoExpanded.svg?updatedAt=1763974367162';

const AVATAR_MENU_GROUPS: AvatarMenuGroup[] = [
  {
    id: 'primary',
    items: [
      { id: 'item1', label: 'Menu Item 1', onClick: () => console.log('item1') },
      { id: 'item2', label: 'Menu Item 2', onClick: () => console.log('item2') },
      { id: 'item3', label: 'Menu Item 3', onClick: () => console.log('item3') },
    ],
  },
  {
    id: 'secondary',
    items: [
      { id: 'error-logs', label: 'Send Error Logs', onClick: () => console.log('error-logs') },
      { id: 'shortcuts', label: 'Keyboard Shortcuts', onClick: () => console.log('shortcuts') },
    ],
  },
];

const AVATAR_MENU_FOOTER: AvatarMenuFooterInfo[] = [
  { label: 'Last Login', value: 'Jun 21 at 08:37' },
  { label: 'Version', value: '6.0' },
];

const defaultAvatarMenuProps = {
  avatarName: 'Anjali Srivastava',
  menuGroups: AVATAR_MENU_GROUPS,
  footerInfo: AVATAR_MENU_FOOTER,
  selectedTheme: 'system' as ThemeMode,
  onThemeChange: (mode: ThemeMode) => console.log('theme changed:', mode),
  onLogout: () => console.log('logout'),
};

const meta: Meta<typeof AppBar> = {
  title: 'UI Components/AppBar',
  component: AppBar,
  parameters: {
    layout: 'fullscreen',
    docs: {
      description: {
        component:
          'Composed app bar with an AppLauncher trigger, brand logo, notification bell, and AvatarMenu. Pass a URL string or any React node as `brandLogo`. App launcher and user menu are host-owned via `appLauncherProps` and `avatarMenuProps`.',
      },
    },
  },
  tags: ['autodocs'],
  argTypes: {
    brandLogo: {
      control: 'text',
      description: 'URL string or React node for the brand logo',
    },
    brandLogoAlt: {
      control: 'text',
      description: 'Alt text for the brand logo image (used when brandLogo is a string)',
    },
  },
};

export default meta;

type Story = StoryObj<typeof AppBar>;

const withAvatarMenu = {
  avatarMenuProps: defaultAvatarMenuProps,
};

export const WithLogoUrl: Story = {
  name: 'Logo as URL',
  args: {
    brandLogo: EXOTEL_LOGO_URL,
    brandLogoAlt: 'Exotel',
    appLauncherProps: {
      type: 'sectioned',
      products: DEFAULT_PRODUCTS,
    },
    onNotificationClick: () => console.log('notification clicked'),
    ...withAvatarMenu,
  },
};

export const WithLogoNode: Story = {
  name: 'Logo as React node',
  args: {
    brandLogo: (
      <svg width="96" height="24" viewBox="0 0 96 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-label="Exotel">
        <rect width="96" height="24" rx="4" fill="#0F3460" />
        <text x="8" y="17" fontFamily="sans-serif" fontSize="13" fontWeight="700" fill="white">exotel</text>
      </svg>
    ),
    appLauncherProps: {
      type: 'default',
      products: DEFAULT_PRODUCTS,
    },
    onNotificationClick: () => console.log('notification clicked'),
    ...withAvatarMenu,
  },
};

export const DefaultLayout: Story = {
  name: 'AppLauncher — default layout',
  args: {
    brandLogo: EXOTEL_LOGO_URL,
    brandLogoAlt: 'Exotel',
    appLauncherProps: {
      type: 'default',
      products: DEFAULT_PRODUCTS,
    },
    onNotificationClick: () => console.log('notification clicked'),
    ...withAvatarMenu,
  },
};

export const SectionedLayout: Story = {
  name: 'AppLauncher — sectioned layout',
  args: {
    brandLogo: EXOTEL_LOGO_URL,
    brandLogoAlt: 'Exotel',
    appLauncherProps: {
      type: 'sectioned',
      products: DEFAULT_PRODUCTS,
    },
    onNotificationClick: () => console.log('notification clicked'),
    ...withAvatarMenu,
  },
};
