import { createContext, useContext } from "react";
import type { NavSectionProps } from "./components/NavSection";
import type { DisplayConfig } from "./utils";
import type { NavItemProps, NavItemPayload } from "./components/NavItem";

export interface NavigationContextProps {
    staticSidebar: boolean;
    currentPath: string;
    setCurrentPath: (path: string) => void;
    sidebarExpanded: boolean;
    isPinned: boolean;
    setIsPinned: (isPinned: boolean) => void;
    search: string;
    setSearch: (search: string) => void;
    sections: NavSectionProps[];
    setSections: (sections: NavSectionProps[]) => void;
    displayConfig: DisplayConfig;
    setDisplayConfig: (displayConfig: DisplayConfig) => void;
    searchExpandedIds: Set<string>;
    setSearchExpandedIds: (ids: Set<string>) => void;
    pinnedItems: NavItemProps[];
    setPinnedItems: (pinnedItems: NavItemProps[]) => void;
    onNavigate?: (item: NavItemPayload) => void;
}

export const defaultNavigationContext: NavigationContextProps = {
    staticSidebar: false,
    currentPath: '',
    setCurrentPath: () => {},
    sidebarExpanded: false,
    isPinned: false,
    setIsPinned: () => {},
    search: '',
    setSearch: () => {},
    sections: [],
    setSections: () => {},
    displayConfig: {},
    setDisplayConfig: () => {},
    searchExpandedIds: new Set<string>(),
    setSearchExpandedIds: () => {},
    pinnedItems: [],
    setPinnedItems: () => {}
}


const navigationContext = createContext<NavigationContextProps>(defaultNavigationContext);

export const useNavigationContext = () => {
    return useContext(navigationContext);
}

export const NavigationProvider = navigationContext.Provider;
